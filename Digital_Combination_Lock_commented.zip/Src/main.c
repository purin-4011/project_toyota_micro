/******************************************************************************
 * @file    main.c
 * @brief   Digital Combination Lock - Core unlock flow (IDLE -> ENTERING ->
 *          UNLOCKED / LOCKED_OUT) เขียนแบบ Register-level (bare-metal)
 *
 *          รหัส default (ตาม proposal): SHORT-SHORT-SHORT-SHORT
 *          ทดสอบ: กดปุ่มสั้น 4 ครั้งติดกัน (แต่ละครั้งเว้นไม่เกิน 1.5s)
 *          แล้วหยุด 1.5 วิ -> ควรเห็น LED เขียวติดค้าง ~10 วิ
 *
 *          พฤติกรรมที่ควรเห็น:
 *            - ทุกครั้งที่กดปุ่ม (ไม่ว่า SHORT/LONG) -> LED เขียวกระพริบสั้นๆ
 *              ตอบรับ (KEY_ACCEPTED) พร้อม 7-segment แสดงจำนวนหลักที่กด
 *              ไปแล้ว (1, 2, 3, ...)
 *            - หยุดกด 1.5 วิ แล้วรหัสถูก -> LED เขียวติดค้าง 10 วิ
 *            - หยุดกด 1.5 วิ แล้วรหัสผิด (ยังไม่ครบ 3 ครั้ง) -> LED แดง
 *              กระพริบสั้นๆ แล้วกลับ IDLE ให้ป้อนใหม่
 *            - ผิดครบ 3 ครั้งติดกัน -> LED แดงติดค้าง 9 วิ (lockout) พร้อม
 *              7-segment นับถอยหลัง 9,8,7,...,0 ระหว่างนี้กดปุ่มอะไรก็ไม่มีผล
 *
 *          ล็อกชั้นที่ 2 (potentiometer dial lock):
 *            - ตอน IDLE, 7-segment โชว์โซนปัจจุบันของ potentiometer (1-9)
 *              ให้ผู้ใช้หมุนหาตำแหน่งได้ โซนเป้าหมาย default = 5
 *            - ถ้า poten อยู่ถูกโซนอยู่แล้วตอนเริ่มกดปุ่มแรก -> เปิด ADC
 *              Analog Watchdog เฝ้าดูไม่ให้หลุดระหว่างกด ถ้าหลุดกลางคัน
 *              (มือไปโดน) -> ยกเลิกทันที ไฟแดงกะพริบเตือน กลับ IDLE
 *              (ไม่นับเป็นรหัสผิด เพราะถือเป็นอุบัติเหตุ)
 *            - ถ้า poten อยู่ผิดโซนตั้งแต่ก่อนกดปุ่มแรก -> ไม่เปิด watchdog
 *              เลย ปล่อยให้กดรหัสจนจบตามปกติ แล้วไปนับเป็น "กรอกผิด 1
 *              ครั้ง" ตอน validate เหมือนกดรหัสปุ่มผิด (ไม่ใช่การตัดจบ
 *              ทันที เพราะไม่ใช่การหลุดระหว่างกด แต่ผิดตั้งแต่ต้น)
 *            - ปลดล็อกสำเร็จได้ก็ต่อเมื่อผ่านทั้ง 2 เงื่อนไข (dial ถูกโซน
 *              + รหัสปุ่มถูก) พร้อมกันตอน validate
 *
 *          ยังไม่มี: โหมดตั้งรหัสใหม่ (Setup mode - รอออกแบบ UI เพิ่ม), CRC
 *          (ตาม Timeline ที่เหลือ)
 *          (⚠ ย่อหน้านี้เก่าแล้ว — ตอนนี้มี Setup Mode, CRC, UART admin,
 *           NTC/LDR, sleep ครบหมดแล้ว และเวลาค้างตอนปลดล็อก/lockout จริงๆ
 *           ดูที่ APP_UNLOCK_HOLD_TICKS / APP_LOCKOUT_TICKS ใน app_config.h)
 *
 * ============================================================================
 *  📘 อธิบายสำหรับมือใหม่: main.c ทำหน้าที่อะไร?
 * ============================================================================
 *  main.c คือ "ศูนย์กลางการเดินสาย" — ตัวมันเองแทบไม่มี logic ของกุญแจเลย
 *  หน้าที่หลักมี 3 อย่าง:
 *    1) เปิดใช้งานฮาร์ดแวร์ทุกตัวตอนเริ่มโปรแกรม (Main_HardwareInit)
 *    2) เป็น "สะพาน" จาก driver -> application:
 *         EXTI (ปุ่ม)   --callback--> Main_Exti...Handler    --> lock_fsm / setup_mode
 *         TIM3 (100ms)  --callback--> Main_Tim3TickHandler   --> lock_fsm / system_mode
 *         ADC           --callback--> Main_Adc...Handler     --> dial_lock / env_monitor
 *         UART RX       --callback--> Main_UartRxHandler     --> admin_command
 *    3) เป็น "ผู้แสดงผล": เมื่อ application แจ้งเหตุการณ์กลับมา
 *         lock_fsm    --notify--> Main_LockNotifyHandler   --> เปิด/ปิด LED, 7-seg
 *         setup_mode  --notify--> Main_SetupNotifyHandler  --> ไฟเหลือง, ข้อความ UART
 *         system_mode --notify--> Main_SystemNotifyHandler --> sleep/wake/disabled
 *
 *  ⚠ สำคัญ: ฟังก์ชัน Main_*Handler ทุกตัว "ทำงานอยู่ใน ISR" (ถูกเรียกจาก
 *  interrupt) ไม่ใช่จาก main loop — main loop ว่างเปล่า มีแค่ WFI (หลับรอ)
 *  ระบบแบบนี้เรียกว่า "event-driven" / "interrupt-driven"
 *
 *  ตัวอย่างการไหลของ 1 การกดปุ่ม PB4:
 *    กดลง  -> EXTI4_IRQHandler -> Main_ExtiEventHandler(RISING)  จดเวลาเริ่ม
 *    ปล่อย -> EXTI4_IRQHandler -> Main_ExtiEventHandler(FALLING) คำนวณเวลากด
 *          -> CodeDecoder_Classify() ได้ SHORT/LONG
 *          -> LockFsm_OnSymbol() เก็บลง buffer
 *          -> lock_fsm แจ้ง KEY_ACCEPTED -> Main_LockNotifyHandler เปิดไฟฟ้า + 7-seg
 *    หยุดกด 1.5s -> TIM3 tick ครบ 15 ครั้ง -> LockFsm_Validate() ตรวจรหัส
 *          -> แจ้ง UNLOCK_SUCCESS หรือ UNLOCK_FAIL -> เปิดไฟเขียว/แดง
 ******************************************************************************/
#include "core_driver.h"
#include "gpio_driver.h"
#include "exti_driver.h"
#include "timer_driver.h"
#include "seven_segment_driver.h"
#include "uart_driver.h"
#include "adc_driver.h"
#include "crc_driver.h"
#include "code_decoder.h"
#include "lock_fsm.h"
#include "code_storage.h"
#include "admin_command.h"
#include "dial_lock.h"
#include "setup_mode.h"
#include "env_monitor.h"
#include "system_mode.h"
#include "app_config.h"

/* จำนวน tick (100ms/tick) ที่ต้องการให้ LED กระพริบสั้นๆ ตอบรับการกด/ผิด */
#define MAIN_BLINK_HOLD_TICKS   (3U)   /* 3 x 100ms = 300ms */

/* ความยาวสูงสุดของบรรทัดคำสั่ง admin (คำสั่งที่ยาวที่สุดคือ "LOCKOUT" = 7
 * ตัวอักษร เผื่อไว้ให้พอสำหรับ error/edge case) */
#define MAIN_ADMIN_LINE_MAX_LEN  (16U)

/* ความยาวสูงสุดของข้อความ UART ที่ประกอบขึ้นเองใน Setup Mode (ยาวสุดคือ
 * ข้อความสรุปตอน COMMITTED เช่น "SETUP SAVED: zone=9, 8 digit,
 * short-short-...-long\r\n") */
#define MAIN_UART_MSG_MAX_LEN   (100U)

/* ตัวแปรที่ถูกแตะทั้งจาก ISR และ main loop ต้องเป็น volatile ตาม MISRA-C
 * (ในโปรเจคนี้ถูกแตะจาก ISR หลายตัวที่ priority ต่างกัน ซึ่งแทรกกันได้ ก็ต้อง volatile เช่นกัน) */
static uint32_t volatile s_press_start_tick = 0U;         /* เวลา (ms จาก TIM2) ที่เริ่มกด PB4 */
static uint32_t volatile s_setup_press_start_tick = 0U;   /* เวลาที่เริ่มกด PB5 */
/* ตัวนับถอยหลังของไฟกระพริบสั้นๆ: ตั้งเป็น 3 แล้ว TIM3 ลดทีละ 1 ทุก 100ms
 * ถึง 0 เมื่อไหร่ก็ดับไฟ -> ได้ไฟกระพริบ 300ms โดยไม่ต้องใช้ delay */
static uint16_t volatile s_green_blink_ticks_remaining = 0U;
static uint16_t volatile s_red_blink_ticks_remaining = 0U;

/* ปุ่มที่วัดระยะเวลากด (PB4, PB5): จำไว้ว่าจังหวะ "กด" ถูกรับไว้จริงไหม
 * ป้องกันกรณีกดตอน sleep/disabled (ถูกทิ้ง) แล้วไปปล่อยตอนระบบกลับมา
 * ACTIVE — ถ้าไม่เช็ค จะคำนวณ duration จากค่าเวลาเก่าจนได้ LONG ผิดๆ */
static bool volatile s_press_valid = false;
static bool volatile s_setup_press_valid = false;

/* นับ tick สำหรับสั่งอ่าน NTC + LDR และจังหวะกระพริบตอน DISABLED */
static uint8_t volatile s_env_sample_ticks = 0U;
static uint8_t volatile s_disabled_blink_ticks = 0U;

/* buffer สะสมบรรทัดคำสั่ง admin ที่รับมาทีละ byte จาก UART RX interrupt */
static char s_admin_line_buffer[MAIN_ADMIN_LINE_MAX_LEN];
static uint8_t s_admin_line_index = 0U;   /* ตอนนี้สะสมไปกี่ตัวอักษรแล้ว */

/* ---------------------------------------------------------------------- *
 * Prototype ของฟังก์ชันภายในไฟล์นี้ (static = ใช้ในไฟล์นี้เท่านั้น)
 * ต้องประกาศไว้ก่อนเพราะ C อ่านจากบนลงล่าง ถ้า main() เรียกฟังก์ชันที่
 * เขียนไว้ข้างล่าง compiler จะยังไม่รู้จัก
 * ---------------------------------------------------------------------- */
static void Main_ExtiEventHandler(EXTI_Edge_t edge);
static void Main_ExtiSetupButtonHandler(EXTI_Edge_t edge);
static void Main_ExtiDigitUpHandler(EXTI_Edge_t edge);
static void Main_ExtiDigitDownHandler(EXTI_Edge_t edge);
static void Main_Tim3TickHandler(void);
static void Main_LockNotifyHandler(LockFsm_Notification_t notification);
static void Main_SetupNotifyHandler(SetupMode_Notification_t notification);
static void Main_UartRxHandler(uint8_t received_byte);
static void Main_AdcEocHandler(uint16_t raw_value);
static void Main_AdcWatchdogHandler(void);
static void Main_AdcInjectedHandler(uint16_t ntc_raw, uint16_t ldr_raw);
static void Main_EnvNotifyHandler(EnvMonitor_Notification_t notification);
static void Main_SystemNotifyHandler(SystemMode_Notification_t notification);
static bool Main_AcceptUserInput(void);
static void Main_HardwareInit(void);

static void Main_SendCurrentPassword(void);
static void Main_SendStatus(void);
static void Main_AppendUint(char * p_buf, uint8_t * p_len, uint32_t value);
static void Main_AppendDeciC(char * p_buf, uint8_t * p_len, int32_t deci_c);
static void Main_AppendSymbolPattern(char * p_buf, uint8_t * p_len,
                                     CodeSymbol_t (*get_symbol)(uint8_t), uint8_t count);
static void Main_AppendChar(char * p_buf, uint8_t * p_len, char c);
static void Main_AppendStr(char * p_buf, uint8_t * p_len, char const * p_str);
static void Main_AppendDigit(char * p_buf, uint8_t * p_len, uint8_t digit);

/* 📘 main() = จุดเริ่มต้นของโปรแกรม (ถูกเรียกจาก startup file หลังจ่ายไฟ/กด reset) */
int main(void)
{
    /* ต้องเปิด FPU เป็นอย่างแรก ก่อนโค้ดที่ใช้ float (env_monitor) จะทำงาน */
    Core_Driver_Init();

    Main_HardwareInit();

    /* งานทั้งหมดขับเคลื่อนด้วย interrupt ตามเกณฑ์ "ห้าม Polling"
     * main loop จึงแค่สั่งให้ CPU เข้า Sleep mode (WFI) ระหว่างรอ interrupt
     * ถัดไป — ตอนระบบอยู่ในสถานะ SLEEP interrupt เหลือแค่ ~15 ครั้ง/วินาที
     * (TIM3 + อ่าน NTC/LDR) CPU จึงหลับเกือบตลอดเวลา
     * 📘 for (;;) = loop ไม่มีที่สิ้นสุด (โปรแกรม embedded ห้าม return ออกจาก main
     *    เพราะไม่มีระบบปฏิบัติการให้กลับไป) แต่ละรอบ: หลับ -> interrupt ปลุก ->
     *    ISR ทำงาน -> กลับมาที่นี่ -> หลับต่อ */
    for (;;)
    {
        Core_Driver_WaitForInterrupt();
    }
}

/**
 * @brief  เปิดใช้งานฮาร์ดแวร์ทุกตัว — ⚠ "ลำดับ" มีความสำคัญ อ่าน comment แต่ละขั้น
 *         หลักทั่วไป: อะไรที่ callback ของ interrupt ต้องใช้ ต้อง init ก่อน
 *         เปิด interrupt นั้น เพราะ interrupt อาจเกิดทันทีหลังเปิด
 */
static void Main_HardwareInit(void)
{
    /* --- LED outputs --- (ทุกดวง: เปิด clock -> ตั้งเป็น output -> เริ่มต้นดับ)
     *   APP_LED_GREEN  = PA5 ไฟฟ้า กระพริบตอบรับการกด
     *   APP_LED_RED    = PA6 ไฟแดง ผิด/lockout/disabled
     *   APP_LED_G      = PB6 ไฟเขียวจริง ปลดล็อกสำเร็จ
     *   APP_LED_YELLOW = PA7 ไฟเหลือง Setup Mode
     * ⚠ แต่ละขาจ่ายได้ ~20 mA ต้องมีตัวต้านทานอนุกรมกับ LED (บน shield มีให้แล้ว) */
    GPIO_Driver_EnableClock(APP_LED_GREEN_PORT);
    GPIO_Driver_Init(APP_LED_GREEN_PORT, APP_LED_GREEN_PIN, GPIO_MODE_OUTPUT, GPIO_PULL_NONE);
    GPIO_Driver_WritePin(APP_LED_GREEN_PORT, APP_LED_GREEN_PIN, GPIO_PIN_RESET);

    GPIO_Driver_EnableClock(APP_LED_RED_PORT);
    GPIO_Driver_Init(APP_LED_RED_PORT, APP_LED_RED_PIN, GPIO_MODE_OUTPUT, GPIO_PULL_NONE);
    GPIO_Driver_WritePin(APP_LED_RED_PORT, APP_LED_RED_PIN, GPIO_PIN_RESET);

    GPIO_Driver_EnableClock(APP_LED_G_PORT);
    GPIO_Driver_Init(APP_LED_G_PORT, APP_LED_G_PIN, GPIO_MODE_OUTPUT, GPIO_PULL_NONE);
    GPIO_Driver_WritePin(APP_LED_G_PORT, APP_LED_G_PIN, GPIO_PIN_RESET);

    GPIO_Driver_EnableClock(APP_LED_YELLOW_PORT);
    GPIO_Driver_Init(APP_LED_YELLOW_PORT, APP_LED_YELLOW_PIN, GPIO_MODE_OUTPUT, GPIO_PULL_NONE);
    GPIO_Driver_WritePin(APP_LED_YELLOW_PORT, APP_LED_YELLOW_PIN, GPIO_PIN_RESET);

    /* --- Timing subsystem (Two-Tier Architecture) ---
     *     TIM2 ต้องมาก่อนปุ่ม เพราะ handler ของปุ่มอ่านเวลาจาก TIM2
     *     (หมายเหตุ: TIM3 เริ่มยิง tick ตั้งแต่ตรงนี้ ก่อน LockFsm_Init จะถูก
     *      เรียก — ใช้ได้เพราะตัวแปรของ lock_fsm มีค่าเริ่มต้นเป็น IDLE/0 อยู่แล้ว) */
    Timer_Driver_TIM2_Init();
    Timer_Driver_TIM3_Init(Main_Tim3TickHandler);

    /* --- Button input (EXTI4 บน PB4) ---
     *     📘 ส่ง "ชื่อฟังก์ชัน" (ไม่มีวงเล็บ) = ส่งที่อยู่ของฟังก์ชันให้ driver จำไว้
     *        driver จะเรียก Main_ExtiEventHandler() ให้เองทุกครั้งที่ปุ่มเปลี่ยน */
    EXTI_Driver_Init(Main_ExtiEventHandler);

    /* --- ปุ่ม Setup Mode ใหม่ (PB5/PA10/PB3) --- */
    EXTI_Driver_InitSetupButton(Main_ExtiSetupButtonHandler);
    EXTI_Driver_InitDigitUpButton(Main_ExtiDigitUpHandler);
    EXTI_Driver_InitDigitDownButton(Main_ExtiDigitDownHandler);

    /* --- 7-segment (BCD) สำหรับแสดง lockout countdown --- */
    SevenSegment_Driver_Init();

    /* --- UART (USART2) สำหรับ Admin Mode: รับคำสั่งจาก PC ผ่าน ST-Link VCP --- */
    UART_Driver_Init(Main_UartRxHandler);
    UART_Driver_SendString("Digital Combination Lock - Admin console ready\r\n");

    /* --- สถานะระบบ (ACTIVE/SLEEP/DISABLED) และเซนเซอร์สภาพแวดล้อม
     *     ต้อง init ก่อน ADC เพราะ JEOC callback จะเรียก EnvMonitor --- */
    SystemMode_Init(Main_SystemNotifyHandler);
    EnvMonitor_Init(Main_EnvNotifyHandler);

    /* --- ADC: regular = potentiometer (PA4) สำหรับล็อกชั้นที่ 2,
     *          injected = NTC (PA0) + LDR (PA1) อ่านทุก 200ms จาก TIM3 --- */
    ADC_Driver_Init(Main_AdcEocHandler, Main_AdcInjectedHandler);

    /* --- CRC (ตรวจสอบความถูกต้องของรหัสที่เก็บไว้ ป้องกัน RAM corruption)
     *     ต้องเปิดก่อน LockFsm_Init() เพราะข้างในจะเรียก CodeStorage_Init()
     *     ซึ่งต้องใช้ CRC hardware คำนวณค่าอ้างอิงทันที --- */
    CRC_Driver_Init();

    /* --- State machine หลักของระบบล็อก --- */
    LockFsm_Init(Main_LockNotifyHandler);

    /* --- Setup Mode (ต้อง init หลัง LockFsm_Init เพราะ Main_SetupNotifyHandler
     *     จะเรียก LockFsm_ForceIdle() ตอนเข้า Setup Mode) --- */
    SetupMode_Init(Main_SetupNotifyHandler);
}

/**
 * @brief  เรียกจาก EXTI4 ISR เมื่อปุ่มถูกกดหรือปล่อย
 *         คำนวณ duration จาก TIM2 tick แล้วส่งต่อให้ lock_fsm หรือ
 *         setup_mode ตัดสินใจ ขึ้นอยู่กับว่าตอนนี้อยู่ใน Setup Mode
 *         ขั้นตอนกรอกรหัสหรือไม่ (main.c ไม่ตัดสินใจ logic เองแล้ว
 *         แค่เป็นสะพานเชื่อม)
 */
static void Main_ExtiEventHandler(EXTI_Edge_t const edge)
{
    /* โครงสร้าง if/else-if 4 ทาง:
     *   1) เพิ่งกดลง            -> จดเวลาเริ่ม + จำว่ารับการกดนี้ไหม
     *   2) ปล่อย แต่ตอนกดไม่ถูกรับ -> ทิ้ง
     *   3) ปล่อย แต่ระบบเพิ่งเปลี่ยนเป็น sleep/disabled ระหว่างกด -> ทิ้ง
     *   4) ปล่อย ปกติ            -> คำนวณ SHORT/LONG แล้วส่งต่อ
     * (EXTI_EDGE_RISING = "กดลง" ตามคอนเวนชันของ exti_driver.h) */
    if (edge == EXTI_EDGE_RISING)
    {
        /* รับการกดเฉพาะตอน ACTIVE (sleep/disabled ไม่รับปุ่ม) */
        s_press_valid = Main_AcceptUserInput();
        s_press_start_tick = Timer_Driver_TIM2_GetTick();
    }
    else if (!s_press_valid)
    {
        /* จังหวะกดไม่ได้ถูกรับไว้ (กดตอน sleep/disabled) - ทิ้งการปล่อยนี้ */
    }
    else if (SystemMode_Get() != SYSTEM_MODE_ACTIVE)
    {
        /* ระบบเปลี่ยนเป็น DISABLED ระหว่างกดค้าง - ทิ้ง */
        s_press_valid = false;
    }
    else /* EXTI_EDGE_FALLING */
    {
        /* เวลากด = เวลาตอนปล่อย - เวลาตอนกด (หน่วย ms เพราะ TIM2 นับทีละ 1ms) */
        uint32_t const release_tick = Timer_Driver_TIM2_GetTick();
        uint32_t const duration_ms  = release_tick - s_press_start_tick;
        CodeSymbol_t const symbol   = CodeDecoder_Classify(duration_ms);

        s_press_valid = false;   /* ใช้การกดนี้ไปแล้ว */

        /* ปุ่ม PB4 ใช้ร่วมกัน 2 งาน -> ดูว่าตอนนี้อยู่โหมดไหนแล้วส่งให้ถูกคน */
        if (SetupMode_GetState() == SETUP_STATE_ENTER_CODE)
        {
            /* อยู่ระหว่างกรอกรหัสใหม่ใน Setup Mode - ส่งให้ setup_mode
             * แทน lock_fsm พร้อมกระพริบ LED feedback เหมือนโหมดปกติ */
            SetupMode_OnCodeSymbol(symbol);

            GPIO_Driver_WritePin(APP_LED_GREEN_PORT, APP_LED_GREEN_PIN, GPIO_PIN_SET);
            s_green_blink_ticks_remaining = (uint16_t) MAIN_BLINK_HOLD_TICKS;
        }
        else if (SetupMode_GetState() == SETUP_STATE_INACTIVE)
        {
            /* โหมดปกติ -> ส่งให้ state machine ของกุญแจ */
            LockFsm_OnSymbol(symbol, duration_ms);
        }
        else
        {
            /* SETUP_STATE_SELECT_LENGTH - ปุ่มนี้ไม่มีบทบาทในขั้นนี้ */
        }
    }
}

/**
 * @brief  เรียกจาก EXTI ISR ของปุ่ม Setup Mode (PB5) — วัดระยะเวลากดค้าง
 *         เสมอ แล้วส่งให้ setup_mode ตัดสินใจความหมายตามสถานะปัจจุบัน
 *         (หลักการวัดเวลาเหมือน Main_ExtiEventHandler ด้านบนทุกอย่าง)
 *         ⚠ สังเกต: ไม่ได้เช็คสถานะ lock_fsm ก่อน -> กด PB5 ค้าง 3s ตอน
 *           LOCKED_OUT ก็เข้า Setup Mode ได้ (และ ForceIdle จะล้าง lockout)
 *           ดูหมายเหตุด้านความปลอดภัยใน setup_mode.c
 */
static void Main_ExtiSetupButtonHandler(EXTI_Edge_t const edge)
{
    if (edge == EXTI_EDGE_RISING)
    {
        s_setup_press_valid = Main_AcceptUserInput();
        s_setup_press_start_tick = Timer_Driver_TIM2_GetTick();
    }
    else if ((!s_setup_press_valid) || (SystemMode_Get() != SYSTEM_MODE_ACTIVE))
    {
        /* กดตอน sleep/disabled หรือระบบเปลี่ยนสถานะระหว่างกดค้าง - ทิ้ง */
        s_setup_press_valid = false;
    }
    else /* EXTI_EDGE_FALLING */
    {
        uint32_t const release_tick = Timer_Driver_TIM2_GetTick();
        uint32_t const duration_ms  = release_tick - s_setup_press_start_tick;

        s_setup_press_valid = false;
        SetupMode_OnButtonPB5(duration_ms);
    }
}

/**
 * @brief  เรียกจาก EXTI ISR ของปุ่มเพิ่มจำนวนหลัก (PA10) — ทำงานตอนปล่อย
 *         ปุ่ม (EXTI_EDGE_FALLING ตามคอนเวนชันของ exti_driver นี้) เพื่อ
 *         กันการกดค้างแล้วนับซ้ำ
 *         (กด 1 ครั้งมี 2 event: กดลง + ปล่อย ถ้านับทั้งคู่จะ +2 จึงเลือกนับแค่ตอนปล่อย)
 *         ⚠ ไม่มี software debounce: ถ้าปุ่มเด้ง (bounce) หลายครั้งตอนปล่อย
 *           อาจนับเกิน 1 ได้ ถ้าเจออาการนี้ตอนทดสอบ แก้ได้ด้วยการเช็คเวลาจาก
 *           TIM2 ว่าห่างจากครั้งก่อน > ~50ms ค่อยรับ
 */
static void Main_ExtiDigitUpHandler(EXTI_Edge_t const edge)
{
    if (edge == EXTI_EDGE_FALLING)
    {
        if (Main_AcceptUserInput())
        {
            SetupMode_OnDigitIncrement();
        }
        else
        {
            /* sleep/disabled - ไม่รับปุ่ม */
        }
    }
    else
    {
        /* EXTI_EDGE_RISING (เพิ่งกดลง) - ไม่ทำอะไร */
    }
}

/**
 * @brief  เรียกจาก EXTI ISR ของปุ่มลดจำนวนหลัก (PB3) — หลักการเดียวกับ
 *         Main_ExtiDigitUpHandler
 */
static void Main_ExtiDigitDownHandler(EXTI_Edge_t const edge)
{
    if (edge == EXTI_EDGE_FALLING)
    {
        if (Main_AcceptUserInput())
        {
            SetupMode_OnDigitDecrement();
        }
        else
        {
            /* sleep/disabled - ไม่รับปุ่ม */
        }
    }
    else
    {
        /* EXTI_EDGE_RISING (เพิ่งกดลง) - ไม่ทำอะไร */
    }
}

/**
 * @brief  เรียกจาก TIM3 ISR ทุก 100ms — ทำ 2 หน้าที่:
 *         1) นับถอยหลัง LED กระพริบสั้นๆ (blink feedback) แล้วดับเมื่อครบ
 *         2) ขับเคลื่อน timeout ต่างๆ ภายใน lock_fsm (input timeout,
 *            unlock display hold, lockout countdown)
 */
static void Main_Tim3TickHandler(void)
{
    /* 📘 ฟังก์ชันนี้คือ "หัวใจที่เต้นทุก 100 ms" ของทั้งระบบ แบ่งเป็น 6 ส่วน:
     *    (1) ดับไฟฟ้าเมื่อครบเวลากระพริบ   (2) ดับไฟแดงเมื่อครบเวลากระพริบ
     *    (3) ขับ lock_fsm (timeout ต่างๆ)   (4) อัพเดตเลขนับถอยหลัง lockout
     *    (5) สั่งอ่าน NTC/LDR ทุก 200ms     (6) ขับ system_mode + กระพริบตอน DISABLED
     *    เทคนิค "นับ tick" แบบนี้ใช้แทน delay() ได้โดย CPU ไม่ต้องหยุดรอเลย */

    /* (1) ไฟฟ้า feedback */
    if (s_green_blink_ticks_remaining > 0U)
    {
        s_green_blink_ticks_remaining--;

        if ((s_green_blink_ticks_remaining == 0U) && (LockFsm_GetState() != LOCK_STATE_UNLOCKED))
        {
            /* ดับไฟกระพริบ เว้นแต่กำลังอยู่ในสถานะ UNLOCKED ที่ต้องการให้
             * ไฟเขียวค้างไว้ต่อ (lock_fsm เป็นคนสั่งดับเองผ่าน
             * LOCK_NOTIFY_RETURN_TO_IDLE ตอนครบ 10 วิ) */
            GPIO_Driver_WritePin(APP_LED_GREEN_PORT, APP_LED_GREEN_PIN, GPIO_PIN_RESET);
        }
        else
        {
            /* ยังนับไม่ครบ หรือกำลังอยู่ในสถานะที่ต้องการให้ไฟค้าง */
        }
    }
    else
    {
        /* ไม่มีไฟกระพริบค้างอยู่ - ไม่ทำอะไร */
    }

    /* (2) ไฟแดงกระพริบสั้น (ตอนกรอกผิด / poten หลุดโซน) — ยกเว้นตอน lockout ที่ต้องค้าง */
    if (s_red_blink_ticks_remaining > 0U)
    {
        s_red_blink_ticks_remaining--;

        if ((s_red_blink_ticks_remaining == 0U) && (LockFsm_GetState() != LOCK_STATE_LOCKED_OUT))
        {
            GPIO_Driver_WritePin(APP_LED_RED_PORT, APP_LED_RED_PIN, GPIO_PIN_RESET);
        }
        else
        {
            /* ยังนับไม่ครบ หรือกำลังอยู่ในสถานะ LOCKED_OUT ที่ต้องการให้ไฟค้าง */
        }
    }
    else
    {
        /* ไม่มีไฟกระพริบค้างอยู่ - ไม่ทำอะไร */
    }

    /* (3) บอก lock_fsm ว่าเวลาผ่านไป 100ms แล้ว */
    LockFsm_OnTick();

    /* (4) อัพเดตจอ 7-segment แสดง lockout countdown ทุก tick ที่อยู่ในสถานะนี้
     * (ยังไม่ทำ "blank" ตอนไม่ใช่ lockout เพราะ BCD driver IC ไม่มีขา
     * Blanking Input ต่อไว้ - ดู TODO ใน seven_segment_driver.h) */
    if ((LockFsm_GetState() == LOCK_STATE_LOCKED_OUT) && (SystemMode_Get() == SYSTEM_MODE_ACTIVE))
    {
        SevenSegment_Driver_ShowDigit((uint8_t) LockFsm_GetLockoutSecondsRemaining());
    }
    else
    {
        /* ไม่อยู่ในสถานะ lockout หรือระบบ sleep/disabled - ไม่ต้องอัพเดตจอ */
    }

    /* (5) --- สั่งอ่าน NTC + LDR (ADC injected) ทุก 200ms ผลมาทาง JEOC interrupt ---
     *     นับ 0 -> 1 -> 2 (ครบ) -> สั่งอ่าน + กลับเป็น 0 = ทุก 2 tick */
    s_env_sample_ticks++;
    if (s_env_sample_ticks >= (uint8_t) APP_ENV_SAMPLE_TICKS)
    {
        s_env_sample_ticks = 0U;
        ADC_Driver_StartInjected();
    }
    else
    {
        /* ยังไม่ถึงรอบอ่าน */
    }

    /* (6) --- ขับ state machine ระดับระบบ: ว่างพอจะหลับได้ก็ต่อเมื่อไม่ได้กำลัง
     *     กรอกรหัส/ปลดล็อก/ล็อกเอาต์ และไม่อยู่ใน Setup Mode (ทำให้ sleep
     *     ไม่มีทางไปล้าง lockout หรือตัดการกรอกรหัสกลางคันได้) --- */
    SystemMode_OnTick((LockFsm_GetState() == LOCK_STATE_IDLE)
                          && (SetupMode_GetState() == SETUP_STATE_INACTIVE),
                      EnvMonitor_IsPresenceDetected());

    /* --- DISABLED: LED แดงกระพริบ (ต่างจาก lockout ที่ติดค้าง) --- */
    if (SystemMode_Get() == SYSTEM_MODE_DISABLED)
    {
        s_disabled_blink_ticks++;
        if (s_disabled_blink_ticks >= (uint8_t) APP_DISABLED_BLINK_TICKS)
        {
            s_disabled_blink_ticks = 0U;
            GPIO_Driver_TogglePin(APP_LED_RED_PORT, APP_LED_RED_PIN);
        }
        else
        {
            /* ยังไม่ถึงจังหวะสลับ */
        }
    }
    else
    {
        s_disabled_blink_ticks = 0U;
    }
}

/**
 * @brief  เรียกจาก lock_fsm เมื่อมีเหตุการณ์เกิดขึ้น (ผ่าน callback ที่
 *         ลงทะเบียนไว้ตอน LockFsm_Init) - main.c เป็นคนตัดสินใจว่าจะ
 *         แสดงผลยังไง (LED + 7-segment + เปิด/ปิด ADC Analog Watchdog)
 *
 *         สรุปการแสดงผลแต่ละเหตุการณ์:
 *           KEY_ACCEPTED   : ไฟฟ้ากระพริบ 300ms, 7-seg = จำนวนหลักที่กด
 *           UNLOCK_SUCCESS : ไฟเขียว PB6 ติดค้าง
 *           UNLOCK_FAIL    : ไฟแดงกระพริบ 300ms, 7-seg = 0
 *           LOCKOUT_ENTER  : ไฟแดงติดค้าง, 7-seg = 9 แล้วนับถอยหลัง
 *           RETURN_TO_IDLE : ดับไฟเขียว/แดง, 7-seg กลับไปโชว์โซน poten
 *           DIAL_VIOLATION : ไฟแดงกระพริบ 300ms, 7-seg = 0
 */
static void Main_LockNotifyHandler(LockFsm_Notification_t const notification)
{
    switch (notification)
    {
        case LOCK_NOTIFY_KEY_ACCEPTED:
            GPIO_Driver_WritePin(APP_LED_GREEN_PORT, APP_LED_GREEN_PIN, GPIO_PIN_SET);
            s_green_blink_ticks_remaining = (uint16_t) MAIN_BLINK_HOLD_TICKS;
            /* แสดงจำนวนหลักที่ป้อนไปแล้วบน 7-segment (1, 2, 3, ...) */
            SevenSegment_Driver_ShowDigit(LockFsm_GetEntryCount());

            /* สัญลักษณ์แรกของรอบ (entry count = 1) -> เปิด Analog Watchdog
             * เฝ้าโซนที่ potentiometer อยู่ตอนนี้ (ดูรายละเอียดด้านล่าง) */
            if (LockFsm_GetEntryCount() == 1U)
            {
                /* ปุ่มแรกของรอบ: ล็อกโซนที่ potentiometer อยู่ "ตอนนี้"
                 * (ไม่ใช่โซนเป้าหมาย) ให้ Analog Watchdog เฝ้าดูว่า
                 * potentiometer อยู่กับที่ตลอดการกดรหัส ถ้าขยับหลุดโซนนี้
                 * กลางคัน -> ยกเลิกรอบทันที
                 * ส่วนการตรวจว่าโซนนี้เป็นโซนที่ถูกต้องหรือไม่ ทำตอน
                 * validate ใน lock_fsm (DialLock_IsAtTargetZone) แยกกัน
                 * 📘 (เหตุผลที่ไม่เฝ้า "โซนเป้าหมาย": ถ้าเฝ้าโซนเป้าหมาย
                 *    ตอนผู้ใช้อยู่ผิดโซน watchdog จะดังทันทีที่กดปุ่มแรก
                 *    = บอกใบ้คนร้ายว่าโซนผิด ไม่ปลอดภัย) */
                uint16_t dial_low;
                uint16_t dial_high;

                DialLock_GetCurrentZoneBounds(&dial_low, &dial_high);
                ADC_Driver_EnableWatchdog(dial_low, dial_high, Main_AdcWatchdogHandler);
            }
            else
            {
                /* ไม่ใช่ตัวแรก - ถ้า watchdog เปิดอยู่แล้วก็เปิดต่อ ถ้าไม่ได้
                 * เปิดไว้ (เพราะผิดโซนตั้งแต่ต้น) ก็ยังคงไม่เปิด */
            }
            break;

        case LOCK_NOTIFY_UNLOCK_SUCCESS:
            GPIO_Driver_WritePin(APP_LED_G_PORT, APP_LED_G_PIN, GPIO_PIN_SET);
            GPIO_Driver_WritePin(APP_LED_RED_PORT, APP_LED_RED_PIN, GPIO_PIN_RESET);
            ADC_Driver_DisableWatchdog();
            /* ไม่ตั้ง blink counter - ไฟติดค้างจนกว่า lock_fsm จะสั่ง
             * RETURN_TO_IDLE เองตอนครบ 10 วิ (ดูฟังก์ชัน Main_Tim3TickHandler) */
            break;

        case LOCK_NOTIFY_UNLOCK_FAIL:
            GPIO_Driver_WritePin(APP_LED_RED_PORT, APP_LED_RED_PIN, GPIO_PIN_SET);
            s_red_blink_ticks_remaining = (uint16_t) MAIN_BLINK_HOLD_TICKS;
            ADC_Driver_DisableWatchdog();
            /* ป้อนรหัสรอบนี้จบแล้ว (ไม่ว่าจะถูกหรือผิด) -> ล้างตัวเลขนับหลัก
             * กลับเป็น 0 เตรียมรอรอบถัดไป */
            SevenSegment_Driver_ShowDigit(0U);
            break;

        case LOCK_NOTIFY_LOCKOUT_ENTER:
            GPIO_Driver_WritePin(APP_LED_RED_PORT, APP_LED_RED_PIN, GPIO_PIN_SET);
            GPIO_Driver_WritePin(APP_LED_GREEN_PORT, APP_LED_GREEN_PIN, GPIO_PIN_RESET);
            ADC_Driver_DisableWatchdog();
            SevenSegment_Driver_ShowDigit((uint8_t) APP_LOCKOUT_DURATION_SEC);
            break;

        case LOCK_NOTIFY_RETURN_TO_IDLE:
            GPIO_Driver_WritePin(APP_LED_G_PORT, APP_LED_G_PIN, GPIO_PIN_RESET);
            GPIO_Driver_WritePin(APP_LED_RED_PORT, APP_LED_RED_PIN, GPIO_PIN_RESET);
            ADC_Driver_DisableWatchdog();
            /* กลับสู่สถานะปกติแล้ว (ไม่ว่าจะจบจาก UNLOCKED หรือ LOCKED_OUT)
             * -> ล้างจอ 7-segment กลับเป็น 0 เตรียมรอบถัดไป (จอจะกลับไป
             * แสดงโซน potentiometer เองอัตโนมัติผ่าน Main_AdcEocHandler
             * ตั้งแต่ sample ถัดไปเพราะตอนนี้ state กลับเป็น IDLE แล้ว) */
            SevenSegment_Driver_ShowDigit(0U);
            break;

        case LOCK_NOTIFY_DIAL_VIOLATION:
            /* potentiometer หลุดโซนเป้าหมายระหว่างกำลังป้อนรหัส - ยกเลิก
             * รอบนี้ทันที เตือนด้วย LED แดงกะพริบสั้นๆ (ไม่ติดค้างเหมือน
             * lockout เพราะไม่ใช่ความผิดที่นับโทษ) */
            ADC_Driver_DisableWatchdog();
            GPIO_Driver_WritePin(APP_LED_RED_PORT, APP_LED_RED_PIN, GPIO_PIN_SET);
            s_red_blink_ticks_remaining = (uint16_t) MAIN_BLINK_HOLD_TICKS;
            SevenSegment_Driver_ShowDigit(0U);
            break;

        default:
            /* MISRA: switch ต้องมี default case เสมอ แม้ enum จะครบทุกค่าแล้ว */
            break;
    }
}

/**
 * @brief  เรียกจาก setup_mode เมื่อมีเหตุการณ์เกิดขึ้น (ผ่าน callback ที่
 *         ลงทะเบียนไว้ตอน SetupMode_Init) — main.c เป็นคนตัดสินใจว่าจะ
 *         แสดงผลยังไง (ไฟเหลือง + ข้อความ UART) ตามสเปค 6 ข้อที่ตกลงกัน
 */
static void Main_SetupNotifyHandler(SetupMode_Notification_t const notification)
{
    /* buffer ชั่วคราวไว้ประกอบข้อความ (local variable อยู่บน stack หายเมื่อฟังก์ชันจบ
     * ไม่เป็นไรเพราะ UART_Driver_SendString คัดลอกข้อความไปเก็บเองแล้ว) */
    char msg_buf[MAIN_UART_MSG_MAX_LEN];
    uint8_t msg_len = 0U;   /* ความยาวข้อความตอนนี้ — ฟังก์ชัน Main_Append* จะเพิ่มให้เอง */

    switch (notification)
    {
        case SETUP_NOTIFY_ENTERED:
            /* เข้า Setup Mode: ยกเลิกการกรอกรหัสปกติที่ค้างอยู่แบบปลอดภัย
             * (ไม่แตะรหัสเดิม/ตัวนับกรอกผิด) แล้วเปิดไฟเหลืองค้างไว้ */
            LockFsm_ForceIdle();
            GPIO_Driver_WritePin(APP_LED_YELLOW_PORT, APP_LED_YELLOW_PIN, GPIO_PIN_SET);
            UART_Driver_SendString("\r\nSETUP MODE\r\n");
            break;

        case SETUP_NOTIFY_DIGIT_COUNT_CHANGED:
            /* ประกอบเป็น "Digits: 3\r\n" แล้วส่งทีเดียว
             * (&msg_len = ส่งที่อยู่ของ msg_len ให้ฟังก์ชันแก้ค่าได้) */
            Main_AppendStr(msg_buf, &msg_len, "Digits: ");
            Main_AppendDigit(msg_buf, &msg_len, SetupMode_GetTargetDigitCount());
            Main_AppendStr(msg_buf, &msg_len, "\r\n");
            UART_Driver_SendString(msg_buf);
            break;

        case SETUP_NOTIFY_CODE_START:
            UART_Driver_SendString("Enter code (short/long)\r\n");
            break;

        case SETUP_NOTIFY_CODE_SYMBOL:
        {
            /* 📘 วงเล็บปีกกา { } ใน case จำเป็นเมื่อต้องประกาศตัวแปรใหม่ใน case
             *    ตัวอย่างข้อความ: "Key 2: long"
             *    ( เงื่อนไข ? A : B ) = ถ้าจริงใช้ A ไม่จริงใช้ B (ternary operator) */
            uint8_t const entered_count = SetupMode_GetEnteredCount();
            CodeSymbol_t const last_symbol = SetupMode_GetEnteredSymbol((uint8_t) (entered_count - 1U));

            Main_AppendStr(msg_buf, &msg_len, "Key ");
            Main_AppendDigit(msg_buf, &msg_len, entered_count);
            Main_AppendStr(msg_buf, &msg_len, ": ");
            Main_AppendStr(msg_buf, &msg_len, (last_symbol == CODE_SYMBOL_LONG) ? "long" : "short");
            Main_AppendStr(msg_buf, &msg_len, "\r\n");
            UART_Driver_SendString(msg_buf);
            break;
        }

        case SETUP_NOTIFY_WARNING_NO_LENGTH:
            UART_Driver_SendString("WARNING: set digit count first\r\n");
            break;

        case SETUP_NOTIFY_WARNING_INCOMPLETE_CODE:
            UART_Driver_SendString("WARNING: code not complete yet\r\n");
            break;

        case SETUP_NOTIFY_COMMITTED:
        {
            uint8_t const digit_count = SetupMode_GetTargetDigitCount();

            Main_AppendStr(msg_buf, &msg_len, "SETUP SAVED: zone=");
            Main_AppendDigit(msg_buf, &msg_len, SetupMode_GetLastCommittedZone());
            Main_AppendStr(msg_buf, &msg_len, ", ");
            Main_AppendDigit(msg_buf, &msg_len, digit_count);
            Main_AppendStr(msg_buf, &msg_len, " digit, ");
            Main_AppendSymbolPattern(msg_buf, &msg_len, SetupMode_GetEnteredSymbol, digit_count);
            Main_AppendStr(msg_buf, &msg_len, "\r\n");
            UART_Driver_SendString(msg_buf);

            GPIO_Driver_WritePin(APP_LED_YELLOW_PORT, APP_LED_YELLOW_PIN, GPIO_PIN_RESET);
            break;
        }

        default:
            /* MISRA: default บังคับ - ไม่ควรเกิด */
            break;
    }
}

/**
 * @brief  คำสั่ง admin "SHOWPASS" — ส่งรหัสผ่านและโซนเป้าหมายปัจจุบันออก
 *         UART ในรูปแบบเดียวกับข้อความสรุปของ Setup Mode เช่น
 *         "PASS: zone=5, 4 digit, short-short-short-short"
 */
static void Main_SendCurrentPassword(void)
{
    char msg_buf[MAIN_UART_MSG_MAX_LEN];
    uint8_t msg_len = 0U;
    uint8_t const digit_count = CodeStorage_GetLength();

    Main_AppendStr(msg_buf, &msg_len, "PASS: zone=");
    Main_AppendDigit(msg_buf, &msg_len, DialLock_GetTargetZone());
    Main_AppendStr(msg_buf, &msg_len, ", ");
    Main_AppendDigit(msg_buf, &msg_len, digit_count);
    Main_AppendStr(msg_buf, &msg_len, " digit, ");
    Main_AppendSymbolPattern(msg_buf, &msg_len, CodeStorage_GetSymbol, digit_count);
    Main_AppendStr(msg_buf, &msg_len, "\r\n");

    UART_Driver_SendString(msg_buf);
}

/**
 * @brief  คำสั่ง admin "STATUS" — ส่งสถานะระบบ อุณหภูมิ และความสว่าง เช่น
 *         "STATUS: ACTIVE, temp=27.4C (normal 27.1C), light=312lux (normal 350lux)"
 *         ใช้ดูค่าจริงจากเซนเซอร์ตอนเดโม/ปรับเกณฑ์
 */
static void Main_SendStatus(void)
{
    char msg_buf[MAIN_UART_MSG_MAX_LEN];
    uint8_t msg_len = 0U;
    SystemMode_t const mode = SystemMode_Get();

    Main_AppendStr(msg_buf, &msg_len, "STATUS: ");

    if (mode == SYSTEM_MODE_ACTIVE)
    {
        Main_AppendStr(msg_buf, &msg_len, "ACTIVE");
    }
    else if (mode == SYSTEM_MODE_SLEEP)
    {
        Main_AppendStr(msg_buf, &msg_len, "SLEEP");
    }
    else
    {
        Main_AppendStr(msg_buf, &msg_len, "DISABLED");
    }

    Main_AppendStr(msg_buf, &msg_len, ", temp=");
    Main_AppendDeciC(msg_buf, &msg_len, EnvMonitor_GetTemperatureDeciC());
    Main_AppendStr(msg_buf, &msg_len, "C (normal ");
    Main_AppendDeciC(msg_buf, &msg_len, EnvMonitor_GetBaselineTemperatureDeciC());
    Main_AppendStr(msg_buf, &msg_len, "C), light=");
    Main_AppendUint(msg_buf, &msg_len, EnvMonitor_GetLux());
    Main_AppendStr(msg_buf, &msg_len, "lux (normal ");
    Main_AppendUint(msg_buf, &msg_len, EnvMonitor_GetBaselineLux());
    Main_AppendStr(msg_buf, &msg_len, "lux)\r\n");

    UART_Driver_SendString(msg_buf);
}

/** ต่อเลขจำนวนเต็มบวกหลายหลัก (ไม่ใช้ sprintf ตามแนว MISRA ของโปรเจค)
 *  📘 วิธีแปลงเลขเป็นตัวอักษร เช่น 312:
 *     รอบ 1: 312 % 10 = 2 -> '2', 312 / 10 = 31
 *     รอบ 2:  31 % 10 = 1 -> '1',  31 / 10 = 3
 *     รอบ 3:   3 % 10 = 3 -> '3',   3 / 10 = 0 (หยุด)
 *     ได้ "2","1","3" (กลับหลัง) จึงต้องวนถอยหลังตอนต่อ -> "312"
 *     '0' + 2 = '2' เพราะรหัส ASCII ของตัวเลข '0'-'9' เรียงติดกัน */
static void Main_AppendUint(char * const p_buf, uint8_t * const p_len, uint32_t value)
{
    char digits[10];
    uint8_t count = 0U;

    do
    {
        digits[count] = (char) ('0' + (char) (value % 10U));
        value /= 10U;
        count++;
    } while ((value > 0U) && (count < (uint8_t) sizeof(digits)));

    while (count > 0U)
    {
        count--;
        Main_AppendChar(p_buf, p_len, digits[count]);
    }
}

/** ต่ออุณหภูมิหน่วย 0.1 องศา เช่น 274 -> "27.4", -35 -> "-3.5" */
static void Main_AppendDeciC(char * const p_buf, uint8_t * const p_len, int32_t const deci_c)
{
    uint32_t magnitude;

    if (deci_c < 0)
    {
        Main_AppendChar(p_buf, p_len, '-');
        magnitude = (uint32_t) (-deci_c);
    }
    else
    {
        magnitude = (uint32_t) deci_c;
    }

    Main_AppendUint(p_buf, p_len, magnitude / 10U);
    Main_AppendChar(p_buf, p_len, '.');
    Main_AppendDigit(p_buf, p_len, (uint8_t) (magnitude % 10U));
}

/**
 * @brief  ต่อรูปแบบรหัส "short-long-..." ลง buffer โดยอ่านสัญลักษณ์ทีละตัว
 *         ผ่านฟังก์ชัน get_symbol (ใช้ร่วมกันทั้ง SHOWPASS และสรุป Setup Mode)
 */
static void Main_AppendSymbolPattern(char * const p_buf, uint8_t * const p_len,
                                     CodeSymbol_t (*get_symbol)(uint8_t), uint8_t const count)
{
    uint8_t i;

    for (i = 0U; i < count; i++)
    {
        if (i > 0U)
        {
            Main_AppendChar(p_buf, p_len, '-');
        }
        else
        {
            /* ตัวแรก - ไม่ต้องใส่ขีดคั่น */
        }

        Main_AppendStr(p_buf, p_len, (get_symbol(i) == CODE_SYMBOL_LONG) ? "long" : "short");
    }
}

/* ------------------------------------------------------------------------
 * ตัวช่วยประกอบข้อความ UART (เฉพาะตัวเลขหลักเดียว 0-9 พอ เพราะทุกค่า
 * dynamic ที่ต้องแสดงใน Setup Mode เป็นเลขหลักเดียวทั้งหมด) — จำเป็นต้อง
 * ประกอบให้เสร็จใน buffer เดียวก่อนค่อยเรียก UART_Driver_SendString()
 * เพราะฟังก์ชันนั้นไม่มี message queue (เรียกซ้ำก่อนส่งจบจะถูกทิ้ง)
 * ------------------------------------------------------------------------ */
/* ต่อ 1 ตัวอักษรท้าย buffer แล้วปิดท้ายด้วย '\0' เสมอ (ข้อความจึงพร้อมส่งได้ตลอด)
 * *p_len = อ่านค่าความยาวผ่าน pointer, (*p_len)++ = เพิ่มความยาวของผู้เรียก */
static void Main_AppendChar(char * const p_buf, uint8_t * const p_len, char const c)
{
    if (*p_len < (uint8_t) (MAIN_UART_MSG_MAX_LEN - 1U))
    {
        p_buf[*p_len] = c;
        (*p_len)++;
    }
    else
    {
        /* buffer เต็ม - ทิ้งอักขระส่วนเกิน (ป้องกัน overflow) */
    }
    p_buf[*p_len] = '\0';
}

/* ต่อข้อความทั้งก้อน (เรียก AppendChar ทีละตัวจนเจอ '\0') */
static void Main_AppendStr(char * const p_buf, uint8_t * const p_len, char const * const p_str)
{
    uint8_t i = 0U;

    while (p_str[i] != '\0')
    {
        Main_AppendChar(p_buf, p_len, p_str[i]);
        i++;
    }
}

/* ต่อเลขหลักเดียว 0-9 (เกิน 9 จะถูกบีบเป็น 9) */
static void Main_AppendDigit(char * const p_buf, uint8_t * const p_len, uint8_t const digit)
{
    uint8_t const clamped = (digit > 9U) ? 9U : digit;

    Main_AppendChar(p_buf, p_len, (char) ('0' + clamped));
}

/**
 * @brief  เรียกจาก USART2 ISR (ผ่าน callback ที่ลงทะเบียนไว้ตอน
 *         UART_Driver_Init) ทุกครั้งที่รับ byte ใหม่ 1 ตัว — สะสมเป็น
 *         บรรทัดคำสั่งจนกว่าจะเจอ '\r' หรือ '\n' แล้วตีความผ่าน
 *         admin_command ทันทีภายใน ISR context (การทำงานสั้นและไม่
 *         blocking ทั้งหมด ปลอดภัยที่จะทำใน ISR)
 */
static void Main_UartRxHandler(uint8_t const received_byte)
{
    /* 📘 ตัวอย่าง: admin พิมพ์ S-T-A-T-U-S แล้วกด Enter
     *    ตัวอักษรมาทีละตัว (ฟังก์ชันนี้ถูกเรียก 7 ครั้ง):
     *      'S' -> buffer = "S"       ... 'S' -> buffer = "STATUS"
     *      '\r' (Enter) -> ปิดท้าย '\0' -> Parse("STATUS") -> ทำคำสั่ง -> ล้าง buffer
     *    ⚠ ไม่มีการ echo ตัวอักษรกลับ: ตอนพิมพ์อาจไม่เห็นตัวอักษรบนจอ terminal
     *      (เปิด "local echo" ในโปรแกรม terminal ถ้าอยากเห็น) */
    if ((received_byte == (uint8_t) '\r') || (received_byte == (uint8_t) '\n'))
    {
        if (s_admin_line_index > 0U)
        {
            AdminCommand_t cmd;

            s_admin_line_buffer[s_admin_line_index] = '\0';
            cmd = AdminCommand_Parse(s_admin_line_buffer);

            switch (cmd)
            {
                case ADMIN_CMD_UNLOCK:
                    SystemMode_OnUserActivity();   /* ปลุกถ้าหลับอยู่ */
                    LockFsm_ForceUnlock();
                    UART_Driver_SendString("OK: Unlocked\r\n");
                    break;

                case ADMIN_CMD_LOCKOUT:
                    SystemMode_OnUserActivity();
                    LockFsm_ForceLockout();
                    UART_Driver_SendString("OK: Lockout engaged\r\n");
                    break;

                case ADMIN_CMD_RESET:
                    if (SystemMode_Get() == SYSTEM_MODE_DISABLED)
                    {
                        /* ตอน DISABLED: RESET ทำหน้าที่ "ล้าง alarm อุณหภูมิ"
                         * อย่างเดียว — รหัสและโซนที่ตั้งไว้จาก Setup Mode
                         * ต้องอยู่ครบ (ระบบถูกระงับชั่วคราว ไม่ได้แปลว่ารหัส
                         * เสียหาย) ถ้ายังผิดปกติอยู่ alarm จะเกิดใหม่ภายใน
                         * ~0.6 วินาที */
                        EnvMonitor_ClearTamper();
                        SystemMode_ClearTamper();
                        UART_Driver_SendString("OK: Temperature alarm cleared (code unchanged)\r\n");
                    }
                    else
                    {
                        /* ตอนใช้งานปกติ: คืนรหัสและโซนเป็นค่า default เหมือนเดิม */
                        LockFsm_ResetToDefault();
                        SystemMode_OnUserActivity();
                        UART_Driver_SendString("OK: Code reset to default\r\n");
                    }
                    break;

                case ADMIN_CMD_SHOWPASS:
                    Main_SendCurrentPassword();
                    break;

                case ADMIN_CMD_STATUS:
                    Main_SendStatus();
                    break;

                default:
                    /* ADMIN_CMD_UNKNOWN - พิมพ์ผิดหรือคำสั่งไม่รองรับ */
                    UART_Driver_SendString("ERROR: Unknown command\r\n");
                    break;
            }

            s_admin_line_index = 0U;
        }
        else
        {
            /* บรรทัดว่างเปล่า (กด Enter ติดกันหรือ \r\n มาคนละ byte) - ไม่ทำอะไร */
        }
    }
    else if (s_admin_line_index < (MAIN_ADMIN_LINE_MAX_LEN - 1U))
    {
        /* ตัวอักษรธรรมดา -> เก็บต่อท้าย (เว้นช่องสุดท้ายไว้ใส่ '\0') */
        s_admin_line_buffer[s_admin_line_index] = (char) received_byte;
        s_admin_line_index++;
    }
    else
    {
        /* บรรทัดยาวเกินไป - ทิ้งตัวอักษรส่วนเกิน (ป้องกัน buffer overflow) */
    }
}

/**
 * @brief  เรียกจาก ADC ISR ทุกครั้งที่แปลงค่า potentiometer เสร็จ 1 ครั้ง
 *         (continuous mode ทำงานต่อเนื่องตลอดเวลา) — อัพเดตค่าให้ dial_lock
 *         แล้วถ้าตอนนี้ยังไม่ได้เริ่มป้อนรหัส (สถานะ IDLE) ให้โชว์โซน
 *         ปัจจุบันบน 7-segment เพื่อช่วยให้ผู้ใช้หมุนหาตำแหน่งได้
 */
static void Main_AdcEocHandler(uint16_t const raw_value)
{
    DialLock_UpdateRaw(raw_value);

    if ((LockFsm_GetState() == LOCK_STATE_IDLE) && (SystemMode_Get() == SYSTEM_MODE_ACTIVE))
    {
        SevenSegment_Driver_ShowDigit(DialLock_GetCurrentZone());
    }
    else
    {
        /* กำลังป้อนรหัสหรืออยู่สถานะอื่น - จอ 7-segment ถูกใช้แสดงอย่างอื่น
         * อยู่แล้ว (จำนวนหลักที่กด/lockout countdown) ไม่ไปแตะ */
    }
}

/**
 * @brief  เรียกจาก ADC ISR เมื่อ Analog Watchdog ตรวจพบว่า potentiometer
 *         หลุดออกจากโซน (ที่อยู่ตอนกดปุ่มแรก) (เปิดใช้งานเฉพาะตอนสถานะ ENTERING เท่านั้น
 *         ผ่าน Main_LockNotifyHandler) ส่งต่อให้ lock_fsm ยกเลิกรอบนี้ทันที
 */
static void Main_AdcWatchdogHandler(void)
{
    LockFsm_OnDialViolation();
}

/**
 * @brief  เรียกจาก ADC ISR (JEOC) ทุก 200ms เมื่ออ่าน NTC + LDR เสร็จ
 */
static void Main_AdcInjectedHandler(uint16_t const ntc_raw, uint16_t const ldr_raw)
{
    EnvMonitor_OnSample(ntc_raw, ldr_raw);
}

/* env_monitor แจ้งว่าอุณหภูมิผิดปกติ -> ส่งต่อให้ system_mode เข้า DISABLED
 * (แยก 2 module เพราะ env_monitor = "ตรวจจับ", system_mode = "ตัดสินสถานะระบบ") */
static void Main_EnvNotifyHandler(EnvMonitor_Notification_t const notification)
{
    switch (notification)
    {
        case ENV_NOTIFY_TAMPER_DETECTED:
            SystemMode_OnTamper();
            break;

        default:
            /* MISRA: default บังคับ */
            break;
    }
}

/**
 * @brief  รับการกดปุ่มหรือไม่: รับเฉพาะตอน ACTIVE และนับเป็น "มีคนใช้งาน"
 *         (รีเซ็ตเวลานับเข้า sleep)
 *         หมายเหตุ: ตอน SLEEP การกดปุ่มจะไม่ถูกรับ และ SystemMode_OnUserActivity
 *         ไม่ถูกเรียกด้วย -> ปุ่มปลุกเครื่องไม่ได้ ต้องบังแสง LDR (หรือคำสั่ง UART)
 */
static bool Main_AcceptUserInput(void)
{
    bool result;

    if (SystemMode_Get() == SYSTEM_MODE_ACTIVE)
    {
        SystemMode_OnUserActivity();
        result = true;
    }
    else
    {
        result = false;
    }

    return result;
}

/**
 * @brief  แสดงผลเมื่อสถานะระบบเปลี่ยน (ACTIVE / SLEEP / DISABLED)
 */
static void Main_SystemNotifyHandler(SystemMode_Notification_t const notification)
{
    char msg_buf[MAIN_UART_MSG_MAX_LEN];
    uint8_t msg_len = 0U;

    switch (notification)
    {
        case SYSTEM_NOTIFY_ENTER_SLEEP:
            /* ดับทุกอย่าง + หยุดอ่าน potentiometer ต่อเนื่อง ให้เหลือ
             * interrupt น้อยที่สุด CPU จะได้หลับใน WFI เกือบตลอด */
            GPIO_Driver_WritePin(APP_LED_GREEN_PORT, APP_LED_GREEN_PIN, GPIO_PIN_RESET);
            GPIO_Driver_WritePin(APP_LED_RED_PORT, APP_LED_RED_PIN, GPIO_PIN_RESET);
            GPIO_Driver_WritePin(APP_LED_G_PORT, APP_LED_G_PIN, GPIO_PIN_RESET);
            GPIO_Driver_WritePin(APP_LED_YELLOW_PORT, APP_LED_YELLOW_PIN, GPIO_PIN_RESET);
            SevenSegment_Driver_Blank();
            ADC_Driver_PauseRegular();
            UART_Driver_SendString("SLEEP: nobody nearby\r\n");
            break;

        case SYSTEM_NOTIFY_WAKE:
            /* กลับมาอ่าน potentiometer -> 7-segment จะแสดงโซนเองจาก EOC */
            ADC_Driver_ResumeRegular();
            UART_Driver_SendString("WAKE: ready\r\n");
            break;

        case SYSTEM_NOTIFY_ENTER_DISABLED:
            /* ยกเลิกทุกอย่างที่ค้างอยู่ (Setup Mode, การกรอกรหัส, ปลดล็อก
             * ค้าง) แล้วปฏิเสธปุ่มทั้งหมดจนกว่า admin จะ RESET */
            if (SetupMode_GetState() != SETUP_STATE_INACTIVE)
            {
                SetupMode_Cancel();
            }
            else
            {
                /* ไม่ได้อยู่ใน Setup Mode */
            }
            LockFsm_ForceIdle();
            ADC_Driver_ResumeRegular();   /* เผื่อเกิดตอนกำลัง sleep อยู่ */

            s_green_blink_ticks_remaining = 0U;
            s_red_blink_ticks_remaining = 0U;
            GPIO_Driver_WritePin(APP_LED_GREEN_PORT, APP_LED_GREEN_PIN, GPIO_PIN_RESET);
            GPIO_Driver_WritePin(APP_LED_G_PORT, APP_LED_G_PIN, GPIO_PIN_RESET);
            GPIO_Driver_WritePin(APP_LED_YELLOW_PORT, APP_LED_YELLOW_PIN, GPIO_PIN_RESET);
            GPIO_Driver_WritePin(APP_LED_RED_PORT, APP_LED_RED_PIN, GPIO_PIN_SET);
            SevenSegment_Driver_Blank();

            Main_AppendStr(msg_buf, &msg_len, "ALERT: TEMP ABNORMAL ");
            Main_AppendDeciC(msg_buf, &msg_len, EnvMonitor_GetTemperatureDeciC());
            Main_AppendStr(msg_buf, &msg_len, "C (normal ");
            Main_AppendDeciC(msg_buf, &msg_len, EnvMonitor_GetBaselineTemperatureDeciC());
            Main_AppendStr(msg_buf, &msg_len, "C) - keypad disabled, send RESET\r\n");
            UART_Driver_SendString(msg_buf);
            break;

        case SYSTEM_NOTIFY_EXIT_DISABLED:
            GPIO_Driver_WritePin(APP_LED_RED_PORT, APP_LED_RED_PIN, GPIO_PIN_RESET);
            break;

        default:
            /* MISRA: default บังคับ */
            break;
    }
}
