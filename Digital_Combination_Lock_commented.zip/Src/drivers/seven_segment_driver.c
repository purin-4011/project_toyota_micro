/******************************************************************************
 * @file    seven_segment_driver.c
 * @brief   Implementation ของ 7-segment BCD driver
 *          ใช้ gpio_driver เป็นชั้นล่าง (ไม่แตะ register ตรงๆ ในไฟล์นี้)
 *
 * 📘 สังเกตว่าไฟล์นี้ไม่มี REG32 เลย — มันเรียกฟังก์ชันของ gpio_driver แทน
 *    นี่คือการ "ซ้อนชั้น" (layering): 7-segment อยู่บน GPIO อีกที
 ******************************************************************************/
#include "seven_segment_driver.h"
#include "gpio_driver.h"
#include "app_config.h"    /* มีชื่อขา APP_SEG_BCD_A..D */

#define SEVEN_SEGMENT_MAX_DIGIT   (9U)
/* mask ของแต่ละบิต BCD:  A = 2^0 = 0001, B = 2^1 = 0010, C = 2^2 = 0100, D = 2^3 = 1000 */
#define SEVEN_SEGMENT_BIT_A       (0x1U)
#define SEVEN_SEGMENT_BIT_B       (0x2U)
#define SEVEN_SEGMENT_BIT_C       (0x4U)
#define SEVEN_SEGMENT_BIT_D       (0x8U)

/** แปลง bit เป็น GPIO_PinState_t (0/1 -> RESET/SET)
 *  ตัวอย่าง: value = 5 (0101), bit_mask = 0x4 (0100) -> 0101 & 0100 = 0100 ≠ 0 -> SET
 *  📘 static ฟังก์ชัน = ใช้ได้เฉพาะในไฟล์นี้ (ฟังก์ชันผู้ช่วยภายใน) */
static GPIO_PinState_t SevenSegment_BitToPinState(uint8_t const value, uint8_t const bit_mask)
{
    GPIO_PinState_t result;

    if ((value & bit_mask) != 0U)
    {
        result = GPIO_PIN_SET;
    }
    else
    {
        result = GPIO_PIN_RESET;
    }

    return result;
}

void SevenSegment_Driver_Init(void)
{
    /* ขา BCD 4 ขาอยู่กระจาย 3 port (C, A, B, A) จึงเปิด clock ทีละขา
     * (เปิด clock port เดิมซ้ำไม่มีผลเสีย) แล้วตั้งเป็น output ไม่มี pull */
    GPIO_Driver_EnableClock(APP_SEG_BCD_A_PORT);
    GPIO_Driver_Init(APP_SEG_BCD_A_PORT, APP_SEG_BCD_A_PIN, GPIO_MODE_OUTPUT, GPIO_PULL_NONE);

    GPIO_Driver_EnableClock(APP_SEG_BCD_B_PORT);
    GPIO_Driver_Init(APP_SEG_BCD_B_PORT, APP_SEG_BCD_B_PIN, GPIO_MODE_OUTPUT, GPIO_PULL_NONE);

    GPIO_Driver_EnableClock(APP_SEG_BCD_C_PORT);
    GPIO_Driver_Init(APP_SEG_BCD_C_PORT, APP_SEG_BCD_C_PIN, GPIO_MODE_OUTPUT, GPIO_PULL_NONE);

    GPIO_Driver_EnableClock(APP_SEG_BCD_D_PORT);
    GPIO_Driver_Init(APP_SEG_BCD_D_PORT, APP_SEG_BCD_D_PIN, GPIO_MODE_OUTPUT, GPIO_PULL_NONE);

    SevenSegment_Driver_ShowDigit(0U);   /* เริ่มต้นแสดงเลข 0 */
}

void SevenSegment_Driver_Blank(void)
{
    /* ส่ง 1111 ตรงๆ (ไม่ผ่าน ShowDigit เพราะ ShowDigit clamp ค่าไว้ไม่เกิน 9) */
    GPIO_Driver_WritePin(APP_SEG_BCD_A_PORT, APP_SEG_BCD_A_PIN, GPIO_PIN_SET);
    GPIO_Driver_WritePin(APP_SEG_BCD_B_PORT, APP_SEG_BCD_B_PIN, GPIO_PIN_SET);
    GPIO_Driver_WritePin(APP_SEG_BCD_C_PORT, APP_SEG_BCD_C_PIN, GPIO_PIN_SET);
    GPIO_Driver_WritePin(APP_SEG_BCD_D_PORT, APP_SEG_BCD_D_PIN, GPIO_PIN_SET);
}

void SevenSegment_Driver_ShowDigit(uint8_t digit)
{
    /* กันค่าเกิน 9 (BCD แสดงได้แค่ 0-9) */
    if (digit > SEVEN_SEGMENT_MAX_DIGIT)
    {
        digit = SEVEN_SEGMENT_MAX_DIGIT;
    }
    else
    {
        /* อยู่ในช่วง 0-9 แล้ว ไม่ต้องปรับ */
    }

    /* แตกเลขออกเป็น 4 บิต แล้วส่งออกไปทีละขา
     * ตัวอย่าง digit = 6 (0110): A=0, B=1, C=1, D=0 -> จอแสดง "6" */
    GPIO_Driver_WritePin(APP_SEG_BCD_A_PORT, APP_SEG_BCD_A_PIN,
                          SevenSegment_BitToPinState(digit, SEVEN_SEGMENT_BIT_A));
    GPIO_Driver_WritePin(APP_SEG_BCD_B_PORT, APP_SEG_BCD_B_PIN,
                          SevenSegment_BitToPinState(digit, SEVEN_SEGMENT_BIT_B));
    GPIO_Driver_WritePin(APP_SEG_BCD_C_PORT, APP_SEG_BCD_C_PIN,
                          SevenSegment_BitToPinState(digit, SEVEN_SEGMENT_BIT_C));
    GPIO_Driver_WritePin(APP_SEG_BCD_D_PORT, APP_SEG_BCD_D_PIN,
                          SevenSegment_BitToPinState(digit, SEVEN_SEGMENT_BIT_D));
}
