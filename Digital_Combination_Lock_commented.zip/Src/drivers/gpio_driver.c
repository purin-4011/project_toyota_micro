/******************************************************************************
 * @file    gpio_driver.c
 * @brief   Implementation ของ GPIO driver (register-level, raw address)
 *
 * 📘 ไฟล์นี้คือ "วิธีทำจริง" ของฟังก์ชันที่ประกาศไว้ใน gpio_driver.h
 *    เป็นไฟล์ที่ควรอ่านเป็นไฟล์แรก เพราะเทคนิค bit manipulation (การแก้ค่า
 *    ทีละบิตใน register) ที่อธิบายละเอียดไว้ที่นี่ ถูกใช้ซ้ำในทุก driver
 ******************************************************************************/
#include "gpio_driver.h"

/* ---------------------------------------------------------------------- *
 * Register offset ภายใน GPIO port (เหมือนกันทุก port ต่างกันแค่ base address)
 * อ้างอิง RM0383 Section 6.4 (GPIO registers)
 *
 * 📘 register แต่ละตัวมีหน้าที่ต่างกัน (แต่ละตัวกว้าง 32 บิต):
 *   MODER (0x00) : ตั้งโหมดของแต่ละขา — ใช้ 2 บิตต่อขา x 16 ขา = 32 บิตพอดี
 *   PUPDR (0x0C) : ตั้ง pull-up/pull-down — 2 บิตต่อขา เหมือน MODER
 *   IDR   (0x10) : Input Data Register — อ่านค่าขาเข้า (1 บิตต่อขา)
 *   ODR   (0x14) : Output Data Register — ค่าที่ขาออกกำลังจ่าย (1 บิตต่อขา)
 *   BSRR  (0x18) : Bit Set/Reset Register — ใช้สั่ง set/reset ขาออกแบบปลอดภัย
 * ---------------------------------------------------------------------- */
#define GPIO_OFFSET_MODER    (0x00UL)
#define GPIO_OFFSET_PUPDR    (0x0CUL)
#define GPIO_OFFSET_IDR      (0x10UL)
#define GPIO_OFFSET_ODR      (0x14UL)
#define GPIO_OFFSET_BSRR     (0x18UL)

/* ---------------------------------------------------------------------- *
 * RCC (สำหรับเปิด clock ของแต่ละ GPIO port) — RM0383 Section 6.3.10
 * 📘 RCC = Reset and Clock Control = "สวิตช์ไฟกลาง" ที่ควบคุมว่า peripheral
 *    ตัวไหนได้รับ clock บ้าง GPIO อยู่บนบัส AHB1 จึงเปิดที่ register AHB1ENR
 *    บิต 0 = GPIOA, บิต 1 = GPIOB, บิต 2 = GPIOC
 * ---------------------------------------------------------------------- */
#define RCC_BASE             (0x40023800UL)
#define RCC_OFFSET_AHB1ENR   (0x30UL)
#define RCC_AHB1ENR_GPIOAEN_BIT (0U)
#define RCC_AHB1ENR_GPIOBEN_BIT (1U)
#define RCC_AHB1ENR_GPIOCEN_BIT (2U)

/** Macro ช่วยแปลง address ธรรมดาให้เป็น volatile 32-bit register access
 *  (คือหัวใจของเทคนิค memory-mapped I/O ที่สอนใน Chapter 0.4)
 *
 *  📘 แกะทีละส่วน: *(volatile uint32_t *)(addr)
 *     (uint32_t *)(addr)  = บอก compiler ว่า "เลข addr นี้คือตำแหน่งของ
 *                           ข้อมูลขนาด 32 บิต" (แปลงเลขให้เป็น pointer)
 *     *(...)              = เข้าไปอ่าน/เขียนข้อมูลที่ตำแหน่งนั้น
 *     volatile            = สำคัญมาก! บอก compiler ว่า "ค่าที่ตำแหน่งนี้
 *                           เปลี่ยนเองได้โดยฮาร์ดแวร์ ห้ามเดาหรือ optimize
 *                           ตัดการอ่าน/เขียนทิ้ง" ไม่งั้น compiler อาจคิดว่า
 *                           อ่านค่าเดิมซ้ำไม่จำเป็น แล้วข้ามไป
 *
 *  ผลคือเขียน REG32(0x40020014) = 5; ได้เหมือนเป็นตัวแปรธรรมดา
 *  แต่จริงๆ คือส่งค่าเข้าฮาร์ดแวร์โดยตรง */
#define REG32(addr)  (*(volatile uint32_t *)(addr))

#define GPIO_BITS_PER_PIN  (2U)     /* MODER/PUPDR ใช้ 2 บิตต่อ 1 ขา */
#define GPIO_FIELD_MASK    (0x3UL)  /* 0x3 = เลขฐานสอง 11 = mask ขนาด 2 บิต */
#define GPIO_INVALID_BIT   (0xFFU)  /* ค่าพิเศษไว้บอกว่า "port ไม่รู้จัก" */

/* ---------------------------------------------------------------------- *
 * Public function implementations
 * ---------------------------------------------------------------------- */

void GPIO_Driver_EnableClock(uint32_t const port_base)
{
    /* 📘 "const" ในพารามิเตอร์ = สัญญาว่าฟังก์ชันนี้จะไม่แก้ค่า port_base
     *    (กันเขียนทับโดยไม่ตั้งใจ) */
    uint32_t clk_bit;

    /* ขั้นที่ 1: ดูว่าเป็น port ไหน แล้วเลือกเลขบิตที่ต้องเปิดใน AHB1ENR */
    if (port_base == GPIOA_BASE)
    {
        clk_bit = RCC_AHB1ENR_GPIOAEN_BIT;
    }
    else if (port_base == GPIOB_BASE)
    {
        clk_bit = RCC_AHB1ENR_GPIOBEN_BIT;
    }
    else if (port_base == GPIOC_BASE)
    {
        clk_bit = RCC_AHB1ENR_GPIOCEN_BIT;
    }
    else
    {
        clk_bit = GPIO_INVALID_BIT;
    }

    /* ขั้นที่ 2: เปิดบิตนั้น
     * 📘 เทคนิค "Set bit" : REG |= (1UL << n);
     *    (1UL << n) = เลข 1 แล้วเลื่อนไปทางซ้าย n ตำแหน่ง
     *                 เช่น n=1 -> 0b...0010 (มีบิตที่ 1 เป็น 1 ตัวเดียว)
     *    |=  (OR แล้วเก็บ) = ทำให้บิตที่ n กลายเป็น 1 โดย "ไม่ไปยุ่ง" บิตอื่น
     *    สำคัญเพราะ AHB1ENR ใช้เปิด clock ของหลาย peripheral ร่วมกัน
     *    ถ้าเขียน = ตรงๆ จะไปปิด clock ตัวอื่นที่เปิดไว้แล้วหมด */
    if (clk_bit != GPIO_INVALID_BIT)
    {
        REG32(RCC_BASE + RCC_OFFSET_AHB1ENR) |= (1UL << clk_bit);
    }
    else
    {
        /* MISRA: else บังคับ — port ที่ไม่รองรับ (โปรเจคนี้ใช้แค่ A/B/C) */
    }
}

void GPIO_Driver_Init(uint32_t const port_base,
                       uint8_t const pin,
                       GPIO_Mode_t const mode,
                       GPIO_Pull_t const pull)
{
    /* แต่ละขากิน 2 บิตใน MODER: ขา 0 อยู่บิต [1:0], ขา 1 อยู่บิต [3:2], ...
     * ดังนั้นขา n เริ่มที่บิต n*2 เช่น ขา 5 -> เริ่มบิต 10 (บิต [11:10]) */
    uint32_t const shift = (uint32_t) pin * GPIO_BITS_PER_PIN;
    uint32_t moder_val;
    uint32_t pupdr_val;

    /* 📘 เทคนิค "Read-Modify-Write" (อ่าน -> แก้ -> เขียนกลับ) — ใช้บ่อยมาก
     *    เพราะเราอยากเปลี่ยนแค่ 2 บิตของขาเรา โดยไม่ทำลายการตั้งค่าของ
     *    ขาอื่นอีก 15 ขาที่อยู่ใน register เดียวกัน
     *
     *    1) moder_val = REG32(...)                -> อ่านค่าเดิมทั้ง 32 บิตมาก่อน
     *    2) moder_val &= ~(0x3 << shift)          -> ล้าง 2 บิตของขาเราให้เป็น 00
     *         (0x3 << shift) = 11 ที่ตำแหน่งขาเรา, ~ = กลับบิต (ตรงนั้นเป็น 00
     *         ที่อื่นเป็น 1 หมด), &= = AND -> บิตที่ AND กับ 0 กลายเป็น 0,
     *         บิตที่ AND กับ 1 คงค่าเดิม
     *    3) moder_val |= (mode << shift)          -> ใส่ค่าใหม่ลงช่องที่ล้างไว้
     *    4) REG32(...) = moder_val                -> เขียนกลับลงฮาร์ดแวร์
     *
     *    ตัวอย่างขา 5 ตั้งเป็น output (01): ล้างบิต 11:10 เป็น 00 แล้วใส่ 01 */
    moder_val = REG32(port_base + GPIO_OFFSET_MODER);
    moder_val &= ~(GPIO_FIELD_MASK << shift);
    moder_val |= ((uint32_t) mode << shift);
    REG32(port_base + GPIO_OFFSET_MODER) = moder_val;

    /* ทำแบบเดียวกันกับ PUPDR (pull-up/down) */
    pupdr_val = REG32(port_base + GPIO_OFFSET_PUPDR);
    pupdr_val &= ~(GPIO_FIELD_MASK << shift);
    pupdr_val |= ((uint32_t) pull << shift);
    REG32(port_base + GPIO_OFFSET_PUPDR) = pupdr_val;
}

void GPIO_Driver_WritePin(uint32_t const port_base,
                           uint8_t const pin,
                           GPIO_PinState_t const state)
{
    /* 📘 BSRR ทำงานแปลกกว่า register อื่น:
     *    - เขียน 1 ที่บิต 0-15  -> ขานั้น "ติด" (SET = 3.3V)
     *    - เขียน 1 ที่บิต 16-31 -> ขา (บิต-16) "ดับ" (RESET = 0V)
     *    - บิตที่เขียน 0 = ไม่มีผลอะไรเลย
     *    จึงใช้ "=" ตรงๆ ได้ ไม่ต้อง read-modify-write ขาอื่นไม่ได้รับผลกระทบ
     *
     *    ทำไมดีกว่าแก้ ODR? การแก้ ODR ต้องอ่าน-แก้-เขียน 3 จังหวะ ถ้ามี
     *    interrupt แทรกกลางคันแล้วไปแก้ขาอื่นใน port เดียวกัน ค่าที่ ISR
     *    เขียนไว้อาจถูกเขียนทับหาย BSRR ทำในจังหวะเดียว (atomic) จึงไม่มีปัญหานี้ */
    if (state == GPIO_PIN_SET)
    {
        /* เขียนครึ่งล่างของ BSRR = SET (atomic, ปลอดภัยกว่า read-modify-write ODR) */
        REG32(port_base + GPIO_OFFSET_BSRR) = (1UL << pin);
    }
    else
    {
        /* เขียนครึ่งบนของ BSRR (bit 16-31) = RESET  เช่นขา 5 -> บิต 21 */
        REG32(port_base + GPIO_OFFSET_BSRR) = (1UL << (pin + 16U));
    }
}

void GPIO_Driver_TogglePin(uint32_t const port_base, uint8_t const pin)
{
    /* 📘 ^= (XOR แล้วเก็บ) = กลับค่าเฉพาะบิตที่ n: 0 -> 1, 1 -> 0
     *    บิตอื่นที่ XOR กับ 0 คงค่าเดิม
     *    หมายเหตุ: อันนี้เป็น read-modify-write บน ODR (ไม่ atomic) แต่โปรเจคนี้
     *    เรียก toggle จาก TIM3 ISR ที่เดียว (LED แดงตอน DISABLED) จึงไม่มีปัญหา */
    REG32(port_base + GPIO_OFFSET_ODR) ^= (1UL << pin);
}

GPIO_PinState_t GPIO_Driver_ReadPin(uint32_t const port_base, uint8_t const pin)
{
    GPIO_PinState_t result;
    uint32_t const idr_val = REG32(port_base + GPIO_OFFSET_IDR);  /* อ่านค่าขาเข้าทั้ง 16 ขา */

    /* 📘 เทคนิค "Test bit": (ค่า & (1 << n)) != 0
     *    AND กับ mask ที่มี 1 แค่บิตเดียว -> ถ้าผลไม่เป็น 0 แปลว่าบิตนั้นเป็น 1 */
    if ((idr_val & (1UL << pin)) != 0U)
    {
        result = GPIO_PIN_SET;
    }
    else
    {
        result = GPIO_PIN_RESET;
    }

    /* MISRA แนะนำให้มี return จุดเดียวท้ายฟังก์ชัน จึงเก็บใส่ result ก่อน */
    return result;
}
