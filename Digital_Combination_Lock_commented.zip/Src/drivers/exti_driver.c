/******************************************************************************
 * @file    exti_driver.c
 * @brief   Implementation ของ EXTI driver (register-level, raw address)
 *          สำหรับปุ่มทั้ง 4 ตัว — แต่ละฟังก์ชัน Init เขียนแบบคัดลอกจากของ
 *          เดิม (PB4/EXTI4) ที่ทดสอบผ่านแล้ว แล้วปรับ port/pin/IRQ ตามปุ่ม
 *          ใหม่ทีละตัว (ไม่ใช้ generic function ตัวเดียวรองรับทุกขา)
 *
 * 📘 วิธีอ่านไฟล์นี้: อ่านคู่แรก (EXTI_Driver_Init + EXTI4_IRQHandler) ให้
 *    เข้าใจละเอียด เพราะอีก 3 คู่ที่เหลือ "เหมือนกันทุกขั้นตอน" ต่างแค่
 *    port / เลขขา / ตำแหน่งใน SYSCFG / ชื่อ IRQ
 *
 *    ขั้นตอนตั้งค่าปุ่ม 1 ตัวให้สร้าง interrupt ได้ มี 6 ขั้น:
 *      1) เปิด clock ของ GPIO port และ SYSCFG
 *      2) ตั้งขาเป็น input + pull-up
 *      3) บอก SYSCFG ว่า EXTI line นี้ให้ฟังขาจาก port ไหน
 *      4) เลือกว่าจะจับ edge แบบไหน (rising / falling / ทั้งคู่)
 *      5) ปลด mask ให้ EXTI line นี้ส่ง interrupt ได้
 *      6) ตั้ง priority และเปิด interrupt ที่ NVIC
 ******************************************************************************/
#include "exti_driver.h"
#include "stm32f411xe.h"   /* ต้องใช้เฉพาะ IRQn_Type enum + NVIC_EnableIRQ()
                             * ตามที่สไลด์ 0500_Interrupts.pdf ระบุชัดว่า
                             * "ต้องใช้ CMSIS" สำหรับตั้งค่า NVIC โดยเฉพาะ
                             * (peripheral register อื่นด้านล่างยังคง define
                             *  แบบ raw address ตามที่สอนใน 0100_GPIO.pdf)
                             * 📘 CMSIS = ไลบรารีมาตรฐานของ ARM ที่ให้ชื่อ
                             *    เช่น EXTI4_IRQn และฟังก์ชัน NVIC_EnableIRQ() */

#define REG32(addr)  (*(volatile uint32_t *)(addr))   /* ดูคำอธิบายใน gpio_driver.c */

/* --- GPIOA/GPIOB (อ้างอิง RM0383 Section 6.4) ---
 * ไฟล์นี้ไม่เรียก gpio_driver แต่เขียน register เอง (ตั้งใจคงโค้ดเดิมที่ทดสอบแล้ว) */
#define GPIOA_BASE               (0x40020000UL)
#define GPIOB_BASE               (0x40020400UL)
#define GPIO_OFFSET_MODER        (0x00UL)
#define GPIO_OFFSET_PUPDR        (0x0CUL)
#define GPIO_OFFSET_IDR          (0x10UL)

/* --- RCC (Section 6.3) ---
 * GPIO อยู่บนบัส AHB1 แต่ SYSCFG อยู่บนบัส APB2 จึงต้องเปิด clock คนละ register */
#define RCC_BASE                 (0x40023800UL)
#define RCC_OFFSET_AHB1ENR       (0x30UL)
#define RCC_OFFSET_APB2ENR       (0x44UL)
#define RCC_AHB1ENR_GPIOAEN_BIT  (0U)
#define RCC_AHB1ENR_GPIOBEN_BIT  (1U)
#define RCC_APB2ENR_SYSCFGEN_BIT (14U)

/* --- SYSCFG (Section 8.2) : ผูก EXTI line เข้ากับ GPIO port ---
 * 📘 EXTI line 4 เป็นได้ทั้ง PA4, PB4, PC4 ... แต่เลือกได้ทีละ port เดียว
 *    SYSCFG_EXTICRx คือที่ "เลือก port" แต่ละ line ใช้ 4 บิต (1 nibble)
 *    register ละ 4 line:
 *       EXTICR1 = line 0,1,2,3   EXTICR2 = line 4,5,6,7   EXTICR3 = line 8,9,10,11
 *    ค่าใน 4 บิต: 0000 = Port A, 0001 = Port B, 0010 = Port C, ...
 *    ตำแหน่ง nibble = (เลข line % 4) * 4  เช่น line 5 -> (5%4)*4 = 4 -> bit [7:4] */
#define SYSCFG_BASE              (0x40013800UL)
#define SYSCFG_OFFSET_EXTICR1    (0x08UL)   /* EXTICR1 ครอบคลุม EXTI0-EXTI3 */
#define SYSCFG_OFFSET_EXTICR2    (0x0CUL)   /* EXTICR2 ครอบคลุม EXTI4-EXTI7 */
#define SYSCFG_OFFSET_EXTICR3    (0x10UL)   /* EXTICR3 ครอบคลุม EXTI8-EXTI11 */
#define SYSCFG_EXTICR_PORTA_SEL  (0x0UL)
#define SYSCFG_EXTICR_PORTB_SEL  (0x1UL)

/* --- EXTI (Section 12.3) --- 1 บิตต่อ 1 line ในทุก register
 *   IMR  = Interrupt Mask Register : บิต = 1 -> อนุญาตให้ line นี้สร้าง interrupt
 *   RTSR = Rising Trigger Selection : บิต = 1 -> จับ rising edge (0->1)
 *   FTSR = Falling Trigger Selection: บิต = 1 -> จับ falling edge (1->0)
 *   PR   = Pending Register         : ฮาร์ดแวร์ตั้งบิตเป็น 1 เมื่อเกิด event
 *          เราต้อง "เคลียร์" เองใน ISR โดยเขียน 1 ลงไป (ใช่ เขียน 1 เพื่อล้าง!)
 *          ถ้าลืมเคลียร์ ISR จะถูกเรียกซ้ำไม่หยุด ระบบค้าง */
#define EXTI_BASE                (0x40013C00UL)
#define EXTI_OFFSET_IMR          (0x00UL)
#define EXTI_OFFSET_RTSR         (0x08UL)
#define EXTI_OFFSET_FTSR         (0x0CUL)
#define EXTI_OFFSET_PR           (0x14UL)

/* --- หมายเลข EXTI line ของแต่ละปุ่ม (= เลขขา) --- */
#define EXTI_LINE_PB4_BIT         (4U)    /* ปุ่มกรอกรหัสหลัก */
#define EXTI_LINE_PB5_BIT         (5U)    /* ปุ่ม Setup Mode */
#define EXTI_LINE_PA10_BIT        (10U)   /* ปุ่มเพิ่มจำนวนหลัก */
#define EXTI_LINE_PB3_BIT         (3U)    /* ปุ่มลดจำนวนหลัก */

/* ที่เก็บ callback ของแต่ละปุ่ม
 * 📘 static (นอกฟังก์ชัน) = ตัวแปรนี้มองเห็นได้เฉพาะในไฟล์นี้ ไฟล์อื่นแตะไม่ได้
 *    volatile = ถูกอ่านใน ISR และถูกเขียนตอน init จึงห้าม compiler cache ค่า
 *    (EXTI_Callback_t) 0 = NULL = "ยังไม่มีฟังก์ชันลงทะเบียน" */
static EXTI_Callback_t volatile s_pb4_callback  = (EXTI_Callback_t) 0;
static EXTI_Callback_t volatile s_pb5_callback  = (EXTI_Callback_t) 0;
static EXTI_Callback_t volatile s_pa10_callback = (EXTI_Callback_t) 0;
static EXTI_Callback_t volatile s_pb3_callback  = (EXTI_Callback_t) 0;

/* ========================================================================
 * ปุ่มกรอกรหัสหลัก - PB4 / EXTI Line 4 (เหมือนเวอร์ชันที่ทดสอบผ่านแล้ว
 * ทุกประการ ไม่มีการแก้ไขแม้แต่บรรทัดเดียว)
 * ======================================================================== */
void EXTI_Driver_Init(EXTI_Callback_t const callback)
{
    uint32_t moder_val;
    uint32_t pupdr_val;
    uint32_t exticr_val;

    /* ป้องกันการส่ง NULL เข้ามา — ถ้าไม่มี callback ก็ไม่รู้จะแจ้งใคร
     * จึงไม่เปิด interrupt เลย (กัน ISR ไปเรียก address 0 แล้ว crash) */
    if (callback != (EXTI_Callback_t) 0)
    {
        s_pb4_callback = callback;   /* จำไว้ว่าเกิด event แล้วให้เรียกใคร */

        /* 1) เปิด clock GPIOB และ SYSCFG */
        REG32(RCC_BASE + RCC_OFFSET_AHB1ENR) |= (1UL << RCC_AHB1ENR_GPIOBEN_BIT);
        REG32(RCC_BASE + RCC_OFFSET_APB2ENR) |= (1UL << RCC_APB2ENR_SYSCFGEN_BIT);

        /* 2) ตั้ง PB4 เป็น input (00) + pull-up (01)
         *    ปุ่มบน Training Shield ต่อแบบ active-low: กด = 0V, ปล่อย = 3.3V
         *    📘 ปล่อยปุ่ม -> pull-up ภายในดึงขาขึ้น 3.3V (อ่านได้ 1)
         *       กดปุ่ม   -> ปุ่มต่อขาลง GND (อ่านได้ 0)
         *    MODER: ล้าง 2 บิตเป็น 00 = input (ไม่ต้อง OR อะไรเพิ่ม) */
        moder_val = REG32(GPIOB_BASE + GPIO_OFFSET_MODER);
        moder_val &= ~(0x3UL << (EXTI_LINE_PB4_BIT * 2U));
        REG32(GPIOB_BASE + GPIO_OFFSET_MODER) = moder_val;

        /* PUPDR: ล้างเป็น 00 แล้วใส่ 01 = pull-up */
        pupdr_val = REG32(GPIOB_BASE + GPIO_OFFSET_PUPDR);
        pupdr_val &= ~(0x3UL << (EXTI_LINE_PB4_BIT * 2U));
        pupdr_val |= (0x1UL << (EXTI_LINE_PB4_BIT * 2U));
        REG32(GPIOB_BASE + GPIO_OFFSET_PUPDR) = pupdr_val;

        /* 3) ผูก EXTI Line 4 เข้ากับ Port B ผ่าน SYSCFG_EXTICR2 (nibble แรก)
         *    line 4 -> EXTICR2, ตำแหน่ง (4%4)*4 = 0 -> bit [3:0]
         *    ล้าง 4 บิต (0xF) แล้วใส่ 0001 = Port B */
        exticr_val = REG32(SYSCFG_BASE + SYSCFG_OFFSET_EXTICR2);
        exticr_val &= ~(0xFUL << 0U);
        exticr_val |= (SYSCFG_EXTICR_PORTB_SEL << 0U);
        REG32(SYSCFG_BASE + SYSCFG_OFFSET_EXTICR2) = exticr_val;

        /* 4) เปิดทั้ง rising และ falling trigger เพื่อจับทั้งกดและปล่อย
         *    📘 ทำไมต้องจับทั้ง 2 ขอบ? เพราะต้องรู้ "เวลาที่เริ่มกด" และ "เวลา
         *       ที่ปล่อย" เพื่อเอามาลบกันหาว่ากดค้างนานกี่ ms (SHORT/LONG) */
        REG32(EXTI_BASE + EXTI_OFFSET_RTSR) |= (1UL << EXTI_LINE_PB4_BIT);
        REG32(EXTI_BASE + EXTI_OFFSET_FTSR) |= (1UL << EXTI_LINE_PB4_BIT);

        /* 5) unmask ให้ EXTI line 4 สร้าง interrupt ได้ */
        REG32(EXTI_BASE + EXTI_OFFSET_IMR) |= (1UL << EXTI_LINE_PB4_BIT);

        /* 6) ตั้ง priority = 1 แล้วเปิด NVIC ให้ EXTI4_IRQn ผ่าน CMSIS function
         *    📘 ตาราง priority ทั้งระบบ (เลขน้อย = สำคัญกว่า แทรกเลขมากได้):
         *       1 = ปุ่มทั้ง 4 (ต้องจับเวลากดให้แม่นที่สุด)
         *       2 = TIM3 tick 100ms
         *       3 = UART
         *       4 = ADC (ถี่ที่สุดแต่สำคัญน้อยสุด) */
        NVIC_SetPriority(EXTI4_IRQn, 1U);
        NVIC_EnableIRQ(EXTI4_IRQn);
    }
    else
    {
        /* MISRA: else บังคับ — callback เป็น NULL จะไม่ init อะไรเลย */
    }
}

/* 📘 ISR (Interrupt Service Routine) ของ EXTI line 4
 *    - ไม่มีใครในโค้ดเรียกฟังก์ชันนี้ตรงๆ! ฮาร์ดแวร์เรียกเองเมื่อเกิด interrupt
 *    - ชื่อต้องสะกดตรงกับในไฟล์ startup (startup_stm32f411retx.s) เป๊ะๆ
 *      ถ้าสะกดผิด จะไม่มี error แต่ interrupt จะไปตก Default_Handler แล้วค้าง
 *    - หลักการเขียน ISR: ทำให้สั้นและเร็ว ห้ามมี loop รอนานๆ */
void EXTI4_IRQHandler(void)
{
    uint32_t idr_val;

    /* เช็คว่า line 4 เป็นตัวที่ยกธงจริงไหม */
    if ((REG32(EXTI_BASE + EXTI_OFFSET_PR) & (1UL << EXTI_LINE_PB4_BIT)) != 0U)
    {
        /* เคลียร์ธง pending ทันที (เขียน 1 = ล้าง ใช้ = ได้เลยเพราะเขียน 0
         * ลงบิตอื่นไม่มีผล) ไม่งั้น ISR นี้จะถูกเรียกซ้ำไม่จบ */
        REG32(EXTI_BASE + EXTI_OFFSET_PR) = (1UL << EXTI_LINE_PB4_BIT);

        if (s_pb4_callback != (EXTI_Callback_t) 0)
        {
            /* EXTI บอกแค่ว่า "สัญญาณเปลี่ยน" แต่ไม่บอกว่าเปลี่ยนไปทางไหน
             * (เพราะเปิดทั้ง rising และ falling) จึงอ่านค่าขาตอนนี้มาตัดสิน:
             * ขาเป็น 0 แปลว่าตอนนี้ถูกกดอยู่ -> เพิ่งกด, เป็น 1 -> เพิ่งปล่อย */
            idr_val = REG32(GPIOB_BASE + GPIO_OFFSET_IDR);

            if ((idr_val & (1UL << EXTI_LINE_PB4_BIT)) == 0U)
            {
                s_pb4_callback(EXTI_EDGE_RISING);   /* อ่านได้ 0 = เพิ่งถูกกดลง */
            }
            else
            {
                s_pb4_callback(EXTI_EDGE_FALLING);  /* อ่านได้ 1 = เพิ่งถูกปล่อย */
            }
        }
        else
        {
            /* ไม่มี callback ลงทะเบียนไว้ - ไม่ทำอะไร (ป้องกัน crash) */
        }
    }
    else
    {
        /* Pending bit ไม่ตรงกับ line ที่รอ - ไม่ควรเกิดขึ้น แต่ handle ไว้กัน MISRA */
    }
}

/* ========================================================================
 * ปุ่ม Setup Mode - PB5 / EXTI Line 5 (คัดลอกจาก EXTI_Driver_Init ด้านบน
 * แล้วปรับ pin เป็น 5 และ IRQn เป็น EXTI9_5_IRQn เพราะ line 5-9 ใช้ vector
 * ร่วมกัน — เนื่องจากมีแค่ปุ่มนี้ตัวเดียวที่ใช้ range นี้ จึงตรวจ pending
 * bit ของ line 5 เท่านั้นพอ ไม่ต้องวนเช็คทั้ง 5-9)
 *
 * 📘 STM32F411 ให้ ISR แยกตัวเฉพาะ line 0,1,2,3,4 เท่านั้น
 *    line 5-9 ต้องใช้ ISR ร่วมกัน 1 ตัว (EXTI9_5_IRQHandler)
 *    line 10-15 ใช้ร่วมกันอีก 1 ตัว (EXTI15_10_IRQHandler)
 *    ถ้าในอนาคตเพิ่มปุ่มบน line 6-9 ต้องเพิ่มการเช็คบิต PR ของ line นั้นใน ISR นี้ด้วย
 * ======================================================================== */
void EXTI_Driver_InitSetupButton(EXTI_Callback_t const callback)
{
    uint32_t moder_val;
    uint32_t pupdr_val;
    uint32_t exticr_val;

    if (callback != (EXTI_Callback_t) 0)
    {
        s_pb5_callback = callback;

        /* 1) clock (เปิดซ้ำได้ไม่มีผลเสีย ถ้าเปิดไปแล้วตอน PB4) */
        REG32(RCC_BASE + RCC_OFFSET_AHB1ENR) |= (1UL << RCC_AHB1ENR_GPIOBEN_BIT);
        REG32(RCC_BASE + RCC_OFFSET_APB2ENR) |= (1UL << RCC_APB2ENR_SYSCFGEN_BIT);

        /* 2) PB5 = input + pull-up */
        moder_val = REG32(GPIOB_BASE + GPIO_OFFSET_MODER);
        moder_val &= ~(0x3UL << (EXTI_LINE_PB5_BIT * 2U));
        REG32(GPIOB_BASE + GPIO_OFFSET_MODER) = moder_val;

        pupdr_val = REG32(GPIOB_BASE + GPIO_OFFSET_PUPDR);
        pupdr_val &= ~(0x3UL << (EXTI_LINE_PB5_BIT * 2U));
        pupdr_val |= (0x1UL << (EXTI_LINE_PB5_BIT * 2U));
        REG32(GPIOB_BASE + GPIO_OFFSET_PUPDR) = pupdr_val;

        /* 3) Line 5 อยู่ nibble ที่ 2 ของ EXTICR2 (bit 4:7) -> shift 4 */
        exticr_val = REG32(SYSCFG_BASE + SYSCFG_OFFSET_EXTICR2);
        exticr_val &= ~(0xFUL << 4U);
        exticr_val |= (SYSCFG_EXTICR_PORTB_SEL << 4U);
        REG32(SYSCFG_BASE + SYSCFG_OFFSET_EXTICR2) = exticr_val;

        /* 4) จับทั้ง 2 ขอบ (ต้องวัดระยะกดค้าง 3 วินาที)  5) unmask */
        REG32(EXTI_BASE + EXTI_OFFSET_RTSR) |= (1UL << EXTI_LINE_PB5_BIT);
        REG32(EXTI_BASE + EXTI_OFFSET_FTSR) |= (1UL << EXTI_LINE_PB5_BIT);
        REG32(EXTI_BASE + EXTI_OFFSET_IMR) |= (1UL << EXTI_LINE_PB5_BIT);

        /* 6) NVIC: ใช้ IRQ รวมของ line 5-9 */
        NVIC_SetPriority(EXTI9_5_IRQn, 1U);
        NVIC_EnableIRQ(EXTI9_5_IRQn);
    }
    else
    {
        /* MISRA: else บังคับ — callback เป็น NULL จะไม่ init อะไรเลย */
    }
}

/* ISR รวมของ EXTI line 5-9 (โปรเจคนี้ใช้แค่ line 5 = PB5) — หลักการเหมือน EXTI4 */
void EXTI9_5_IRQHandler(void)
{
    uint32_t idr_val;

    if ((REG32(EXTI_BASE + EXTI_OFFSET_PR) & (1UL << EXTI_LINE_PB5_BIT)) != 0U)
    {
        REG32(EXTI_BASE + EXTI_OFFSET_PR) = (1UL << EXTI_LINE_PB5_BIT);   /* เคลียร์ธง */

        if (s_pb5_callback != (EXTI_Callback_t) 0)
        {
            idr_val = REG32(GPIOB_BASE + GPIO_OFFSET_IDR);

            if ((idr_val & (1UL << EXTI_LINE_PB5_BIT)) == 0U)
            {
                s_pb5_callback(EXTI_EDGE_RISING);    /* 0 = เพิ่งกด */
            }
            else
            {
                s_pb5_callback(EXTI_EDGE_FALLING);   /* 1 = เพิ่งปล่อย */
            }
        }
        else
        {
            /* ไม่มี callback ลงทะเบียนไว้ - ไม่ทำอะไร */
        }
    }
    else
    {
        /* ไม่ใช่ line 5 (โปรเจคนี้ใช้แค่ line 5 ใน vector นี้ -
         * ไม่ควรเกิดจาก line อื่น แต่ handle ไว้กัน MISRA) */
    }
}

/* ========================================================================
 * ปุ่มเพิ่มจำนวนหลัก - PA10 / EXTI Line 10 (คัดลอกจาก EXTI_Driver_Init
 * ปรับเป็น GPIOA, pin 10, IRQn เป็น EXTI15_10_IRQn)
 * ======================================================================== */
void EXTI_Driver_InitDigitUpButton(EXTI_Callback_t const callback)
{
    uint32_t moder_val;
    uint32_t pupdr_val;
    uint32_t exticr_val;

    if (callback != (EXTI_Callback_t) 0)
    {
        s_pa10_callback = callback;

        /* 1) ปุ่มนี้อยู่ Port A จึงเปิด clock GPIOA (ไม่ใช่ GPIOB) */
        REG32(RCC_BASE + RCC_OFFSET_AHB1ENR) |= (1UL << RCC_AHB1ENR_GPIOAEN_BIT);
        REG32(RCC_BASE + RCC_OFFSET_APB2ENR) |= (1UL << RCC_APB2ENR_SYSCFGEN_BIT);

        /* 2) PA10 = input + pull-up  (ขา 10 -> บิต [21:20]) */
        moder_val = REG32(GPIOA_BASE + GPIO_OFFSET_MODER);
        moder_val &= ~(0x3UL << (EXTI_LINE_PA10_BIT * 2U));
        REG32(GPIOA_BASE + GPIO_OFFSET_MODER) = moder_val;

        pupdr_val = REG32(GPIOA_BASE + GPIO_OFFSET_PUPDR);
        pupdr_val &= ~(0x3UL << (EXTI_LINE_PA10_BIT * 2U));
        pupdr_val |= (0x1UL << (EXTI_LINE_PA10_BIT * 2U));
        REG32(GPIOA_BASE + GPIO_OFFSET_PUPDR) = pupdr_val;

        /* 3) Line 10 อยู่ nibble ที่ 3 ของ EXTICR3 (bit 8:11) -> shift 8
         *    ใส่ 0000 = Port A (ค่า 0 จึงเหมือนแค่ล้าง แต่เขียนไว้ให้ชัดเจน) */
        exticr_val = REG32(SYSCFG_BASE + SYSCFG_OFFSET_EXTICR3);
        exticr_val &= ~(0xFUL << 8U);
        exticr_val |= (SYSCFG_EXTICR_PORTA_SEL << 8U);
        REG32(SYSCFG_BASE + SYSCFG_OFFSET_EXTICR3) = exticr_val;

        /* 4) + 5) จับทั้ง 2 ขอบ แล้ว unmask (main.c ใช้แค่ขอบ "ปล่อย" ก็ตาม) */
        REG32(EXTI_BASE + EXTI_OFFSET_RTSR) |= (1UL << EXTI_LINE_PA10_BIT);
        REG32(EXTI_BASE + EXTI_OFFSET_FTSR) |= (1UL << EXTI_LINE_PA10_BIT);
        REG32(EXTI_BASE + EXTI_OFFSET_IMR) |= (1UL << EXTI_LINE_PA10_BIT);

        /* 6) NVIC: ใช้ IRQ รวมของ line 10-15 */
        NVIC_SetPriority(EXTI15_10_IRQn, 1U);
        NVIC_EnableIRQ(EXTI15_10_IRQn);
    }
    else
    {
        /* MISRA: else บังคับ — callback เป็น NULL จะไม่ init อะไรเลย */
    }
}

/* ISR รวมของ EXTI line 10-15 (โปรเจคนี้ใช้แค่ line 10 = PA10) */
void EXTI15_10_IRQHandler(void)
{
    uint32_t idr_val;

    if ((REG32(EXTI_BASE + EXTI_OFFSET_PR) & (1UL << EXTI_LINE_PA10_BIT)) != 0U)
    {
        REG32(EXTI_BASE + EXTI_OFFSET_PR) = (1UL << EXTI_LINE_PA10_BIT);  /* เคลียร์ธง */

        if (s_pa10_callback != (EXTI_Callback_t) 0)
        {
            idr_val = REG32(GPIOA_BASE + GPIO_OFFSET_IDR);   /* อ่านจาก Port A */

            if ((idr_val & (1UL << EXTI_LINE_PA10_BIT)) == 0U)
            {
                s_pa10_callback(EXTI_EDGE_RISING);    /* 0 = เพิ่งกด */
            }
            else
            {
                s_pa10_callback(EXTI_EDGE_FALLING);   /* 1 = เพิ่งปล่อย */
            }
        }
        else
        {
            /* ไม่มี callback ลงทะเบียนไว้ - ไม่ทำอะไร */
        }
    }
    else
    {
        /* ไม่ใช่ line 10 (โปรเจคนี้ใช้แค่ line 10 ใน vector นี้ -
         * ไม่ควรเกิดจาก line อื่น แต่ handle ไว้กัน MISRA) */
    }
}

/* ========================================================================
 * ปุ่มลดจำนวนหลัก - PB3 / EXTI Line 3 (คัดลอกจาก EXTI_Driver_Init
 * ปรับเป็น pin 3, IRQn เป็น EXTI3_IRQn - เป็น dedicated vector ของตัวเอง)
 *
 * ⚠ หมายเหตุฮาร์ดแวร์: บน Nucleo ขา PB3 เป็นขา SWO ของ debugger ด้วย
 *   ปกติใช้เป็น GPIO ได้ (ตอน debug แบบ SWD ธรรมดาไม่ได้ใช้ SWO)
 *   แต่ถ้าวันหนึ่งเปิด SWV/trace ใน CubeIDE ปุ่มนี้อาจทำงานแปลกๆ
 * ======================================================================== */
void EXTI_Driver_InitDigitDownButton(EXTI_Callback_t const callback)
{
    uint32_t moder_val;
    uint32_t pupdr_val;
    uint32_t exticr_val;

    if (callback != (EXTI_Callback_t) 0)
    {
        s_pb3_callback = callback;

        /* 1) clock */
        REG32(RCC_BASE + RCC_OFFSET_AHB1ENR) |= (1UL << RCC_AHB1ENR_GPIOBEN_BIT);
        REG32(RCC_BASE + RCC_OFFSET_APB2ENR) |= (1UL << RCC_APB2ENR_SYSCFGEN_BIT);

        /* 2) PB3 = input + pull-up */
        moder_val = REG32(GPIOB_BASE + GPIO_OFFSET_MODER);
        moder_val &= ~(0x3UL << (EXTI_LINE_PB3_BIT * 2U));
        REG32(GPIOB_BASE + GPIO_OFFSET_MODER) = moder_val;

        pupdr_val = REG32(GPIOB_BASE + GPIO_OFFSET_PUPDR);
        pupdr_val &= ~(0x3UL << (EXTI_LINE_PB3_BIT * 2U));
        pupdr_val |= (0x1UL << (EXTI_LINE_PB3_BIT * 2U));
        REG32(GPIOB_BASE + GPIO_OFFSET_PUPDR) = pupdr_val;

        /* 3) Line 3 อยู่ nibble ที่ 4 ของ EXTICR1 (bit 12:15) -> shift 12 */
        exticr_val = REG32(SYSCFG_BASE + SYSCFG_OFFSET_EXTICR1);
        exticr_val &= ~(0xFUL << 12U);
        exticr_val |= (SYSCFG_EXTICR_PORTB_SEL << 12U);
        REG32(SYSCFG_BASE + SYSCFG_OFFSET_EXTICR1) = exticr_val;

        /* 4) + 5) */
        REG32(EXTI_BASE + EXTI_OFFSET_RTSR) |= (1UL << EXTI_LINE_PB3_BIT);
        REG32(EXTI_BASE + EXTI_OFFSET_FTSR) |= (1UL << EXTI_LINE_PB3_BIT);
        REG32(EXTI_BASE + EXTI_OFFSET_IMR) |= (1UL << EXTI_LINE_PB3_BIT);

        /* 6) NVIC: line 3 มี IRQ เป็นของตัวเอง */
        NVIC_SetPriority(EXTI3_IRQn, 1U);
        NVIC_EnableIRQ(EXTI3_IRQn);
    }
    else
    {
        /* MISRA: else บังคับ — callback เป็น NULL จะไม่ init อะไรเลย */
    }
}

/* ISR ของ EXTI line 3 (PB3) */
void EXTI3_IRQHandler(void)
{
    uint32_t idr_val;

    if ((REG32(EXTI_BASE + EXTI_OFFSET_PR) & (1UL << EXTI_LINE_PB3_BIT)) != 0U)
    {
        REG32(EXTI_BASE + EXTI_OFFSET_PR) = (1UL << EXTI_LINE_PB3_BIT);   /* เคลียร์ธง */

        if (s_pb3_callback != (EXTI_Callback_t) 0)
        {
            idr_val = REG32(GPIOB_BASE + GPIO_OFFSET_IDR);

            if ((idr_val & (1UL << EXTI_LINE_PB3_BIT)) == 0U)
            {
                s_pb3_callback(EXTI_EDGE_RISING);    /* 0 = เพิ่งกด */
            }
            else
            {
                s_pb3_callback(EXTI_EDGE_FALLING);   /* 1 = เพิ่งปล่อย */
            }
        }
        else
        {
            /* ไม่มี callback ลงทะเบียนไว้ - ไม่ทำอะไร */
        }
    }
    else
    {
        /* Pending bit ไม่ตรงกับ line ที่รอ - ไม่ควรเกิดขึ้น แต่ handle ไว้กัน MISRA */
    }
}
