/******************************************************************************
 * @file    timer_driver.c
 * @brief   Implementation ของ Timer driver (register-level, raw address)
 *          (อ่านคำอธิบายพื้นฐานเรื่อง PSC / CNT / ARR ใน timer_driver.h ก่อน)
 ******************************************************************************/
#include "timer_driver.h"
#include "stm32f411xe.h"   /* ต้องใช้เฉพาะ IRQn_Type enum + NVIC_EnableIRQ()
                             * ตามที่สไลด์ 0500_Interrupts.pdf ระบุว่า "ต้องใช้
                             * CMSIS" สำหรับตั้งค่า NVIC โดยเฉพาะ (peripheral
                             * register อื่นด้านล่างยังคง raw address ตามเดิม) */

#define REG32(addr)  (*(volatile uint32_t *)(addr))   /* ดูคำอธิบายใน gpio_driver.c */

/* --- TIM2 / TIM3 base address (RM0383 Section 2.3, Memory Map) --- */
#define TIM2_BASE              (0x40000000UL)
#define TIM3_BASE               (0x40000400UL)

/* --- Register offset ภายใน timer (เหมือนกันทั้ง TIM2/TIM3) ---
 *   CR1  : Control Register 1  — บิต CEN = เริ่ม/หยุดนับ
 *   DIER : DMA/Interrupt Enable — บิต UIE = เปิด interrupt ตอนนับครบรอบ
 *   SR   : Status Register     — บิต UIF = ธง "นับครบรอบแล้ว" (ต้องเคลียร์เอง)
 *   EGR  : Event Generation    — บิต UG = สั่งให้เกิด update event ทันที
 *   CNT  : ค่าที่นับอยู่, PSC : ตัวหาร, ARR : ค่าสูงสุดก่อนวนกลับ */
#define TIM_OFFSET_CR1          (0x00UL)
#define TIM_OFFSET_DIER         (0x0CUL)
#define TIM_OFFSET_SR           (0x10UL)
#define TIM_OFFSET_EGR          (0x14UL)
#define TIM_OFFSET_CNT          (0x24UL)
#define TIM_OFFSET_PSC          (0x28UL)
#define TIM_OFFSET_ARR          (0x2CUL)

#define TIM_CR1_CEN_BIT         (0U)
#define TIM_DIER_UIE_BIT        (0U)
#define TIM_SR_UIF_BIT          (0U)
#define TIM_EGR_UG_BIT          (0U)

/* --- RCC (Section 6.3.10, APB1ENR) --- TIM2/TIM3 อยู่บนบัส APB1 */
#define RCC_BASE                (0x40023800UL)
#define RCC_OFFSET_APB1ENR      (0x40UL)
#define RCC_APB1ENR_TIM2EN_BIT  (0U)
#define RCC_APB1ENR_TIM3EN_BIT  (1U)

/* PSC คำนวณให้ counter clock = 1 kHz (1 tick = 1ms)
 * TIMCLK / (PSC + 1) = 1000  ->  PSC = (TIMCLK / 1000) - 1
 * แทนค่า: (16,000,000 / 1000) - 1 = 15,999
 * 📘 ทำไมต้อง -1? เพราะฮาร์ดแวร์หารด้วย (PSC + 1) เสมอ (PSC = 0 คือหาร 1) */
#define TIMER_DRIVER_PSC_FOR_1KHZ  ((uint32_t)((TIMER_DRIVER_TIMCLK_HZ / 1000UL) - 1UL))
/* ARR ของ TIM3 = 100 - 1 = 99 -> นับ 0,1,...,99 = 100 ขั้น x 1ms = 100ms ต่อรอบ */
#define TIMER_DRIVER_TIM3_ARR      ((uint32_t)(TIMER_DRIVER_TICK_MS - 1U))

static Timer_TickCallback_t volatile s_tim3_tick_callback = (Timer_TickCallback_t) 0;

void Timer_Driver_TIM2_Init(void)
{
    /* 1) เปิด clock ให้ TIM2 */
    REG32(RCC_BASE + RCC_OFFSET_APB1ENR) |= (1UL << RCC_APB1ENR_TIM2EN_BIT);

    /* 2) ตั้ง prescaler ให้ counter clock = 1kHz */
    REG32(TIM2_BASE + TIM_OFFSET_PSC) = TIMER_DRIVER_PSC_FOR_1KHZ;

    /* 3) ตั้ง Auto-Reload สูงสุด (TIM2 เป็น 32-bit timer) เพื่อให้เป็น
     *    free-running แทบไม่ overflow (ที่ 1ms/tick ~= 49.7 วันถึง wrap)
     *    📘 0xFFFFFFFF = 4,294,967,295 ms ≈ 49.7 วัน
     *       ต่อให้ wrap กลับ 0 การลบ (ปล่อย - กด) ด้วย uint32_t ก็ยังได้
     *       ผลถูก เพราะเลข unsigned วนรอบแบบ modulo 2^32 */
    REG32(TIM2_BASE + TIM_OFFSET_ARR) = 0xFFFFFFFFUL;

    /* 4) BUG FIX ที่สำคัญมาก: ค่า PSC/ARR ที่เพิ่งเขียนไปจะยังไม่มีผลจริง
     *    จนกว่าจะเกิด "update event" ครั้งแรก (ปกติคือตอน overflow ครบรอบ)
     *    เพราะ ARR ตั้งไว้สูงสุดแทบไม่มีวัน overflow เอง เราจึงต้อง "บังคับ"
     *    ให้เกิด update event ทันทีด้วยการเซ็ต EGR.UG กัน ไม่งั้น TIM2 จะนับ
     *    ด้วยความเร็วดิบ 16MHz แทนที่จะเป็น 1kHz ตามที่ตั้งใจ (bug ที่ทำให้
     *    กดสั้นก็ถูกอ่านเป็น LONG เสมอ เพราะตัวเลข duration พุ่งเกิน threshold)
     *    📘 PSC มี "ตัวสำรอง" (shadow register) ค่าที่เราเขียนไปเก็บไว้ใน
     *       ตัวสำรองก่อน แล้วค่อยถูกคัดลอกไปใช้จริงตอนเกิด update event */
    REG32(TIM2_BASE + TIM_OFFSET_EGR) |= (1UL << TIM_EGR_UG_BIT);

    /* 5) EGR.UG จะไปเซ็ต flag UIF ใน SR ด้วยเป็นผลข้างเคียง ต้อง clear ทิ้ง
     *    ก่อน (TIM2 ไม่ได้เปิด interrupt แต่เคลียร์ไว้เพื่อความสะอาดของ state) */
    REG32(TIM2_BASE + TIM_OFFSET_SR) &= ~(1UL << TIM_SR_UIF_BIT);

    /* 6) reset counter แล้วเริ่มนับ (ไม่เปิด interrupt — เป็นแค่นาฬิกากลาง) */
    REG32(TIM2_BASE + TIM_OFFSET_CNT) = 0UL;
    REG32(TIM2_BASE + TIM_OFFSET_CR1) |= (1UL << TIM_CR1_CEN_BIT);
}

uint32_t Timer_Driver_TIM2_GetTick(void)
{
    /* แค่อ่าน CNT ตรงๆ = เวลาเป็น ms นับตั้งแต่เริ่ม (อ่านทีเดียว ไม่ใช่ polling) */
    return REG32(TIM2_BASE + TIM_OFFSET_CNT);
}

void Timer_Driver_TIM3_Init(Timer_TickCallback_t const callback)
{
    if (callback != (Timer_TickCallback_t) 0)
    {
        s_tim3_tick_callback = callback;

        /* 1) เปิด clock ให้ TIM3 */
        REG32(RCC_BASE + RCC_OFFSET_APB1ENR) |= (1UL << RCC_APB1ENR_TIM3EN_BIT);

        /* 2) ตั้ง prescaler เหมือน TIM2 (counter clock = 1kHz) */
        REG32(TIM3_BASE + TIM_OFFSET_PSC) = TIMER_DRIVER_PSC_FOR_1KHZ;

        /* 3) ตั้ง ARR ให้ overflow ทุก 100ms ตาม design */
        REG32(TIM3_BASE + TIM_OFFSET_ARR) = TIMER_DRIVER_TIM3_ARR;

        /* 4) BUG FIX เดียวกับ TIM2: ต้องบังคับ update event ก่อน ไม่งั้น
         *    PSC ที่เพิ่งตั้งจะยังไม่มีผล ทำให้ TIM3 overflow ทุก ~6
         *    ไมโครวินาที (นับดิบ 16MHz) แทนที่จะเป็นทุก 100ms ตามที่ตั้งใจ
         *    ผลคือ interrupt รัวถี่ผิดปกติจนระบบค้าง/ทำงานผิดเพี้ยน
         *    จากนั้นเคลียร์ธง UIF ที่เกิดจาก UG และรีเซ็ต counter เป็น 0 */
        REG32(TIM3_BASE + TIM_OFFSET_EGR) |= (1UL << TIM_EGR_UG_BIT);
        REG32(TIM3_BASE + TIM_OFFSET_SR) &= ~(1UL << TIM_SR_UIF_BIT);
        REG32(TIM3_BASE + TIM_OFFSET_CNT) = 0UL;

        /* 5) เปิด Update Interrupt Enable (นับครบรอบเมื่อไหร่ -> ส่ง interrupt) */
        REG32(TIM3_BASE + TIM_OFFSET_DIER) |= (1UL << TIM_DIER_UIE_BIT);

        /* 6) ตั้ง priority = 2 (ต่ำกว่า EXTI4 ตามที่ตกลงไว้ในสถาปัตยกรรม)
         *    แล้วเปิด NVIC ให้ TIM3_IRQn ผ่าน CMSIS function ตามที่สไลด์สอน */
        NVIC_SetPriority(TIM3_IRQn, 2U);
        NVIC_EnableIRQ(TIM3_IRQn);

        /* 7) เริ่มนับ */
        REG32(TIM3_BASE + TIM_OFFSET_CR1) |= (1UL << TIM_CR1_CEN_BIT);
    }
    else
    {
        /* MISRA: else บังคับ - callback เป็น NULL จะไม่ init อะไรเลย */
    }
}

/**
 * @brief  ISR ของ TIM3 — ทำงานทุก 100ms ตาม design
 *         ชื่อฟังก์ชันต้องตรงกับที่ startup file กำหนดไว้เป็น weak symbol
 *         📘 "weak symbol" = startup file มีฟังก์ชันชื่อนี้สำรองไว้ (ว่างๆ)
 *            ถ้าเราเขียนชื่อเดียวกัน linker จะใช้ของเราแทนอัตโนมัติ
 */
void TIM3_IRQHandler(void)
{
    if ((REG32(TIM3_BASE + TIM_OFFSET_SR) & (1UL << TIM_SR_UIF_BIT)) != 0U)
    {
        /* Clear update interrupt flag (เขียน 0 เพื่อ clear ตาม datasheet)
         * ⚠ สังเกต: ของ timer เคลียร์ด้วยการเขียน "0" แต่ของ EXTI PR เคลียร์
         *   ด้วยการเขียน "1" — แต่ละ peripheral ไม่เหมือนกัน ต้องเปิด
         *   Reference Manual ดูทุกครั้ง (rc_w0 = เขียน 0 ล้าง, rc_w1 = เขียน 1 ล้าง) */
        REG32(TIM3_BASE + TIM_OFFSET_SR) &= ~(1UL << TIM_SR_UIF_BIT);

        if (s_tim3_tick_callback != (Timer_TickCallback_t) 0)
        {
            s_tim3_tick_callback();   /* = Main_Tim3TickHandler() ใน main.c */
        }
        else
        {
            /* ไม่มี callback ลงทะเบียนไว้ - ไม่ทำอะไร */
        }
    }
    else
    {
        /* flag อื่นที่ไม่ใช่ update interrupt - ไม่ควรเกิด แต่ handle ไว้กัน MISRA */
    }
}
