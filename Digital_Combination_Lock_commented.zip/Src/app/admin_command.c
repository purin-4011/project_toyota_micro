/******************************************************************************
 * @file    admin_command.c
 * @brief   Implementation ของ admin_command (pure logic)
 ******************************************************************************/
#include "admin_command.h"

/**
 * @brief  เทียบ string 2 ตัวว่าเหมือนกันทุกตัวอักษรไหม (รวม null terminator)
 *         เขียนเองแทนการใช้ strcmp() จาก <string.h> เพื่อให้ชัดเจนว่าไม่มี
 *         dependency กับ libc ส่วนที่ไม่จำเป็น (ตาม MISRA-C แนวทางหลีกเลี่ยง
 *         ฟังก์ชัน string ที่มีความเสี่ยงด้าน bounds)
 * @return 1 = เหมือนกัน, 0 = ต่างกัน
 *
 * 📘 ตัวอย่างการทำงาน เทียบ "RESET" กับ "RESET":
 *    i=0 'R'=='R' ต่อ, i=1 'E'=='E' ต่อ, ... i=5 ทั้งคู่เป็น '\0' -> loop หยุด
 *    เช็คท้าย p_a[5] == p_b[5] (ทั้งคู่ '\0') -> ตรงกัน
 *    เทียบ "RESETX" กับ "RESET": loop หยุดที่ i=5 เพราะ p_b เป็น '\0'
 *    แต่ p_a[5] = 'X' ≠ '\0' -> ไม่ตรง (กันกรณีคำสั่งยาวกว่า)
 */
static uint8_t AdminCommand_StringEquals(char const * const p_a, char const * const p_b)
{
    uint8_t result;
    uint8_t i;
    uint8_t mismatch_found;

    i = 0U;
    mismatch_found = 0U;

    /* วนเทียบทีละตัว จนกว่าจะเจอตัวที่ต่าง หรือ string ใดจบก่อน */
    while ((mismatch_found == 0U) && (p_a[i] != '\0') && (p_b[i] != '\0'))
    {
        if (p_a[i] != p_b[i])
        {
            mismatch_found = 1U;
        }
        else
        {
            i++;
        }
    }

    if ((mismatch_found == 0U) && (p_a[i] == p_b[i]))
    {
        /* ทั้งคู่ชนไปที่ '\0' พร้อมกัน แปลว่าตรงกันทุกตัวอักษร */
        result = 1U;
    }
    else
    {
        result = 0U;
    }

    return result;
}

AdminCommand_t AdminCommand_Parse(char const * const p_line)
{
    AdminCommand_t result;

    /* ไล่เทียบกับคำสั่งที่รู้จักทีละคำ เจอตัวไหนตรงก็ใช้ตัวนั้น */
    if (p_line == (char const *) 0)
    {
        result = ADMIN_CMD_UNKNOWN;   /* กัน NULL pointer */
    }
    else if (AdminCommand_StringEquals(p_line, "UNLOCK") != 0U)
    {
        result = ADMIN_CMD_UNLOCK;
    }
    else if (AdminCommand_StringEquals(p_line, "LOCKOUT") != 0U)
    {
        result = ADMIN_CMD_LOCKOUT;
    }
    else if (AdminCommand_StringEquals(p_line, "RESET") != 0U)
    {
        result = ADMIN_CMD_RESET;
    }
    else if (AdminCommand_StringEquals(p_line, "SHOWPASS") != 0U)
    {
        result = ADMIN_CMD_SHOWPASS;
    }
    else if (AdminCommand_StringEquals(p_line, "STATUS") != 0U)
    {
        result = ADMIN_CMD_STATUS;
    }
    else
    {
        result = ADMIN_CMD_UNKNOWN;
    }

    return result;
}
