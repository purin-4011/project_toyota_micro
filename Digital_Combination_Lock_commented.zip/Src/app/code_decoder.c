/******************************************************************************
 * @file    code_decoder.c
 * @brief   Implementation ของ code_decoder (pure logic, ไม่แตะ hardware)
 *          (ไฟล์ที่ง่ายที่สุดในโปรเจค — มีแค่ if/else ตัวเดียว)
 ******************************************************************************/
#include "code_decoder.h"
#include "app_config.h"   /* ใช้ APP_PRESS_THRESHOLD_MS (= 500) */

CodeSymbol_t CodeDecoder_Classify(uint32_t const duration_ms)
{
    CodeSymbol_t result;

    /* กดน้อยกว่า 500 ms -> SHORT, ตั้งแต่ 500 ms ขึ้นไป -> LONG
     * 📘 (uint32_t) หน้าค่าคงที่ = "cast" แปลงชนิดให้ตรงกันก่อนเทียบ (ตาม MISRA) */
    if (duration_ms < (uint32_t) APP_PRESS_THRESHOLD_MS)
    {
        result = CODE_SYMBOL_SHORT;
    }
    else
    {
        result = CODE_SYMBOL_LONG;
    }

    return result;
}
