/******************************************************************************
 * @file    lock_fsm.c
 * @brief   Implementation ของ lock_fsm (pure logic, ไม่แตะ hardware)
 *          (ดูแผนภาพสถานะใน lock_fsm.h ประกอบตอนอ่าน)
 ******************************************************************************/
#include "lock_fsm.h"
#include "code_storage.h"   /* เทียบรหัสปุ่ม (ล็อกชั้นที่ 1) */
#include "dial_lock.h"      /* เทียบโซน potentiometer (ล็อกชั้นที่ 2) */
#include "app_config.h"     /* ค่า timeout / จำนวนครั้ง */

/* ---------------------------------------------------------------------- *
 * ตัวแปรสถานะภายใน (static = ไฟล์อื่นแก้ตรงๆ ไม่ได้)
 * ---------------------------------------------------------------------- */
static LockState_t s_state = LOCK_STATE_IDLE;   /* สถานะปัจจุบัน */
static LockFsm_NotifyCallback_t volatile s_notify_callback = (LockFsm_NotifyCallback_t) 0;

/* buffer เก็บสัญลักษณ์ที่ผู้ใช้กดในรอบนี้ (สูงสุด 8 ตัว) */
static CodeSymbol_t s_entry_buffer[CODE_STORAGE_MAX_LENGTH];
static uint8_t s_entry_count = 0U;               /* กดไปแล้วกี่ตัวในรอบนี้ */

static uint16_t s_idle_tick_counter = 0U;  /* นับ tick ระหว่างไม่มีการกด (สำหรับ input timeout) */
static uint16_t s_hold_tick_counter = 0U;  /* นับ tick ระหว่างแสดงผล UNLOCKED หรือ LOCKED_OUT */
static uint8_t s_wrong_attempt_count = 0U; /* ผิดติดกันกี่ครั้งแล้ว */

/* ---------------------------------------------------------------------- *
 * Private function prototypes
 * ---------------------------------------------------------------------- */
static void LockFsm_Notify(LockFsm_Notification_t notification);
static void LockFsm_PushSymbol(CodeSymbol_t symbol);
static void LockFsm_Validate(void);

/* ---------------------------------------------------------------------- *
 * Private function implementations
 * ---------------------------------------------------------------------- */

/* แจ้งเหตุการณ์ออกไปให้ main.c (เช็ค NULL ก่อนเสมอ กัน crash) */
static void LockFsm_Notify(LockFsm_Notification_t const notification)
{
    if (s_notify_callback != (LockFsm_NotifyCallback_t) 0)
    {
        s_notify_callback(notification);   /* = Main_LockNotifyHandler() */
    }
    else
    {
        /* ไม่มี callback ลงทะเบียนไว้ - ไม่ทำอะไร */
    }
}

/* เก็บสัญลักษณ์ 1 ตัวต่อท้าย buffer */
static void LockFsm_PushSymbol(CodeSymbol_t const symbol)
{
    if (s_entry_count < (uint8_t) CODE_STORAGE_MAX_LENGTH)
    {
        s_entry_buffer[s_entry_count] = symbol;
        s_entry_count++;
    }
    else
    {
        /* buffer เต็ม - ทิ้งสัญลักษณ์ส่วนเกิน (ป้องกัน overflow)
         * 📘 buffer overflow = เขียนเกินขนาดอาเรย์ ไปทับตัวแปรอื่นในหน่วยความจำ
         *    เป็นบั๊กอันตรายที่หายาก จึงต้องเช็คขอบเขตทุกครั้งก่อนเขียน */
    }
}

/* ตรวจรหัส — ถูกเรียกเมื่อผู้ใช้หยุดกดครบ 1.5 วินาที */
static void LockFsm_Validate(void)
{
    /* ต้องผ่าน "ทั้งสองชั้น" พร้อมกันถึงจะถือว่าถูก */
    bool const code_matched = CodeStorage_Compare(s_entry_buffer, s_entry_count);  /* ชั้น 1: รหัสปุ่ม */
    bool const dial_matched = DialLock_IsAtTargetZone();                           /* ชั้น 2: โซน poten */
    bool const matched = code_matched && dial_matched;                             /* && = AND */

    if (matched)
    {
        /* ถูก -> UNLOCKED, ล้างตัวนับผิด, เริ่มนับเวลาแสดงผล */
        s_state = LOCK_STATE_UNLOCKED;
        s_wrong_attempt_count = 0U;
        s_hold_tick_counter = 0U;
        LockFsm_Notify(LOCK_NOTIFY_UNLOCK_SUCCESS);
    }
    else
    {
        /* ผิด -> นับเพิ่ม 1 */
        s_wrong_attempt_count++;

        if (s_wrong_attempt_count >= (uint8_t) APP_MAX_WRONG_ATTEMPTS)
        {
            /* ผิดครบ 3 ครั้ง -> LOCKED_OUT */
            s_state = LOCK_STATE_LOCKED_OUT;
            s_hold_tick_counter = 0U;
            LockFsm_Notify(LOCK_NOTIFY_LOCKOUT_ENTER);
        }
        else
        {
            /* ยังไม่ครบ -> กลับ IDLE ให้ลองใหม่ */
            s_state = LOCK_STATE_IDLE;
            LockFsm_Notify(LOCK_NOTIFY_UNLOCK_FAIL);
        }
    }

    /* จบรอบ ไม่ว่าถูกหรือผิด -> ล้าง buffer เตรียมรอบหน้า */
    s_entry_count = 0U;
    s_idle_tick_counter = 0U;
}

/* ---------------------------------------------------------------------- *
 * Public function implementations
 * ---------------------------------------------------------------------- */

void LockFsm_Init(LockFsm_NotifyCallback_t const notify_callback)
{
    CodeStorage_Init();   /* ใส่รหัส default (ต้องเปิด CRC driver ก่อน - ดู main.c) */
    DialLock_Init();      /* โซนเป้าหมาย default = 5 */

    s_notify_callback = notify_callback;
    s_state = LOCK_STATE_IDLE;
    s_entry_count = 0U;
    s_idle_tick_counter = 0U;
    s_hold_tick_counter = 0U;
    s_wrong_attempt_count = 0U;
}

/* เหตุการณ์ "มีการกดปุ่ม 1 ครั้ง" */
void LockFsm_OnSymbol(CodeSymbol_t const symbol, uint32_t const press_duration_ms)
{
    /* press_duration_ms สงวนไว้สำหรับโหมดตั้งรหัสในอนาคต (ตรวจจับกดค้าง
     * >=3 วินาที) ยังไม่ใช้ใน scope ปัจจุบัน - cast เป็น void กัน warning */
    (void) press_duration_ms;

    if (s_state == LOCK_STATE_LOCKED_OUT)
    {
        /* ตาม proposal: ระหว่าง lockout กดปุ่มอะไรก็ไม่มีผล */
    }
    else if (s_state == LOCK_STATE_UNLOCKED)
    {
        /* ระหว่างแสดงผลปลดล็อกสำเร็จค้างไว้ ไม่รับ input ใหม่ */
    }
    else
    {
        /* LOCK_STATE_IDLE หรือ LOCK_STATE_ENTERING - รับสัญลักษณ์ */
        if (s_state == LOCK_STATE_IDLE)
        {
            s_state = LOCK_STATE_ENTERING;   /* กดครั้งแรกของรอบ -> เริ่มกรอก */
        }
        else
        {
            /* อยู่ใน ENTERING อยู่แล้ว ไม่ต้องเปลี่ยน state */
        }

        LockFsm_PushSymbol(symbol);
        s_idle_tick_counter = 0U;   /* เพิ่งกด -> เริ่มนับ timeout 1.5s ใหม่ */
        LockFsm_Notify(LOCK_NOTIFY_KEY_ACCEPTED);
    }
}

/* เหตุการณ์ "เวลาผ่านไป 100 ms" — แต่ละสถานะนับเวลาเรื่องของตัวเอง */
void LockFsm_OnTick(void)
{
    if (s_state == LOCK_STATE_ENTERING)
    {
        /* กำลังกรอก: นับว่าหยุดกดมานานแค่ไหน ครบ 15 tick (1.5s) = กรอกจบ ตรวจเลย
         * 📘 นี่คือเหตุผลที่ไม่ต้องมีปุ่ม "Enter" — แค่หยุดกดก็ส่งรหัสเอง */
        s_idle_tick_counter++;

        if (s_idle_tick_counter >= (uint16_t) APP_INPUT_TIMEOUT_TICKS)
        {
            LockFsm_Validate();
        }
        else
        {
            /* ยังไม่ครบ timeout - รอ symbol ถัดไป */
        }
    }
    else if (s_state == LOCK_STATE_UNLOCKED)
    {
        /* ปลดล็อกอยู่: ค้างไว้ APP_UNLOCK_HOLD_TICKS แล้วล็อกกลับเอง */
        s_hold_tick_counter++;

        if (s_hold_tick_counter >= (uint16_t) APP_UNLOCK_HOLD_TICKS)
        {
            s_state = LOCK_STATE_IDLE;
            LockFsm_Notify(LOCK_NOTIFY_RETURN_TO_IDLE);
        }
        else
        {
            /* ยังไม่ครบเวลาแสดงผลสำเร็จ */
        }
    }
    else if (s_state == LOCK_STATE_LOCKED_OUT)
    {
        /* ถูกล็อกเอาต์: ครบ APP_LOCKOUT_TICKS แล้วปลดโทษ + ล้างตัวนับผิด */
        s_hold_tick_counter++;

        if (s_hold_tick_counter >= (uint16_t) APP_LOCKOUT_TICKS)
        {
            s_state = LOCK_STATE_IDLE;
            s_wrong_attempt_count = 0U;
            LockFsm_Notify(LOCK_NOTIFY_RETURN_TO_IDLE);
        }
        else
        {
            /* ยังไม่ครบเวลา lockout */
        }
    }
    else
    {
        /* LOCK_STATE_IDLE: ไม่มีอะไรต้องทำทุก tick */
    }
}

LockState_t LockFsm_GetState(void)
{
    return s_state;
}

uint8_t LockFsm_GetWrongAttemptCount(void)
{
    return s_wrong_attempt_count;
}

uint16_t LockFsm_GetLockoutSecondsRemaining(void)
{
    uint16_t seconds_remaining;

    if (s_state == LOCK_STATE_LOCKED_OUT)
    {
        /* tick ที่เหลือ / 10 = วินาทีที่เหลือ (หารจำนวนเต็ม ปัดเศษทิ้ง)
         * เช่น เหลือ 57 tick -> 5 วินาที
         * (ตอนเริ่มเหลือ 100 tick = "10" แต่ 7-segment บีบเหลือ 9 ให้) */
        uint16_t const ticks_remaining = (uint16_t) APP_LOCKOUT_TICKS - s_hold_tick_counter;
        seconds_remaining = ticks_remaining / (uint16_t) APP_TICKS_PER_SECOND;
    }
    else
    {
        seconds_remaining = 0U;
    }

    return seconds_remaining;
}

uint8_t LockFsm_GetEntryCount(void)
{
    return s_entry_count;
}

/* admin UNLOCK: กระโดดไป UNLOCKED ทันที */
void LockFsm_ForceUnlock(void)
{
    s_state = LOCK_STATE_UNLOCKED;
    s_entry_count = 0U;
    s_idle_tick_counter = 0U;
    s_hold_tick_counter = 0U;
    s_wrong_attempt_count = 0U;
    LockFsm_Notify(LOCK_NOTIFY_UNLOCK_SUCCESS);
}

/* admin LOCKOUT: กระโดดไป LOCKED_OUT ทันที */
void LockFsm_ForceLockout(void)
{
    s_state = LOCK_STATE_LOCKED_OUT;
    s_entry_count = 0U;
    s_idle_tick_counter = 0U;
    s_hold_tick_counter = 0U;
    /* ไม่แตะ s_wrong_attempt_count เพราะนี่ไม่ใช่การกดรหัสผิดจริง
     * เป็นคำสั่งบังคับจาก admin */
    LockFsm_Notify(LOCK_NOTIFY_LOCKOUT_ENTER);
}

/* admin RESET (ตอนระบบปกติ): คืนค่าโรงงาน */
void LockFsm_ResetToDefault(void)
{
    /* คืนค่าทั้ง 2 ชั้นกลับเป็น default พร้อมกัน: รหัส (short x4) และโซน
     * เป้าหมาย (โซน 5) — เดิมคืนแค่รหัส ทำให้หลัง RESET โซนยังค้างเป็นค่าที่
     * ตั้งจาก Setup Mode
     * ใช้ SetTargetZone แทน DialLock_Init เพราะ Init จะล้างค่า ADC ล่าสุด
     * เป็น 0 ด้วย ทำให้ 7-segment กระพริบเป็นโซน 1 ชั่วขณะ */
    CodeStorage_Init();
    DialLock_SetTargetZone((uint8_t) DIAL_LOCK_DEFAULT_TARGET_ZONE);
    s_state = LOCK_STATE_IDLE;
    s_entry_count = 0U;
    s_idle_tick_counter = 0U;
    s_hold_tick_counter = 0U;
    s_wrong_attempt_count = 0U;
    LockFsm_Notify(LOCK_NOTIFY_RETURN_TO_IDLE);
}

/* poten ถูกหมุนหลุดโซนระหว่างกรอก (มาจาก ADC Analog Watchdog) */
void LockFsm_OnDialViolation(void)
{
    if (s_state == LOCK_STATE_ENTERING)
    {
        s_state = LOCK_STATE_IDLE;
        s_entry_count = 0U;
        s_idle_tick_counter = 0U;
        /* ไม่แตะ s_wrong_attempt_count โดยตั้งใจ - ถือว่าเป็นอุบัติเหตุ
         * ไม่ใช่การเดารหัสผิด (ตามที่ตกลงกันไว้) */
        LockFsm_Notify(LOCK_NOTIFY_DIAL_VIOLATION);
    }
    else
    {
        /* ไม่ได้อยู่ในสถานะ ENTERING (ไม่ควรเกิดขึ้นเพราะ watchdog เปิดใช้
         * งานเฉพาะตอน ENTERING เท่านั้น) - ไม่ทำอะไร ป้องกันไว้เผื่อ edge case */
    }
}

/* ยกเลิกรอบปัจจุบันแบบนุ่มนวล (ใช้ตอนเข้า Setup Mode / ตอนเข้า DISABLED) */
void LockFsm_ForceIdle(void)
{
    /* ตั้งใจ "ไม่" เรียก CodeStorage_Init() และ "ไม่" แตะ
     * s_wrong_attempt_count - ใช้ตอนเข้า Setup Mode เพื่อยกเลิกการกรอก
     * รหัสที่ค้างอยู่แบบปลอดภัย โดยไม่ล้างรหัสเดิมหรือประวัติกรอกผิด */
    s_state = LOCK_STATE_IDLE;
    s_entry_count = 0U;
    s_idle_tick_counter = 0U;
    s_hold_tick_counter = 0U;
    LockFsm_Notify(LOCK_NOTIFY_RETURN_TO_IDLE);
}
