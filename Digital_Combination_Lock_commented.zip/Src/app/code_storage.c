/******************************************************************************
 * @file    code_storage.c
 * @brief   Implementation ของ code_storage (เก็บใน RAM + ตรวจสอบความถูกต้อง
 *          ด้วย CRC ฮาร์ดแวร์)
 *
 *          หมายเหตุสถาปัตยกรรม: module นี้ยังถือเป็น "เกือบ pure logic"
 *          เหมือนเดิม เพราะ crc_driver ไม่มี interrupt/state แบบ async
 *          (ป้อนข้อมูลเข้า -> อ่านผลลัพธ์ออกได้ทันที เหมือนฟังก์ชันคณิตศาสตร์
 *          ธรรมดา) จึงต่างจาก driver ตัวอื่น (EXTI/Timer/ADC/UART) ที่ห้าม
 *          แตะจาก app layer โดยตรงเพราะมี callback/ISR เกี่ยวข้อง
 ******************************************************************************/
#include "code_storage.h"
#include "crc_driver.h"

#define CODE_STORAGE_DEFAULT_LENGTH (4U)   /* รหัส default ยาว 4 หลัก */

/* ข้อมูลภายใน "ตู้เซฟ" (static = ไฟล์อื่นแตะตรงๆ ไม่ได้ ต้องผ่านฟังก์ชันเท่านั้น)
 *   s_stored_symbols  : อาเรย์เก็บรหัส จองไว้ 8 ช่อง ใช้จริงเท่ากับ s_stored_length
 *   s_stored_length   : รหัสยาวกี่หลัก
 *   s_stored_code_crc : "ลายนิ้วมือ" CRC ของรหัส ที่คำนวณไว้ตอนบันทึก */
static CodeSymbol_t s_stored_symbols[CODE_STORAGE_MAX_LENGTH];
static uint8_t s_stored_length = 0U;
static uint32_t s_stored_code_crc = 0U;

/* รหัส default ตาม proposal: สั้น-สั้น-สั้น-สั้น
 * (const = ค่าคงที่ จะถูกเก็บใน Flash ไม่กิน RAM และแก้ไม่ได้) */
static CodeSymbol_t const s_default_code[CODE_STORAGE_DEFAULT_LENGTH] =
{
    CODE_SYMBOL_SHORT,
    CODE_SYMBOL_SHORT,
    CODE_SYMBOL_SHORT,
    CODE_SYMBOL_SHORT
};

/**
 * @brief  คำนวณ CRC ของรหัส (ความยาว + สัญลักษณ์ทุกตัว) ผ่านฮาร์ดแวร์
 *         ใส่ความยาวเข้าไปคำนวณด้วย เพื่อให้จับความเสียหายที่ทำให้ความยาว
 *         เพี้ยนได้ด้วย ไม่ใช่แค่เนื้อหาสัญลักษณ์
 *         ลำดับการป้อน: [ความยาว] [หลักที่ 1] [หลักที่ 2] ... [หลักสุดท้าย]
 */
static uint32_t CodeStorage_ComputeCrc(CodeSymbol_t const * const p_symbols,
                                        uint8_t const length)
{
    uint32_t crc;
    uint8_t i;

    CRC_Driver_Reset();                              /* เริ่มนับใหม่ */
    crc = CRC_Driver_FeedWord((uint32_t) length);    /* ป้อนความยาวก่อน */

    for (i = 0U; i < length; i++)
    {
        crc = CRC_Driver_FeedWord((uint32_t) p_symbols[i]);   /* ป้อนทีละหลัก */
    }

    return crc;   /* ค่าสุดท้าย = CRC ของข้อมูลทั้งชุด */
}

void CodeStorage_Init(void)
{
    uint8_t i;

    /* คัดลอกรหัส default ลงตู้เซฟ */
    for (i = 0U; i < CODE_STORAGE_DEFAULT_LENGTH; i++)
    {
        s_stored_symbols[i] = s_default_code[i];
    }

    s_stored_length = CODE_STORAGE_DEFAULT_LENGTH;

    /* คำนวณ CRC ของรหัส default เก็บไว้อ้างอิง สำหรับเช็คความถูกต้อง
     * ทุกครั้งที่มีการเทียบรหัสภายหลัง */
    s_stored_code_crc = CodeStorage_ComputeCrc(s_stored_symbols, s_stored_length);
}

bool CodeStorage_Compare(CodeSymbol_t const * const p_symbols, uint8_t const length)
{
    bool result;
    uint8_t i;
    /* ขั้นที่ 1: คำนวณ CRC ของรหัสที่อยู่ใน RAM "ตอนนี้" */
    uint32_t const current_crc = CodeStorage_ComputeCrc(s_stored_symbols, s_stored_length);

    if (current_crc != s_stored_code_crc)
    {
        /* ขั้นที่ 2a: CRC ไม่ตรง!
         * ข้อมูลรหัสที่เก็บไว้เสียหาย (เช่น RAM bit-flip) ไม่ตรงกับ CRC ที่
         * บันทึกไว้ตอน commit ครั้งล่าสุด -> กู้กลับเป็นรหัส default ทันที
         * เพื่อความปลอดภัย (ไม่ปล่อยให้ใช้รหัสที่เพี้ยนไปโดยไม่รู้ตัว) แล้ว
         * ถือว่ารอบนี้เทียบไม่ผ่านเสมอ (ผู้ใช้ต้องลองใหม่ด้วยรหัสที่ถูกต้อง
         * ตามที่กู้คืนมา) */
        CodeStorage_Init();
        result = false;
    }
    else if (length != s_stored_length)
    {
        /* ขั้นที่ 2b: ความยาวไม่เท่ากัน -> ผิดแน่นอน ไม่ต้องเทียบทีละตัว */
        result = false;
    }
    else
    {
        /* ขั้นที่ 2c: เทียบทีละหลัก — สมมติว่าถูกไว้ก่อน เจอหลักไหนผิดค่อยเปลี่ยน
         * 📘 สังเกตว่าเจอผิดแล้วก็ "ไม่หยุด" วนจนครบทุกหลัก — เป็นสไตล์ MISRA
         *    (ไม่ใช้ break) และทำให้ใช้เวลาเท่ากันเสมอไม่ว่าผิดที่หลักไหน */
        result = true;

        for (i = 0U; i < length; i++)
        {
            if (p_symbols[i] != s_stored_symbols[i])
            {
                result = false;
            }
            else
            {
                /* สัญลักษณ์ตำแหน่งนี้ตรงกัน - ตรวจตำแหน่งถัดไปต่อ */
            }
        }
    }

    return result;
}

uint8_t CodeStorage_GetLength(void)
{
    return s_stored_length;
}

CodeSymbol_t CodeStorage_GetSymbol(uint8_t const index)
{
    CodeSymbol_t result;

    /* เช็คขอบเขตก่อนอ่านอาเรย์เสมอ (อ่านเกินขอบ = อ่านขยะในหน่วยความจำ) */
    if (index < s_stored_length)
    {
        result = s_stored_symbols[index];
    }
    else
    {
        result = CODE_SYMBOL_SHORT;   /* index เกินความยาวรหัส - คืนค่าปลอดภัย */
    }

    return result;
}

void CodeStorage_Commit(CodeSymbol_t const * const p_symbols, uint8_t length)
{
    uint8_t i;

    /* กันขอบเขตไม่ให้เกิน buffer (Setup Mode ควร clamp มาให้แล้ว แต่กันไว้
     * อีกชั้นตามหลัก defensive programming) */
    if (length > (uint8_t) CODE_STORAGE_MAX_LENGTH)
    {
        length = (uint8_t) CODE_STORAGE_MAX_LENGTH;
    }
    else
    {
        /* อยู่ในขอบเขตแล้ว - ไม่ต้องทำอะไร */
    }

    /* คัดลอกรหัสใหม่ทับของเดิม */
    for (i = 0U; i < length; i++)
    {
        s_stored_symbols[i] = p_symbols[i];
    }
    s_stored_length = length;

    /* คำนวณ CRC อ้างอิงใหม่ทันที เหมือนที่ CodeStorage_Init ทำกับรหัส
     * default - ทำให้ CodeStorage_Compare() ตรวจสอบรหัสใหม่นี้ได้ถูกต้อง
     * ตั้งแต่การเปรียบเทียบครั้งถัดไป
     * (ถ้าลืมบรรทัดนี้ ครั้งหน้าที่ Compare CRC จะไม่ตรง -> ระบบคิดว่า
     *  ข้อมูลเสีย แล้วกู้กลับเป็นรหัส default ทิ้งรหัสใหม่ไป) */
    s_stored_code_crc = CodeStorage_ComputeCrc(s_stored_symbols, s_stored_length);
}
