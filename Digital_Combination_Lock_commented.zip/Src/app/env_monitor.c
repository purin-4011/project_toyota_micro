/******************************************************************************
 * @file    env_monitor.c
 * @brief   Implementation ของ env_monitor (pure logic, ไม่แตะ hardware)
 *          ใช้ float + logf/powf (ต้องเปิด FPU ก่อน — ดู Core_Driver_Init)
 *
 * 📘 ขั้นตอนการประมวลผลทุก 200 ms:
 *    ค่าดิบ ADC (0-4095) -> ความต้านทานเซนเซอร์ (โอห์ม) -> อุณหภูมิ / lux
 *    -> 1 วินาทีแรก: เก็บค่าเฉลี่ยเป็น "ค่าปกติ"
 *    -> หลังจากนั้น: เทียบอุณหภูมิกับค่าปกติ ถ้าต่างเกิน 3 องศา 3 ครั้งติด = tamper
 ******************************************************************************/
#include <math.h>          /* logf, log10f, powf, fabsf */
#include "env_monitor.h"
#include "app_config.h"

#define ENV_KELVIN_OFFSET     (273.15f)     /* องศาเซลเซียส = เคลวิน - 273.15 */
#define ENV_MAX_LUX           (1000000.0f)  /* เพดานค่า lux กันตัวเลขพุ่งเกินจริง */

static EnvMonitor_NotifyCallback_t s_notify_callback = (EnvMonitor_NotifyCallback_t) 0;

/* ค่าล่าสุด และค่าปกติ (volatile เพราะเขียนใน ADC ISR แต่อ่านจาก UART ISR) */
static float volatile s_temperature_c = 0.0f;
static float volatile s_lux = 0.0f;
static float volatile s_baseline_temp_c = 0.0f;
static float volatile s_baseline_lux = 0.0f;

/* ตัวช่วยหาค่าเฉลี่ยช่วงบูต */
static float s_temp_sum = 0.0f;
static float s_lux_sum = 0.0f;
static uint8_t s_baseline_count = 0U;
static bool volatile s_baseline_ready = false;   /* ได้ค่าปกติครบแล้วหรือยัง */

/* ตัวช่วยตรวจ tamper */
static uint8_t s_abnormal_count = 0U;             /* ผิดปกติติดกันกี่ sample */
static bool volatile s_tamper_latched = false;   /* tamper ค้างอยู่ไหม */

/**
 * @brief  แปลงค่า ADC ดิบเป็นความต้านทานของเซนเซอร์ใน voltage divider
 *         R_sensor = Rx * Vout / (Vcc - Vout) และเพราะ Vref = Vcc = 3.3V
 *         จึงลดรูปเหลือ R_sensor = Rx * raw / (4095 - raw)
 *         (clamp raw ไว้ 1..4094 กันหารด้วยศูนย์และ log(0))
 *
 * 📘 ตัวอย่าง: raw = 2048 (ครึ่งหนึ่ง) -> R = 10k x 2048 / 2047 ≈ 10k
 *    แปลว่าเซนเซอร์มีค่าเท่า Rx พอดี (แรงดันแบ่งครึ่ง)
 */
static float EnvMonitor_RawToResistance(uint16_t raw, float const rx_ohm)
{
    if (raw < 1U)
    {
        raw = 1U;
    }
    else if (raw > 4094U)
    {
        raw = 4094U;
    }
    else
    {
        /* อยู่ในช่วงที่คำนวณได้ - ไม่ต้องปรับ */
    }

    return (rx_ohm * (float) raw) / (APP_ADC_MAX_RAW - (float) raw);
}

/** Beta equation (สไลด์ 0400_ADC หน้า 32)
 *  สูตร:  T = (B x T0) / (T0 x ln(R/R0) + B)     (หน่วยเคลวิน)
 *  B = 3950, T0 = 298.15 K (25°C), R0 = 10k (ค่า NTC ที่ 25°C)
 *  ตรวจสอบง่ายๆ: ถ้า R = R0 -> ln(1) = 0 -> T = T0 = 25°C ถูกต้อง
 *  📘 logf = ln (log ฐาน e) แบบ float  (ตัว f ท้ายชื่อ = เวอร์ชัน float เร็วกว่า double) */
static float EnvMonitor_ResistanceToCelsius(float const r_ntc)
{
    float const t_kelvin = (APP_NTC_BETA * APP_NTC_T0_KELVIN)
                         / ((APP_NTC_T0_KELVIN * logf(r_ntc / APP_NTC_R0_OHM)) + APP_NTC_BETA);

    return t_kelvin - ENV_KELVIN_OFFSET;
}

/** สูตรเดียวกับ Lab 4.3: lux = 10^((log10(R) - OFFSET) / SLOPE)
 *  (กลับสมการ log10(R) = SLOPE x log10(lux) + OFFSET ที่ได้จากกราฟ datasheet LDR) */
static float EnvMonitor_ResistanceToLux(float const r_ldr)
{
    float lux = powf(10.0f, (log10f(r_ldr) - APP_LDR_OFFSET) / APP_LDR_SLOPE);

    if (lux > ENV_MAX_LUX)
    {
        lux = ENV_MAX_LUX;
    }
    else
    {
        /* อยู่ในช่วงปกติ */
    }

    return lux;
}

static void EnvMonitor_Notify(EnvMonitor_Notification_t const notification)
{
    if (s_notify_callback != (EnvMonitor_NotifyCallback_t) 0)
    {
        s_notify_callback(notification);   /* = Main_EnvNotifyHandler() */
    }
    else
    {
        /* ไม่มี callback ลงทะเบียนไว้ - ไม่ทำอะไร */
    }
}

/** เก็บ sample ช่วงแรกหลังบูตมาเฉลี่ยเป็นค่าปกติ (ค่าเฉลี่ย = ผลรวม / จำนวน) */
static void EnvMonitor_CollectBaseline(float const temp_c, float const lux)
{
    s_temp_sum += temp_c;
    s_lux_sum += lux;
    s_baseline_count++;

    if (s_baseline_count >= (uint8_t) APP_ENV_BASELINE_SAMPLES)
    {
        s_baseline_temp_c = s_temp_sum / (float) s_baseline_count;
        s_baseline_lux = s_lux_sum / (float) s_baseline_count;
        s_baseline_ready = true;   /* ครบ 5 sample (1 วินาที) -> เริ่มตรวจจริงได้ */
    }
    else
    {
        /* ยังเก็บไม่ครบ */
    }
}

/** ตรวจอุณหภูมิผิดปกติ (ต้องผิดปกติติดกันหลาย sample กันค่ากระตุก) */
static void EnvMonitor_CheckTemperature(float const temp_c)
{
    /* ส่วนต่างจากค่าปกติ (fabsf = ค่าสัมบูรณ์ ตัดเครื่องหมายลบ — ร้อนขึ้นหรือ
     * เย็นลงก็นับเหมือนกัน) */
    float const delta = fabsf(temp_c - s_baseline_temp_c);

    if (s_tamper_latched)
    {
        /* ค้างอยู่แล้ว - รอ admin ล้าง ไม่ปรับค่าปกติระหว่างนี้ */
    }
    else if (delta > APP_TEMP_TAMPER_DELTA_C)
    {
        /* ต่างเกิน 3 องศา -> นับ 1 ครั้ง ครบ 3 ครั้งติดกัน (0.6s) ถึงจะเชื่อ
         * 📘 การรอหลาย sample เรียกว่า "debounce" ของสัญญาณ กันค่ากระโดด
         *    ชั่วขณะจากสัญญาณรบกวนทำให้ alarm ผิดๆ */
        s_abnormal_count++;

        if (s_abnormal_count >= (uint8_t) APP_TEMP_TAMPER_CONFIRM_SAMPLES)
        {
            s_tamper_latched = true;
            EnvMonitor_Notify(ENV_NOTIFY_TAMPER_DETECTED);
        }
        else
        {
            /* ยังไม่ครบจำนวนที่ต้องยืนยัน */
        }
    }
    else
    {
        s_abnormal_count = 0U;   /* กลับมาปกติ -> เริ่มนับใหม่ (ต้อง "ติดกัน" เท่านั้น) */
        /* ปกติ: ให้ค่าปกติขยับตามอุณหภูมิห้องอย่างช้าๆ
         * 📘 เทคนิค "low-pass filter" แบบง่าย: ขยับเข้าหาค่าใหม่ทีละ 1/1500
         *    ของส่วนต่าง ห้องค่อยๆ อุ่นขึ้นตอนบ่าย ค่าปกติก็ตามไปด้วย
         *    แต่ถ้าเอาไฟแช็กมาลน (เปลี่ยนเร็ว) ค่าปกติตามไม่ทัน -> จับได้ */
        s_baseline_temp_c += (temp_c - s_baseline_temp_c) / APP_TEMP_BASELINE_TRACK_DIV;
    }
}

void EnvMonitor_Init(EnvMonitor_NotifyCallback_t const notify_callback)
{
    s_notify_callback = notify_callback;
    s_temp_sum = 0.0f;
    s_lux_sum = 0.0f;
    s_baseline_count = 0U;
    s_baseline_ready = false;
    s_abnormal_count = 0U;
    s_tamper_latched = false;
}

/* จุดเข้าหลัก: ถูกเรียกทุก 200ms พร้อมค่าดิบของเซนเซอร์ทั้งสอง */
void EnvMonitor_OnSample(uint16_t const ntc_raw, uint16_t const ldr_raw)
{
    /* แปลงค่าดิบ -> ความต้านทาน -> หน่วยจริง */
    float const temp_c = EnvMonitor_ResistanceToCelsius(
                             EnvMonitor_RawToResistance(ntc_raw, APP_NTC_RX_OHM));
    float const lux = EnvMonitor_ResistanceToLux(
                          EnvMonitor_RawToResistance(ldr_raw, APP_LDR_RX_OHM));

    s_temperature_c = temp_c;
    s_lux = lux;

    if (s_baseline_ready)
    {
        EnvMonitor_CheckTemperature(temp_c);   /* ช่วงทำงานปกติ */
    }
    else
    {
        EnvMonitor_CollectBaseline(temp_c, lux);   /* ช่วง 1 วินาทีแรกหลังบูต */
    }
}

bool EnvMonitor_IsPresenceDetected(void)
{
    bool result;

    if (s_baseline_ready)
    {
        /* มีคน = แสงตอนนี้ < 50% ของแสงปกติ (มีคนเอามือ/ตัวมาบัง)
         * เช่น ปกติ 300 lux -> ต่ำกว่า 150 lux ถือว่ามีคน */
        result = (s_lux < ((s_baseline_lux * APP_PRESENCE_LUX_PERCENT) / 100.0f));
    }
    else
    {
        result = false;
    }

    return result;
}

bool EnvMonitor_IsTamperLatched(void)
{
    return s_tamper_latched;
}

void EnvMonitor_ClearTamper(void)
{
    s_abnormal_count = 0U;
    s_tamper_latched = false;
}

/** ปัดเศษ float (องศา) เป็นจำนวนเต็มหน่วย 0.1 องศา
 *  ตัวอย่าง: 27.43 -> x10 = 274.3 -> +0.5 = 274.8 -> ตัดทศนิยม = 274
 *  (ค่าลบต้อง -0.5 แทน เพราะการแปลง float -> int ตัดเข้าหาศูนย์) */
static int32_t EnvMonitor_ToDeci(float const value)
{
    float const scaled = value * 10.0f;
    int32_t result;

    if (scaled >= 0.0f)
    {
        result = (int32_t) (scaled + 0.5f);
    }
    else
    {
        result = (int32_t) (scaled - 0.5f);
    }

    return result;
}

int32_t EnvMonitor_GetTemperatureDeciC(void)
{
    return EnvMonitor_ToDeci(s_temperature_c);
}

int32_t EnvMonitor_GetBaselineTemperatureDeciC(void)
{
    return EnvMonitor_ToDeci(s_baseline_temp_c);
}

uint32_t EnvMonitor_GetLux(void)
{
    return (uint32_t) (s_lux + 0.5f);   /* +0.5 แล้วตัดทศนิยม = ปัดเศษ */
}

uint32_t EnvMonitor_GetBaselineLux(void)
{
    return (uint32_t) (s_baseline_lux + 0.5f);
}
