/******************************************************************************
 * @file    system_mode.c
 * @brief   Implementation ของ system_mode (pure logic, ไม่แตะ hardware)
 *          (ดูแผนภาพใน system_mode.h)
 ******************************************************************************/
#include "system_mode.h"
#include "app_config.h"

static SystemMode_t volatile s_mode = SYSTEM_MODE_ACTIVE;   /* สถานะปัจจุบัน */
static SystemMode_NotifyCallback_t s_notify_callback = (SystemMode_NotifyCallback_t) 0;
static uint16_t volatile s_idle_ticks = 0U;   /* นับว่าว่าง (ไม่มีคน+ไม่มีกด) มากี่ tick */

static void SystemMode_Notify(SystemMode_Notification_t const notification)
{
    if (s_notify_callback != (SystemMode_NotifyCallback_t) 0)
    {
        s_notify_callback(notification);   /* = Main_SystemNotifyHandler() */
    }
    else
    {
        /* ไม่มี callback ลงทะเบียนไว้ - ไม่ทำอะไร */
    }
}

/* ตื่นจาก sleep (ใช้ร่วมกัน 2 ที่: มีคนมาบังแสง และ กดปุ่ม) */
static void SystemMode_Wake(void)
{
    s_mode = SYSTEM_MODE_ACTIVE;
    s_idle_ticks = 0U;
    SystemMode_Notify(SYSTEM_NOTIFY_WAKE);
}

void SystemMode_Init(SystemMode_NotifyCallback_t const notify_callback)
{
    s_notify_callback = notify_callback;
    s_mode = SYSTEM_MODE_ACTIVE;
    s_idle_ticks = 0U;
}

void SystemMode_OnTick(bool const can_sleep, bool const presence)
{
    /* 📘 switch-case = เลือกทำตามค่าของ s_mode ทีละกรณี
     *    break; = จบกรณีนี้ (ถ้าลืม break จะไหลไปทำกรณีถัดไปด้วย = บั๊กยอดฮิต) */
    switch (s_mode)
    {
        case SYSTEM_MODE_ACTIVE:
            /* !presence = "ไม่มีคน" (! = NOT) */
            if (can_sleep && (!presence))
            {
                s_idle_ticks++;

                if (s_idle_ticks >= (uint16_t) APP_SLEEP_IDLE_TICKS)
                {
                    /* ว่างครบ 15 วินาที -> หลับ */
                    s_mode = SYSTEM_MODE_SLEEP;
                    s_idle_ticks = 0U;
                    SystemMode_Notify(SYSTEM_NOTIFY_ENTER_SLEEP);
                }
                else
                {
                    /* ยังไม่ครบเวลา */
                }
            }
            else
            {
                /* มีคนอยู่ใกล้ หรือระบบกำลังทำงานอยู่ - เริ่มนับใหม่ */
                s_idle_ticks = 0U;
            }
            break;

        case SYSTEM_MODE_SLEEP:
            if (presence)
            {
                SystemMode_Wake();   /* มีคนมาบังแสง -> ตื่น */
            }
            else
            {
                /* ยังไม่มีคน - หลับต่อ */
            }
            break;

        case SYSTEM_MODE_DISABLED:
            /* ออกได้ทางเดียวคือ SystemMode_ClearTamper() (admin RESET) */
            break;

        default:
            /* MISRA: default บังคับ - ไม่ควรเกิด */
            break;
    }
}

void SystemMode_OnUserActivity(void)
{
    if (s_mode == SYSTEM_MODE_ACTIVE)
    {
        s_idle_ticks = 0U;   /* มีคนใช้งาน -> เริ่มนับเวลาว่างใหม่ */
    }
    else if (s_mode == SYSTEM_MODE_SLEEP)
    {
        SystemMode_Wake();
    }
    else
    {
        /* DISABLED - การใช้งานไม่มีผล */
    }
}

void SystemMode_OnTamper(void)
{
    if (s_mode != SYSTEM_MODE_DISABLED)
    {
        /* เข้า DISABLED ได้จากทุกสถานะ (แม้กำลังหลับ) */
        s_mode = SYSTEM_MODE_DISABLED;
        s_idle_ticks = 0U;
        SystemMode_Notify(SYSTEM_NOTIFY_ENTER_DISABLED);
    }
    else
    {
        /* อยู่ใน DISABLED แล้ว */
    }
}

void SystemMode_ClearTamper(void)
{
    if (s_mode == SYSTEM_MODE_DISABLED)
    {
        s_mode = SYSTEM_MODE_ACTIVE;
        s_idle_ticks = 0U;
        SystemMode_Notify(SYSTEM_NOTIFY_EXIT_DISABLED);
    }
    else
    {
        /* ไม่ได้อยู่ใน DISABLED - ไม่ต้องทำอะไร */
    }
}

SystemMode_t SystemMode_Get(void)
{
    return s_mode;
}
