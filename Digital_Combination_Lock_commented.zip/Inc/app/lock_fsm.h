/******************************************************************************
 * @file    lock_fsm.h
 * @brief   State machine หลักของ Digital Combination Lock
 *
 *          SCOPE: flow ปลดล็อก (IDLE -> ENTERING -> UNLOCKED / LOCKED_OUT)
 *          (Setup Mode ถูกแยกไปอยู่ใน setup_mode.c แล้ว — comment เดิมที่
 *           บอกว่ายังไม่มี Setup mode เป็นข้อมูลเก่า)
 *
 *          Module นี้ไม่แตะ hardware โดยตรงเลย (ไม่ include driver ใดๆ)
 *          สื่อสารกับภายนอกผ่าน callback (LockFsm_NotifyCallback_t) เท่านั้น
 *          เพื่อให้ Application ชั้นบน (main.c) เป็นคนตัดสินใจว่าจะแสดงผล
 *          อย่างไร (LED, 7-segment)
 *
 * ============================================================================
 *  📘 อธิบายสำหรับมือใหม่: State Machine (FSM) คืออะไร?
 * ============================================================================
 *  FSM = Finite State Machine = ระบบที่ "อยู่ในสถานะใดสถานะหนึ่งเสมอ"
 *  และเปลี่ยนสถานะเมื่อเกิดเหตุการณ์ (event) เหมือนไฟจราจร: แดง -> เขียว -> เหลือง
 *  สถานะเดียวกัน แต่เหตุการณ์เดียวกันอาจให้ผลต่างกันตามสถานะที่อยู่
 *  (เช่น กดปุ่มตอน IDLE = เริ่มกรอก, กดปุ่มตอน LOCKED_OUT = ไม่มีผล)
 *
 *  แผนภาพสถานะของกุญแจ:
 *
 *            กดปุ่มครั้งแรก                  หยุดกด 1.5s + รหัสถูก
 *     IDLE ─────────────────> ENTERING ─────────────────────────> UNLOCKED
 *      ^                       │   │                                 │
 *      │   หยุดกด 1.5s +        │   │ หยุดกด 1.5s + ผิดครบ 3 ครั้ง     │ ครบเวลาแสดงผล
 *      │<── ผิด (ยังไม่ครบ 3) ───┘   v                                 │
 *      │                       LOCKED_OUT                            │
 *      │<─────── ครบเวลา lockout ───┘                                 │
 *      │<─────────────────────────────────────────────────────────────┘
 *      │<── poten หลุดโซนระหว่างกรอก (DIAL_VIOLATION, ไม่นับว่าผิด)
 *
 *  เหตุการณ์ที่ขับ FSM นี้มี 2 แหล่ง:
 *    - LockFsm_OnSymbol() : มีการกดปุ่ม 1 ครั้ง (มาจาก EXTI ผ่าน main.c)
 *    - LockFsm_OnTick()   : เวลาผ่านไป 100 ms (มาจาก TIM3 ผ่าน main.c)
 ******************************************************************************/
#ifndef LOCK_FSM_H
#define LOCK_FSM_H

#include <stdint.h>
#include "code_decoder.h"

/* สถานะทั้ง 4 ของกุญแจ */
typedef enum
{
    LOCK_STATE_IDLE = 0U,      /* รอ — ยังไม่มีใครกด (7-seg โชว์โซน poten) */
    LOCK_STATE_ENTERING,       /* กำลังกรอกรหัส (7-seg โชว์จำนวนหลักที่กดแล้ว) */
    LOCK_STATE_UNLOCKED,       /* ปลดล็อกสำเร็จ — LED เขียวค้าง */
    LOCK_STATE_LOCKED_OUT      /* ผิดครบ 3 ครั้ง — LED แดงค้าง + นับถอยหลัง */
} LockState_t;

/** เหตุการณ์ที่ lock_fsm แจ้งออกไปให้ Application ชั้นบนไปแสดงผลต่อ
 *  📘 lock_fsm "ประกาศ" ว่าเกิดอะไรขึ้น ส่วน main.c "ตัดสินใจ" ว่าจะเปิดไฟไหน
 *     ถ้าวันหนึ่งเปลี่ยนจาก LED เป็น buzzer ก็แก้แค่ main.c ไม่ต้องแตะไฟล์นี้ */
typedef enum
{
    LOCK_NOTIFY_KEY_ACCEPTED = 0U,  /* รับสัญลักษณ์เข้ามา 1 ตัว (ไฟกระพริบสั้นๆ ตอบรับ) */
    LOCK_NOTIFY_UNLOCK_SUCCESS,     /* รหัสถูกต้อง */
    LOCK_NOTIFY_UNLOCK_FAIL,        /* รหัสผิด (แต่ยังไม่ครบ 3 ครั้ง) */
    LOCK_NOTIFY_LOCKOUT_ENTER,      /* ผิดครบ 3 ครั้ง เข้าสู่ lockout */
    LOCK_NOTIFY_RETURN_TO_IDLE,     /* จบช่วงแสดงผล (UNLOCKED หรือ LOCKOUT) กลับสู่ปกติ */
    LOCK_NOTIFY_DIAL_VIOLATION      /* potentiometer หลุดโซนระหว่างป้อนรหัส - ยกเลิกรอบนี้ */
} LockFsm_Notification_t;

typedef void (*LockFsm_NotifyCallback_t)(LockFsm_Notification_t notification);

/**
 * @brief  เริ่มต้น lock_fsm: ตั้งรหัส default ผ่าน code_storage และรีเซ็ต
 *         สถานะทั้งหมดกลับเป็น IDLE
 * @param  notify_callback : ฟังก์ชันที่ Application ชั้นบน implement ไว้รับ
 *                           เหตุการณ์ (ห้าม NULL)
 */
void LockFsm_Init(LockFsm_NotifyCallback_t notify_callback);

/**
 * @brief  เรียกทุกครั้งที่ code_decoder แปลง duration เป็นสัญลักษณ์ได้แล้ว
 *         (เรียกจาก EXTI release handler ผ่าน main.c)
 * @param  symbol            : สัญลักษณ์ที่ได้จาก CodeDecoder_Classify()
 * @param  press_duration_ms : เวลากดจริง (ms) - ตอนนี้ยังไม่ได้ใช้ค่านี้
 *                             ใน logic (สงวนไว้สำหรับโหมดตั้งรหัสในอนาคต
 *                             ที่ต้องแยกกดค้างยาวพิเศษออกจากรหัสปกติ)
 */
void LockFsm_OnSymbol(CodeSymbol_t symbol, uint32_t press_duration_ms);

/**
 * @brief  เรียกทุก 100ms จาก TIM3 tick (ผ่าน main.c) เพื่อขับเคลื่อน
 *         timeout ต่างๆ ภายใน state machine (input timeout, lockout countdown,
 *         unlock display hold)
 */
void LockFsm_OnTick(void);

/** อ่านสถานะปัจจุบันของ state machine */
LockState_t LockFsm_GetState(void);

/** อ่านจำนวนครั้งที่กดผิดติดต่อกัน ณ ปัจจุบัน (0-3) */
uint8_t LockFsm_GetWrongAttemptCount(void);

/**
 * @brief  อ่านจำนวนวินาทีที่เหลือของ lockout countdown (สำหรับแสดงบน
 *         7-segment) คืนค่า 0 เสมอถ้าไม่ได้อยู่ในสถานะ LOCKED_OUT
 */
uint16_t LockFsm_GetLockoutSecondsRemaining(void);

/**
 * @brief  อ่านจำนวนสัญลักษณ์ (SHORT/LONG) ที่ป้อนเข้ามาแล้วในรอบปัจจุบัน
 *         (สำหรับแสดงบน 7-segment ว่ากดไปกี่หลักแล้ว) คืนค่า 0 ถ้ายังไม่ได้
 *         เริ่มป้อนหรือเพิ่งจบรอบไปแล้ว
 */
uint8_t LockFsm_GetEntryCount(void);

/* ---------------------------------------------------------------------- *
 * Admin override functions (เรียกจาก UART admin command เท่านั้น)
 * ---------------------------------------------------------------------- *
 * ทั้ง 3 ฟังก์ชันนี้ "ข้าม" flow ปกติของ state machine โดยตั้งใจ เพราะเป็น
 * คำสั่งจาก admin ที่ต้องมีผลทันทีไม่ว่าระบบจะอยู่สถานะไหนอยู่ก่อนหน้า
 * (ยกเว้นได้อธิบายไว้ในแต่ละฟังก์ชัน)
 * ---------------------------------------------------------------------- */

/** สั่งปลดล็อกทันที (เหมือนป้อนรหัสถูกต้อง) ไม่ว่าจะอยู่สถานะใดอยู่ก่อน */
void LockFsm_ForceUnlock(void);

/** สั่งเข้าสู่ lockout ทันที (เหมือนกดรหัสผิดครบ 3 ครั้ง) ไม่ว่าจะอยู่
 *  สถานะใดอยู่ก่อน — ไม่เพิ่ม wrong_attempt_count เพราะไม่ใช่การกดผิดจริง */
void LockFsm_ForceLockout(void);

/** สั่งรีเซ็ตรหัสกลับเป็นค่า default และกลับสู่สถานะ IDLE ทันที */
void LockFsm_ResetToDefault(void);

/**
 * @brief  เรียกเมื่อ potentiometer หลุดออกจากโซนเป้าหมายระหว่างกำลังป้อน
 *         รหัสอยู่ (สถานะ ENTERING) — ยกเลิกรอบป้อนรหัสปัจจุบันทันที กลับสู่
 *         IDLE โดยไม่นับเป็นการกดรหัสผิด (ไม่กระทบ wrong_attempt_count)
 *         ถ้าเรียกตอนไม่ได้อยู่ในสถานะ ENTERING จะไม่มีผลอะไร
 *         (หมายเหตุ: จริงๆ คือหลุด "โซนที่อยู่ตอนกดปุ่มแรก" ไม่ใช่โซนเป้าหมาย
 *          ดูคำอธิบายใน main.c ตรง LOCK_NOTIFY_KEY_ACCEPTED)
 */
void LockFsm_OnDialViolation(void);

/**
 * @brief  บังคับกลับสู่สถานะ IDLE โดยไม่แตะรหัสที่เก็บไว้และไม่แตะตัวนับ
 *         จำนวนครั้งกรอกผิด (ต่างจาก LockFsm_ResetToDefault ที่ล้างรหัส
 *         กลับเป็นค่า default ด้วย) ใช้ตอนเข้า Setup Mode เพื่อยกเลิก
 *         การกรอกรหัสที่ค้างอยู่แบบปลอดภัย
 */
void LockFsm_ForceIdle(void);

#endif /* LOCK_FSM_H */
