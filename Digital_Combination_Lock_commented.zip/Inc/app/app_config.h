/******************************************************************************
 * @file    app_config.h
 * @brief   ค่าคงที่ระดับ Application: pin mapping และ threshold ต่างๆ
 *          รวมไว้ที่เดียวเพื่อแก้ pin/threshold ได้จากจุดเดียว
 *
 * 📘 นี่คือ "แผงตั้งค่า" ของทั้งโปรเจค
 *    อยากย้ายขา LED? อยากเปลี่ยนเวลากดค้าง? อยากเปลี่ยนเวลา lockout?
 *    -> แก้ที่ไฟล์นี้ไฟล์เดียว ไม่ต้องไล่หาในโค้ดทุกไฟล์
 *
 *    #define ชื่อ ค่า  = ให้ compiler "แทนข้อความ" ชื่อนั้นด้วยค่านั้นก่อน compile
 *    (ไม่กิน RAM เลย เพราะไม่ใช่ตัวแปร) ตัว U ท้ายเลข = unsigned (ไม่ติดลบ)
 *    ตัว f ท้ายเลข = float (ทศนิยม)
 ******************************************************************************/
#ifndef APP_CONFIG_H
#define APP_CONFIG_H

#include <stdint.h>
#include "gpio_driver.h"   /* ต้องใช้ชื่อ GPIOA_BASE, GPIOB_BASE, GPIOC_BASE */

/* ---------------------------------------------------------------------- *
 * Pin Mapping (อ้างอิงจาก Block Diagram ใน Project Proposal)
 * รูปแบบ: _PORT = port ไหน, _PIN = ขาที่เท่าไหร่  (ในวงเล็บ = ชื่อแบบ Arduino)
 * ---------------------------------------------------------------------- */
#define APP_BUTTON_PORT        GPIOB_BASE
#define APP_BUTTON_PIN         (4U)   /* PB4 (D5) - EXTI4 ปุ่มกรอกรหัสหลัก
                                       * (ค่านี้ไม่ได้ถูกใช้จริง — exti_driver.c
                                       *  hardcode PB4 ไว้เอง ถ้าจะย้ายปุ่มต้อง
                                       *  แก้ใน exti_driver.c ด้วย) */

/* ⚠ ชื่อ "GREEN" ตัวนี้ชวนสับสน: ค่าจริงคือ PA5 (D13) ซึ่งบน shield เป็น
 *   LED สีฟ้า ใช้เป็นไฟ "กระพริบตอบรับทุกครั้งที่กดปุ่ม" (feedback)
 *   comment เดิมด้านล่างที่เขียนว่า PA7 เป็นประวัติการลองผิดลองถูก ไม่ตรงกับค่าแล้ว */
#define APP_LED_GREEN_PORT     GPIOA_BASE
#define APP_LED_GREEN_PIN      (5U)   /* PA7 (D11) - ลองใหม่เพราะ PA5 จริงๆ
                                       * เป็นสีฟ้า ไม่ใช่เขียว (เจอจากทดสอบจริง)
                                       * ถ้า PA7 ไม่ใช่เขียวอีก ให้ลองสลับเป็น
                                       * GPIOB_BASE / pin 6 (PB6, D10) แทน */

/* LED เขียวจริง PB6 (D10) — ติดค้างตอนปลดล็อกสำเร็จ */
#define APP_LED_G_PORT     GPIOB_BASE
#define APP_LED_G_PIN      (6U)

#define APP_LED_RED_PORT       GPIOA_BASE
#define APP_LED_RED_PIN        (6U)   /* PA6 (D12) - ผิด/ล็อกอยู่ */

#define APP_LED_YELLOW_PORT    GPIOA_BASE
#define APP_LED_YELLOW_PIN     (7U)   /* PA7 (D11) - ติดค้างระหว่างอยู่ใน Setup Mode */

/* ---------------------------------------------------------------------- *
 * ปุ่ม Setup Mode (เพิ่มใหม่)
 * - PB5 (D4)  : กดค้าง >= APP_SETUP_ENTRY_HOLD_MS เพื่อเข้า Setup Mode,
 *               กดสั้นเพื่อ confirm/exit แต่ละขั้นตอนภายใน Setup Mode
 * - PA10 (D2) : เพิ่มจำนวนหลักรหัส (เฉพาะตอนขั้นเลือกจำนวนหลัก)
 * - PB3 (D3)  : ลดจำนวนหลักรหัส (เฉพาะตอนขั้นเลือกจำนวนหลัก)
 * (เหมือน APP_BUTTON_* — ค่าเหล่านี้เป็นเอกสารอ้างอิง exti_driver.c hardcode ขาเอง)
 * ---------------------------------------------------------------------- */
#define APP_SETUP_BUTTON_PORT   GPIOB_BASE
#define APP_SETUP_BUTTON_PIN    (5U)

#define APP_DIGIT_UP_PORT       GPIOA_BASE
#define APP_DIGIT_UP_PIN        (10U)

#define APP_DIGIT_DOWN_PORT     GPIOB_BASE
#define APP_DIGIT_DOWN_PIN      (3U)

/* ---------------------------------------------------------------------- *
 * Timing Thresholds (หน่วย: มิลลิวินาที)
 * ---------------------------------------------------------------------- */
#define APP_PRESS_THRESHOLD_MS      (500U)   /* กด < 500ms = SHORT, >= 500ms = LONG */
#define APP_INPUT_TIMEOUT_MS        (1500U)  /* หยุดกดนานเท่านี้ = "กรอกจบแล้ว ตรวจรหัสเลย" */
#define APP_LOCKOUT_DURATION_SEC    (9U)     /* เลขที่โชว์บน 7-segment ตอนเริ่ม lockout */
#define APP_MAX_WRONG_ATTEMPTS      (3U)     /* ผิดกี่ครั้งติดกันถึงจะ lockout */
#define APP_SETUP_ENTRY_HOLD_MS     (3000U)  /* ต้องกด PB5 ค้างนานเท่านี้ถึงจะเข้า Setup Mode */

/* ---------------------------------------------------------------------- *
 * แปลงเวลาเป็นจำนวน TIM3 tick (1 tick = 100ms ตาม TIMER_DRIVER_TICK_MS)
 * เพื่อให้ lock_fsm นับ tick ได้ตรงๆ โดยไม่ต้องคูณ/หารซ้ำทุกครั้งที่เรียก
 * 📘 สูตร: จำนวน tick = เวลา(ms) / 100
 *
 * ⚠ ตรวจพบว่าค่าบางตัวไม่ตรงกับ comment (ไม่ได้แก้ค่าให้ บอกไว้ให้ตัดสินใจเอง):
 *   - APP_LOCKOUT_TICKS = 100 -> 100 x 100ms = 10 วินาที (comment เขียน 9s)
 *     ถ้าอยากได้ 9 วินาทีพอดีตาม proposal ให้เปลี่ยนเป็น 90U
 *   - APP_UNLOCK_HOLD_TICKS = 50 -> 5 วินาที (comment เขียน 10s)
 *     ถ้าอยากได้ 10 วินาทีตาม proposal ให้เปลี่ยนเป็น 100U
 * ---------------------------------------------------------------------- */
#define APP_INPUT_TIMEOUT_TICKS     (15U)   /* 1500ms / 100ms ต่อ tick */
#define APP_LOCKOUT_TICKS           (100U)   /* 9s / 100ms ต่อ tick */
#define APP_UNLOCK_HOLD_TICKS       (50U)  /* 10s ตามที่ proposal ระบุให้
                                              * แสดงผลปลดล็อกสำเร็จค้างไว้ */
#define APP_TICKS_PER_SECOND        (10U)   /* 1000ms / 100ms ต่อ tick */

/* ---------------------------------------------------------------------- *
 * 7-Segment BCD input pins — ยืนยันแล้วจาก Guide_Exam_1.pdf (ตาราง pin
 * mapping อย่างเป็นทางการ พร้อมรูป Training Shield 1 Rev 03.00 จริง)
 *
 * หมายเหตุจากสไลด์: ถ้าใช้ shield สีน้ำเงิน (blue shield) ป้าย silkscreen
 * บนบอร์ดจะ "ผิด" ให้ยึดตาม pin mapping นี้ (ของ shield สีแดง) แทนเสมอ
 * ---------------------------------------------------------------------- */
#define APP_SEG_BCD_A_PORT   GPIOC_BASE   /* 2^0 (LSB) -> PC7 */
#define APP_SEG_BCD_A_PIN    (7U)
#define APP_SEG_BCD_B_PORT   GPIOA_BASE   /* 2^1       -> PA8 */
#define APP_SEG_BCD_B_PIN    (8U)
#define APP_SEG_BCD_C_PORT   GPIOB_BASE   /* 2^2       -> PB10 */
#define APP_SEG_BCD_C_PIN    (10U)
#define APP_SEG_BCD_D_PORT   GPIOA_BASE   /* 2^3 (MSB) -> PA9 */
#define APP_SEG_BCD_D_PIN    (9U)

/* ---------------------------------------------------------------------- *
 * เซนเซอร์สภาพแวดล้อม (ADC injected: PA0 = NTC, PA1 = LDR)
 * ค่าวงจรและสูตรยืนยันจาก Lab 4.2 / Lab 4.3 (Voltage divider: Rx 10k ต่อ
 * VCC, เซนเซอร์ต่อ GND, Vout เข้า ADC)
 *
 * 📘 NTC = ตัวต้านทานที่ค่าลดลงเมื่อร้อนขึ้น (ใช้วัดอุณหภูมิ)
 *    LDR = ตัวต้านทานที่ค่าลดลงเมื่อสว่างขึ้น (ใช้วัดแสง)
 *    ADC วัดแรงดันได้ ไม่ใช่ความต้านทาน จึงต่อเป็น voltage divider:
 *         3.3V ──[Rx 10k]──┬──[เซนเซอร์]── GND
 *                          └──> ขา ADC (Vout)
 *    พอความต้านทานเซนเซอร์เปลี่ยน Vout ก็เปลี่ยน -> คำนวณย้อนกลับได้
 *    (สูตรอยู่ใน env_monitor.c)
 * ---------------------------------------------------------------------- */
#define APP_ADC_MAX_RAW             (4095.0f)
#define APP_NTC_RX_OHM              (10000.0f)
#define APP_NTC_R0_OHM              (10000.0f)   /* ความต้านทาน NTC ที่ T0 */
#define APP_NTC_T0_KELVIN           (298.15f)    /* 25 องศา */
#define APP_NTC_BETA                (3950.0f)    /* ค่า Beta ของ NTC (ดูจาก datasheet เซนเซอร์) */
#define APP_LDR_RX_OHM              (10000.0f)
#define APP_LDR_SLOPE               (-0.6875f)   /* log10(R) = SLOPE*log10(lux) + OFFSET */
#define APP_LDR_OFFSET              (5.1276f)

/* อ่าน NTC + LDR ทุกกี่ tick ของ TIM3 (2 x 100ms = ทุก 200ms) */
#define APP_ENV_SAMPLE_TICKS        (2U)
/* จำนวน sample แรกหลังบูตที่ใช้หาค่าเฉลี่ยเป็น "ค่าปกติ" (5 x 200ms = 1 วินาที) */
#define APP_ENV_BASELINE_SAMPLES    (5U)

/* อุณหภูมิผิดปกติ = ต่างจากค่าปกติเกินเท่านี้ (องศา) ติดต่อกันกี่ sample */
#define APP_TEMP_TAMPER_DELTA_C         (3.0f)
#define APP_TEMP_TAMPER_CONFIRM_SAMPLES (3U)     /* 3 x 200ms = 0.6 วินาที กันค่ากระตุก */
/* ค่าปกติของอุณหภูมิขยับตามห้องอย่างช้าๆ (ทุก sample ขยับ 1/1500 ของส่วนต่าง
 * = time constant ~5 นาที) อุณหภูมิห้องที่ค่อยๆ เปลี่ยนจึงไม่ทำให้ alarm
 * แต่การเป่าไฟ/จับด้วยมือ (เปลี่ยนเร็ว) ยังจับได้
 * (1500 sample x 0.2 วินาที = 300 วินาที = 5 นาที) */
#define APP_TEMP_BASELINE_TRACK_DIV     (1500.0f)

/* มีคนอยู่ใกล้ = แสงลดลงต่ำกว่ากี่ % ของค่าปกติตอนบูต (โดนบังแสง) */
#define APP_PRESENCE_LUX_PERCENT    (50.0f)

/* ไม่มีคน + ไม่มีการกดปุ่ม นานเท่านี้ -> เข้า sleep (150 x 100ms = 15 วินาที) */
#define APP_SLEEP_IDLE_TICKS        (150U)

/* สถานะ DISABLED: LED แดงกระพริบทุกกี่ tick (5 x 100ms = 0.5 วินาที) */
#define APP_DISABLED_BLINK_TICKS    (5U)

#endif /* APP_CONFIG_H */
