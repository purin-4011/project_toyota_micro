/******************************************************************************
 * @file    code_storage.h
 * @brief   เก็บรหัส (sequence ของ SHORT/LONG) ไว้ใน RAM เท่านั้น
 *          (ยืนยันแล้วว่าไฟดับ = รหัสหาย ไม่ persist ลง Flash)
 *
 *          ตั้งแต่เพิ่ม CRC: ทุกครั้งที่ CodeStorage_Compare() ถูกเรียก จะ
 *          เช็คก่อนว่าข้อมูลรหัสที่เก็บไว้ยังตรงกับ CRC ที่บันทึกไว้ตอน
 *          commit ล่าสุดไหม (ป้องกัน RAM corruption) ถ้าไม่ตรงจะกู้กลับเป็น
 *          รหัส default อัตโนมัติ
 *
 *          (comment เดิมบอกว่ายังไม่มีฟังก์ชันตั้งรหัสใหม่ — ตอนนี้มีแล้ว
 *           คือ CodeStorage_Commit() ที่ Setup Mode เรียกใช้ ด้านล่างสุด)
 *
 * 📘 เปรียบเทียบง่ายๆ: module นี้คือ "ตู้เซฟเก็บรหัสที่ถูกต้อง"
 *    - Init    = ใส่รหัสเริ่มต้น สั้น-สั้น-สั้น-สั้น
 *    - Compare = เอารหัสที่ผู้ใช้กดมาเทียบว่าตรงไหม
 *    - Commit  = เปลี่ยนรหัสใหม่ (จาก Setup Mode)
 *    - GetLength / GetSymbol = แอบดูรหัส (ใช้กับคำสั่ง admin SHOWPASS)
 ******************************************************************************/
#ifndef CODE_STORAGE_H
#define CODE_STORAGE_H

#include <stdint.h>
#include <stdbool.h>      /* ให้ใช้ type bool (true/false) ได้ */
#include "code_decoder.h" /* ใช้ CodeSymbol_t */

/** ความยาวรหัสสูงสุดที่ buffer รองรับ (ตาม proposal: 4-8 หลัก) */
#define CODE_STORAGE_MAX_LENGTH   (8U)

/** ตั้งค่ารหัส default (ตาม proposal: "มีรหัสเริ่มต้นคือ สั้น-สั้น-สั้น-สั้น") */
void CodeStorage_Init(void);

/**
 * @brief  เทียบรหัสที่ป้อนเข้ามากับรหัสที่เก็บไว้
 * @param  p_symbols : buffer ของสัญลักษณ์ที่ผู้ใช้ป้อน
 *         📘 "p_" นำหน้า = ธรรมเนียมบอกว่าเป็น pointer (ตัวชี้ไปยังอาเรย์)
 *            CodeSymbol_t const * = "ชี้ไปที่ข้อมูลที่ห้ามแก้"
 * @param  length    : จำนวนสัญลักษณ์ที่ป้อน
 * @return true ถ้าตรงกันทุกตัวและความยาวเท่ากัน, false ถ้าไม่ตรง
 */
bool CodeStorage_Compare(CodeSymbol_t const * p_symbols, uint8_t length);

/** อ่านความยาวของรหัสที่เก็บไว้ปัจจุบัน */
uint8_t CodeStorage_GetLength(void);

/**
 * @brief  อ่านสัญลักษณ์ตำแหน่งที่ index ของรหัสที่เก็บไว้ (ใช้แสดงรหัสผ่าน
 *         ทาง admin console) คืน CODE_SYMBOL_SHORT ถ้า index เกินความยาว
 */
CodeSymbol_t CodeStorage_GetSymbol(uint8_t index);

/**
 * @brief  บันทึกรหัสใหม่ (จาก Setup Mode) ทับรหัสเดิม แล้วคำนวณ/เก็บ CRC
 *         อ้างอิงใหม่ทันที (หลักการเดียวกับ CodeStorage_Init แต่ใช้ข้อมูล
 *         ที่ผู้ใช้กำหนดเองแทนค่า default)
 * @param  p_symbols : อาเรย์สัญลักษณ์รหัสใหม่
 * @param  length    : จำนวนสัญลักษณ์ของรหัสใหม่ (จะถูก clamp ไม่เกิน
 *                     CODE_STORAGE_MAX_LENGTH)
 */
void CodeStorage_Commit(CodeSymbol_t const * p_symbols, uint8_t length);

#endif /* CODE_STORAGE_H */
