/******************************************************************************
 * @file    env_monitor.h
 * @brief   Pure logic module (ไม่แตะ hardware) — แปลงค่า ADC ดิบของ NTC และ
 *          LDR เป็นอุณหภูมิ (องศา) และความสว่าง (lux) แล้วตัดสินว่า
 *          1) มีคนอยู่ใกล้ไหม (แสงลดลงจากค่าปกติมาก = มีคนบังแสง)
 *          2) อุณหภูมิผิดปกติไหม (ต่างจากค่าปกติเกินเกณฑ์ = ถูกโจมตีด้วย
 *             ความร้อน/ความเย็น) — เมื่อเกิดแล้วจะ "ค้าง" (latched) จนกว่า
 *             admin จะสั่ง EnvMonitor_ClearTamper() ผ่านคำสั่ง RESET
 *
 *          "ค่าปกติ" (baseline) = ค่าเฉลี่ยของ sample แรกหลังบูต
 *
 * 📘 คำศัพท์:
 *    tamper   = การงัดแงะ/พยายามโจมตีอุปกรณ์ (ที่นี่หมายถึงใช้ความร้อนเป่า)
 *    latched  = "ล็อกค้าง" เกิดครั้งเดียวแล้วค้างไว้ ไม่หายเองแม้สาเหตุหายไป
 *    baseline = ค่าอ้างอิงว่า "ปกติ" เป็นเท่าไหร่ (เทียบกับค่านี้ว่าเปลี่ยนไปมากไหม)
 *    lux      = หน่วยความสว่าง (ห้องทั่วไป ~300 lux, กลางแดด ~100,000 lux)
 *
 *    ⚠ ข้อควรรู้: baseline วัดตอนบูต 1 วินาทีแรก ถ้าตอนเปิดเครื่องเอามือบัง
 *      LDR อยู่ ค่าปกติของแสงจะต่ำผิด และการตรวจ "มีคน" จะเพี้ยนไปจนกว่าจะรีบูต
 ******************************************************************************/
#ifndef ENV_MONITOR_H
#define ENV_MONITOR_H

#include <stdint.h>
#include <stdbool.h>

typedef enum
{
    ENV_NOTIFY_TAMPER_DETECTED = 0U    /* อุณหภูมิผิดปกติ (แจ้งครั้งเดียวตอนเริ่มค้าง) */
} EnvMonitor_Notification_t;

typedef void (*EnvMonitor_NotifyCallback_t)(EnvMonitor_Notification_t notification);

void EnvMonitor_Init(EnvMonitor_NotifyCallback_t notify_callback);

/**
 * @brief  ป้อนค่าดิบจาก ADC 1 รอบ (เรียกจาก JEOC callback ทุก 200ms)
 */
void EnvMonitor_OnSample(uint16_t ntc_raw, uint16_t ldr_raw);

/** มีคนอยู่ใกล้ (บังแสง) หรือไม่ — คืน false เสมอจนกว่าจะได้ค่าปกติแล้ว */
bool EnvMonitor_IsPresenceDetected(void);

/** อุณหภูมิผิดปกติค้างอยู่หรือไม่ */
bool EnvMonitor_IsTamperLatched(void);

/** ล้างสถานะอุณหภูมิผิดปกติ (admin RESET) — ถ้ายังผิดปกติอยู่จะเกิดใหม่ทันที */
void EnvMonitor_ClearTamper(void);

/** อุณหภูมิล่าสุด / ค่าปกติ หน่วย 0.1 องศา (เช่น 274 = 27.4 องศา)
 *  📘 ทำไมไม่คืน float ตรงๆ? เพราะตอนพิมพ์ออก UART เราไม่ใช้ printf (หนักและ
 *     ไม่ผ่าน MISRA) การคืนเป็นจำนวนเต็มหน่วย 0.1 ทำให้แยกหลักพิมพ์เองได้ง่าย */
int32_t EnvMonitor_GetTemperatureDeciC(void);
int32_t EnvMonitor_GetBaselineTemperatureDeciC(void);

/** ความสว่างล่าสุด / ค่าปกติ หน่วย lux */
uint32_t EnvMonitor_GetLux(void);
uint32_t EnvMonitor_GetBaselineLux(void);

#endif /* ENV_MONITOR_H */
