/******************************************************************************
 * @file    code_decoder.h
 * @brief   แปลง "ระยะเวลาที่กดปุ่มค้างไว้ (ms)" ให้เป็นสัญลักษณ์ SHORT / LONG
 *          Module นี้เป็น pure logic ไม่แตะ hardware โดยตรง (ทดสอบแยกได้ง่าย)
 *
 * 📘 "pure logic" = ไฟล์นี้เป็นแค่การคำนวณ/ตัดสินใจ ไม่มี register ไม่มี
 *    interrupt -> ยกโค้ดไปรันบนคอมเพื่อทดสอบได้เลย ไม่ต้องมีบอร์ด
 *
 *    รหัสผ่านของโปรเจคนี้คือ "จังหวะการกด" เหมือนรหัสมอร์ส เช่น
 *    สั้น-สั้น-ยาว-สั้น  ->  SHORT, SHORT, LONG, SHORT
 ******************************************************************************/
#ifndef CODE_DECODER_H
#define CODE_DECODER_H

#include <stdint.h>

/* สัญลักษณ์ 1 หลักของรหัส มีได้ 2 แบบ */
typedef enum
{
    CODE_SYMBOL_SHORT = 0U,   /* กดสั้น (< 500 ms) */
    CODE_SYMBOL_LONG  = 1U    /* กดยาว (>= 500 ms) */
} CodeSymbol_t;

/**
 * @brief  จำแนก duration การกดปุ่มเป็น SHORT หรือ LONG
 * @param  duration_ms : ระยะเวลาที่ปุ่มถูกกดค้างไว้ (หน่วย ms)
 * @return CODE_SYMBOL_SHORT หรือ CODE_SYMBOL_LONG
 * ตัวอย่าง: CodeDecoder_Classify(120) -> SHORT,  CodeDecoder_Classify(800) -> LONG
 */
CodeSymbol_t CodeDecoder_Classify(uint32_t duration_ms);

#endif /* CODE_DECODER_H */
