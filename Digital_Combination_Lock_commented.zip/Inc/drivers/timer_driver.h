/******************************************************************************
 * @file    timer_driver.h
 * @brief   Timer driver (register-level, raw address) ตาม
 *          "Two-Tier Timing Architecture":
 *
 *          TIER 1 - TIM2 : Free-running millisecond counter (ไม่มี interrupt)
 *                          Application layer อ่านค่ามาคำนวณ duration เอง
 *          TIER 2 - TIM3 : Periodic interrupt ทุก 100ms
 *                          ใช้ทำทั้ง input-timeout (1.5s) และ lockout
 *                          countdown ผ่าน mode-switching ใน
 *                          Application layer (driver ไม่รู้เรื่อง mode)
 *                          (⚠ comment เดิมเขียน 30s — ค่าจริงตอนนี้ดูที่
 *                           APP_LOCKOUT_TICKS ใน app_config.h)
 *
 * ============================================================================
 *  📘 อธิบายสำหรับมือใหม่: Timer คืออะไร?
 * ============================================================================
 *  Timer คือ "ตัวนับ" ในฮาร์ดแวร์ที่บวกเลขขึ้นเองทีละ 1 ตามจังหวะ clock
 *  โดยไม่ต้องใช้ CPU เลย มี register สำคัญ 3 ตัว:
 *    PSC (Prescaler)   : ตัวหารความถี่ — clock 16 MHz หาร (PSC+1)
 *                        ถ้า PSC = 15999 -> 16,000,000 / 16,000 = 1,000 ครั้ง/วินาที
 *                        = counter เพิ่มขึ้น 1 ทุก 1 ms
 *    CNT (Counter)     : ค่าที่กำลังนับอยู่ตอนนี้ (อ่านได้ตลอด)
 *    ARR (Auto-Reload) : นับถึงค่านี้แล้ววนกลับไป 0 + ยกธง "update"
 *                        ถ้า ARR = 99 -> นับ 0..99 = 100 ครั้ง = 100 ms ต่อรอบ
 *
 *  ทำไมแยกเป็น 2 ตัว (Two-Tier)?
 *   - TIM2 = "นาฬิกาจับเวลา" ไม่มี interrupt เอาไว้ดูเวลาปัจจุบันเป็น ms
 *     ตอนกดปุ่มจดเวลาไว้ ตอนปล่อยจดอีกครั้ง ลบกัน = กดนานกี่ ms
 *     (ละเอียดระดับ 1 ms แต่ไม่รบกวน CPU เลย)
 *   - TIM3 = "นาฬิกาปลุกทุก 100 ms" สร้าง interrupt เป็นจังหวะหัวใจของระบบ
 *     ใช้นับ timeout, นับถอยหลัง, กระพริบ LED (ไม่ต้องละเอียดมาก)
 *
 *          CLOCK ASSUMPTION: timer clock = 16 MHz (HSI default ของ
 *          Nucleo-F411RE ที่ยังไม่ได้ตั้ง PLL เพิ่ม) ถ้าเปลี่ยน SystemClock
 *          ภายหลัง ต้องแก้ TIMER_DRIVER_TIMCLK_HZ ด้านล่างให้ตรงความถี่จริง
 *          📘 HSI = High Speed Internal = ตัวกำเนิดสัญญาณ 16 MHz ในชิป ที่ชิป
 *             ใช้เป็นค่าเริ่มต้นตอนเปิดเครื่อง (ยังไม่ได้เร่งเป็น 100 MHz)
 ******************************************************************************/
#ifndef TIMER_DRIVER_H
#define TIMER_DRIVER_H

#include <stdint.h>

#define TIMER_DRIVER_TIMCLK_HZ   (16000000UL)   /* ความถี่ clock ที่ป้อนเข้า timer = 16 MHz */
#define TIMER_DRIVER_TICK_MS     (100U)         /* TIM3 ยิง interrupt ทุกกี่ ms */

/* ชนิดของ callback ที่ TIM3 จะเรียกทุก 100 ms (ไม่รับ/ไม่คืนค่า) */
typedef void (*Timer_TickCallback_t)(void);

/** เริ่มต้น TIM2 เป็น free-running millisecond counter (นับ 1 ครั้ง = 1ms) */
void Timer_Driver_TIM2_Init(void);

/** อ่านค่า tick ปัจจุบันของ TIM2 (หน่วย ms นับตั้งแต่ init)
 *  ตัวอย่างการใช้วัดเวลา:
 *     start = Timer_Driver_TIM2_GetTick();   (ตอนกด)
 *     ... ผ่านไปสักพัก ...
 *     duration = Timer_Driver_TIM2_GetTick() - start;   (ตอนปล่อย) */
uint32_t Timer_Driver_TIM2_GetTick(void);

/** เริ่มต้น TIM3 ให้ interrupt ทุก 100ms พร้อมเปิด NVIC
 *  @param callback : ฟังก์ชันที่ถูกเรียกทุก 100ms (ห้าม NULL) */
void Timer_Driver_TIM3_Init(Timer_TickCallback_t callback);

#endif /* TIMER_DRIVER_H */
