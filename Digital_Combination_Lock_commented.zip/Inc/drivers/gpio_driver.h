/******************************************************************************
 * @file    gpio_driver.h
 * @brief   GPIO driver — Register-level (bare-metal) สำหรับ STM32F411RE
 *          เขียนตามสไตล์ที่สอนในคอร์ส: define register เป็น address ตรงๆ
 *          ไม่พึ่งพา CMSIS struct (GPIOA->MODER แบบ HAL/LL ใช้)
 *
 * ============================================================================
 *  📘 อธิบายสำหรับมือใหม่: ไฟล์ .h (header) คืออะไร?
 * ============================================================================
 *  ไฟล์ .h เปรียบเหมือน "เมนูร้านอาหาร" — บอกว่ามีฟังก์ชันอะไรให้เรียกใช้ได้
 *  บ้าง รับพารามิเตอร์อะไร คืนค่าอะไร แต่ "ไม่มีวิธีทำ" อยู่ในนี้
 *  ส่วน "วิธีทำจริง" (implementation) อยู่ในไฟล์ .c ที่ชื่อเดียวกัน
 *  (gpio_driver.c)
 *
 *  ไฟล์อื่นที่อยากใช้ GPIO แค่ #include "gpio_driver.h" ก็เรียกฟังก์ชัน
 *  ด้านล่างได้เลย ไม่ต้องรู้ว่าข้างในทำงานยังไง
 *
 *  📘 GPIO คืออะไร?
 *  GPIO = General Purpose Input/Output = ขาของชิปที่เราสั่งได้เองว่าจะให้
 *  เป็น "ขาออก" (output: จ่ายไฟ 3.3V หรือ 0V ออกไป เช่น เปิด/ปิด LED) หรือ
 *  "ขาเข้า" (input: อ่านว่าตอนนี้มีไฟ 3.3V หรือ 0V เข้ามา เช่น อ่านปุ่มกด)
 *
 *  ชิป STM32 แบ่งขาเป็นกลุ่มเรียกว่า "port" ได้แก่ GPIOA, GPIOB, GPIOC, ...
 *  แต่ละ port มี 16 ขา (pin 0 - 15) เช่น PA5 = Port A ขาที่ 5
 *
 *  ⚠ ข้อจำกัดฮาร์ดแวร์: ขา GPIO จ่ายกระแสได้ประมาณ 20 mA ต่อขา และรับแรงดัน
 *    logic 3.3V — ห้ามต่อ LED โดยไม่มีตัวต้านทานจำกัดกระแส และห้ามป้อน 5V
 *    เข้าขาที่ไม่ใช่ 5V-tolerant
 *
 *  MISRA-C notes (MISRA = มาตรฐานการเขียน C ให้ปลอดภัยในงาน embedded):
 *  - fixed-width types (uint8_t/uint32_t) แทน int
 *      -> uint8_t = จำนวนเต็มไม่ติดลบ 8 บิต (0-255)
 *      -> uint32_t = จำนวนเต็มไม่ติดลบ 32 บิต (0 - 4,294,967,295)
 *      เหตุผล: "int" มีขนาดไม่แน่นอนแล้วแต่ชิป แต่ uint32_t เป็น 32 บิตเสมอ
 *  - ไม่มี dynamic memory (ไม่ใช้ malloc/free เพราะ RAM น้อยและอาจ fragment)
 *  - ทุกไฟล์มี header guard (ดูคำอธิบาย #ifndef ด้านล่าง)
 ******************************************************************************/

/* 📘 Header guard: กันไม่ให้ไฟล์นี้ถูก include ซ้ำ 2 รอบในไฟล์ .c เดียวกัน
 *    (ถ้าซ้ำ compiler จะ error ว่าประกาศ enum/type ซ้ำ)
 *    หลักการ: ครั้งแรกที่เจอ GPIO_DRIVER_H ยังไม่ถูก define -> เข้าไปอ่าน
 *    และ define มันทันที ครั้งที่สองเจอว่า define แล้ว -> ข้ามทั้งไฟล์ */
#ifndef GPIO_DRIVER_H
#define GPIO_DRIVER_H

#include <stdint.h>   /* ไลบรารีมาตรฐานที่ให้ type uint8_t, uint32_t ฯลฯ */

/* ---------------------------------------------------------------------- *
 * Base address ของแต่ละ GPIO port (อ้างอิง RM0383 Memory Map)
 * ผู้เรียกใช้ driver นี้จะส่งค่าคงที่พวกนี้เข้ามาแทนการส่ง struct pointer
 *
 * 📘 "Memory-mapped I/O" คือหัวใจของการเขียนแบบ register-level:
 *    ใน STM32 ฮาร์ดแวร์ทุกตัว (GPIO, Timer, UART, ...) ถูก "แปะ" ไว้ที่
 *    ตำแหน่ง (address) หนึ่งในหน่วยความจำ ถ้าเราเขียนค่าลงไปที่ address นั้น
 *    = สั่งงานฮาร์ดแวร์ ถ้าอ่านค่าจาก address นั้น = อ่านสถานะฮาร์ดแวร์
 *
 *    "Base address" = ที่อยู่เริ่มต้นของ port นั้น ส่วน register ย่อยแต่ละตัว
 *    (MODER, IDR, ODR ...) อยู่ห่างจาก base ไป "offset" ไบต์ (ดูใน .c)
 *    ตัวอย่าง: GPIOA_BASE = 0x40020000 ดังนั้น GPIOA_IDR อยู่ที่
 *              0x40020000 + 0x10 = 0x40020010
 *
 *    ตัว UL ท้ายตัวเลข = Unsigned Long (บอก compiler ว่าเป็นเลขไม่ติดลบ
 *    ขนาด 32 บิต ป้องกันการคำนวณ overflow/ติดลบผิดพลาด)
 * ---------------------------------------------------------------------- */
#define GPIOA_BASE   (0x40020000UL)
#define GPIOB_BASE   (0x40020400UL)
#define GPIOC_BASE   (0x40020800UL)

/* ---------------------------------------------------------------------- *
 * Public type definitions
 *
 * 📘 enum = การตั้ง "ชื่อเล่น" ให้ตัวเลข เพื่อให้อ่านโค้ดเข้าใจง่าย
 *    เช่น เขียน GPIO_MODE_OUTPUT แทนการเขียนเลข 1 ลอยๆ
 *    typedef ... GPIO_Mode_t; = ตั้งชื่อ type ใหม่ว่า GPIO_Mode_t
 *    (ลงท้ายด้วย _t เป็นธรรมเนียมว่า "นี่คือชื่อ type")
 * ---------------------------------------------------------------------- */

/* โหมดของขา — ค่าเลขตรงกับที่ต้องเขียนลงใน register MODER (2 บิตต่อขา)
 *   00 = Input, 01 = Output (ยังมี 10 = Alternate Function และ 11 = Analog
 *   แต่ driver นี้ใช้แค่ 2 แบบแรก ส่วน UART/ADC ไปตั้งเองในไฟล์ของตัวเอง) */
typedef enum
{
    GPIO_MODE_INPUT  = 0x00U,
    GPIO_MODE_OUTPUT = 0x01U
} GPIO_Mode_t;

/* ตัวต้านทาน pull-up / pull-down ภายในชิป — ค่าเลขตรงกับ register PUPDR
 * 📘 ทำไมต้องมี pull? ถ้าขา input ไม่ได้ต่อกับอะไรเลย (ลอย/floating)
 *    มันจะอ่านค่าสุ่มมั่วๆ 0/1 จากสัญญาณรบกวน การใส่ pull-up = ต่อตัวต้านทาน
 *    ไปที่ 3.3V ให้ "ค่าปกติ" เป็น 1 เสมอ (ใช้กับปุ่มที่กดแล้วต่อลง GND)
 *    pull-down = กลับกัน ค่าปกติเป็น 0 */
typedef enum
{
    GPIO_PULL_NONE = 0x00U,
    GPIO_PULL_UP   = 0x01U,
    GPIO_PULL_DOWN = 0x02U
} GPIO_Pull_t;

/* สถานะลอจิกของขา: RESET = 0 (0V), SET = 1 (3.3V) */
typedef enum
{
    GPIO_PIN_RESET = 0U,
    GPIO_PIN_SET   = 1U
} GPIO_PinState_t;

/* ---------------------------------------------------------------------- *
 * Public function prototypes
 * 📘 "prototype" = การประกาศหน้าตาฟังก์ชันล่วงหน้า (ชื่อ, พารามิเตอร์,
 *    ค่าที่คืน) ให้ไฟล์อื่นรู้จัก ส่วนเนื้อในอยู่ใน gpio_driver.c
 *    void = ไม่คืนค่าอะไรกลับมา
 * ---------------------------------------------------------------------- */

/**
 * @brief  เปิดสัญญาณนาฬิกาให้ GPIO port (ต้องเรียกก่อนใช้งาน port นั้นเสมอ)
 *         📘 เพื่อประหยัดไฟ STM32 จะ "ปิด clock" ของทุก peripheral ไว้ตอนเปิด
 *            เครื่อง ถ้าไม่เปิด clock ก่อน การเขียน register ของ port นั้น
 *            จะไม่มีผลอะไรเลย (เหมือนสั่งงานเครื่องที่ยังไม่เสียบปลั๊ก)
 * @param  port_base : ที่อยู่ฐานของ port เช่น GPIOA_BASE, GPIOB_BASE, GPIOC_BASE
 */
void GPIO_Driver_EnableClock(uint32_t port_base);

/**
 * @brief  ตั้งค่าโหมดและ pull ของขา GPIO หนึ่งขา
 * @param  port_base : ที่อยู่ฐานของ port
 * @param  pin       : หมายเลขขา (0-15)
 * @param  mode      : GPIO_MODE_INPUT หรือ GPIO_MODE_OUTPUT
 * @param  pull      : ตัวเลือก pull-up/down/none
 * ตัวอย่าง: GPIO_Driver_Init(GPIOA_BASE, 5U, GPIO_MODE_OUTPUT, GPIO_PULL_NONE);
 *           = ตั้ง PA5 เป็นขาออก ไม่มี pull
 */
void GPIO_Driver_Init(uint32_t port_base, uint8_t pin, GPIO_Mode_t mode, GPIO_Pull_t pull);

/**
 * @brief  เขียนค่าลอจิกให้ขา output (ใช้ BSRR เพื่อให้เป็น atomic operation)
 *         ตัวอย่าง: GPIO_Driver_WritePin(GPIOA_BASE, 5U, GPIO_PIN_SET); -> PA5 = 3.3V (LED ติด)
 */
void GPIO_Driver_WritePin(uint32_t port_base, uint8_t pin, GPIO_PinState_t state);

/**
 * @brief  สลับสถานะขา output (toggle) — ถ้าเดิมติดจะดับ ถ้าเดิมดับจะติด
 */
void GPIO_Driver_TogglePin(uint32_t port_base, uint8_t pin);

/**
 * @brief  อ่านค่าลอจิกปัจจุบันของขา (คืน GPIO_PIN_SET หรือ GPIO_PIN_RESET)
 */
GPIO_PinState_t GPIO_Driver_ReadPin(uint32_t port_base, uint8_t pin);

#endif /* GPIO_DRIVER_H */
