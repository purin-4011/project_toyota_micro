/******************************************************************************
 * @file    seven_segment_driver.h
 * @brief   ควบคุมจอ 7-segment ผ่าน BCD driver IC บน Training Shield
 *          (ตาม intro slide: "1 7-segment display with BCD driver IC")
 *
 *          หลักการ: BCD driver IC (เช่น 7447/4511) จะแปลงรหัส 4-bit BCD
 *          เป็นลายไฟ 7 segment ให้เองในฮาร์ดแวร์ — driver ตัวนี้จึงแค่ต้อง
 *          ส่งเลข 0-9 ออกไปเป็น 4 บิตผ่าน GPIO 4 ขา ไม่ต้องคุมทีละ segment
 *
 * 📘 อธิบายเพิ่ม:
 *    จอ 7-segment มีหลอด LED 7 ขีด (a-g) ประกอบเป็นตัวเลข ถ้าคุมตรงๆ ต้องใช้ 7 ขา
 *    แต่บน shield มีชิปตัวกลาง (BCD decoder) รับเลขฐานสอง 4 บิตแล้ววาดเลขให้เอง
 *    BCD = Binary Coded Decimal = เขียนเลข 0-9 เป็นฐานสอง 4 บิต เช่น
 *        เลข 5 = 0101  -> 2^0 = 1, 2^1 = 0, 2^2 = 1, 2^3 = 0
 *        เลข 9 = 1001  -> 2^0 = 1, 2^1 = 0, 2^2 = 0, 2^3 = 1
 *    ขาที่ต่อ:  2^0 = PC7,  2^1 = PA8,  2^2 = PB10,  2^3 = PA9
 *
 *          Pin BCD ทั้ง 4 (APP_SEG_BCD_x_* ใน app_config.h) ยืนยันแล้วจาก
 *          Guide_Exam_1.pdf (ตาราง pin mapping อย่างเป็นทางการของ Training
 *          Shield 1 Rev 03.00): PC7, PA8, PB10, PA9 ตามลำดับ 2^0 ถึง 2^3
 ******************************************************************************/
#ifndef SEVEN_SEGMENT_DRIVER_H
#define SEVEN_SEGMENT_DRIVER_H

#include <stdint.h>

/** ตั้งค่าขา BCD ทั้ง 4 เป็น output และเริ่มต้นที่เลข 0 */
void SevenSegment_Driver_Init(void);

/**
 * @brief  แสดงเลข 0-9 บนจอ 7-segment ผ่านการส่งรหัส BCD
 * @param  digit : เลขที่ต้องการแสดง (0-9) ถ้าส่งค่าเกิน 9 จะถูก clamp เหลือ 9
 *         📘 clamp = "บีบค่าให้อยู่ในขอบเขต" เช่น ส่ง 10 มาก็แสดง 9
 */
void SevenSegment_Driver_ShowDigit(uint8_t digit);

/**
 * @brief  ดับจอ 7-segment โดยส่งรหัส BCD 1111 (15) — IC ถอดรหัส BCD ทั่วไป
 *         (CD4511 / 74HC4511 / 74LS47) จะไม่แสดงอะไรเมื่อได้ค่านี้
 *         หมายเหตุ: ยังไม่ได้ยืนยันกับ IC บน Training Shield จริง ถ้าจอยัง
 *         แสดงสัญลักษณ์แปลกๆ แทนการดับ ให้เปลี่ยนไปใช้ ShowDigit(0) แทน
 */
void SevenSegment_Driver_Blank(void);

#endif /* SEVEN_SEGMENT_DRIVER_H */
