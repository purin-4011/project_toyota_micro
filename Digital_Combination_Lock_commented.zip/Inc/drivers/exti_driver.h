/******************************************************************************
 * @file    exti_driver.h
 * @brief   EXTI driver (register-level, raw address) — จับ press/release
 *          ของปุ่มทั้ง 4 ตัวที่ใช้ในโปรเจค แต่ละปุ่มมีฟังก์ชัน Init ของ
 *          ตัวเอง เขียนแบบ "คัดลอกจากของเดิมที่ทดสอบผ่านแล้ว" (PB4/EXTI4)
 *          แล้วปรับ port/pin/IRQ ให้ตรงปุ่มใหม่ แทนที่จะเขียนเป็นฟังก์ชัน
 *          generic ตัวเดียวรองรับทุกขา — เพื่อลดความเสี่ยงที่จะพลาดจุดใด
 *          จุดหนึ่งของปุ่มที่ทดสอบผ่านแล้ว (PB4) ระหว่างทำให้ generic
 *
 * ============================================================================
 *  📘 อธิบายสำหรับมือใหม่: EXTI และ Interrupt คืออะไร?
 * ============================================================================
 *  วิธีอ่านปุ่มมี 2 แบบ:
 *   1) Polling   : CPU วนถามขาปุ่มซ้ำๆ "กดยัง? กดยัง? กดยัง?" -> เปลือง CPU
 *                  และถ้าไปทำงานอื่นอยู่อาจพลาดการกดสั้นๆ
 *   2) Interrupt : ฮาร์ดแวร์คอยเฝ้าขาให้ ทันทีที่สัญญาณเปลี่ยน มันจะ "ขัดจังหวะ"
 *                  CPU ให้หยุดงานที่ทำอยู่ แล้วกระโดดไปรันฟังก์ชันพิเศษที่เรียกว่า
 *                  ISR (Interrupt Service Routine) ทำเสร็จก็กลับไปทำงานเดิมต่อ
 *                  -> เหมือนกริ่งประตู ไม่ต้องเดินไปเปิดดูทุก 5 วินาที
 *
 *  EXTI = EXTernal Interrupt controller = วงจรที่คอยเฝ้า "ขอบสัญญาณ" (edge)
 *  ของขา GPIO แล้วสร้าง interrupt
 *    - rising edge  = สัญญาณเปลี่ยนจาก 0 -> 1
 *    - falling edge = สัญญาณเปลี่ยนจาก 1 -> 0
 *  EXTI มี "line" 0-15 ตรงกับเลขขา: line 4 ใช้ได้กับ PA4 หรือ PB4 หรือ PC4
 *  (เลือกได้ทีละ port ผ่าน SYSCFG) โปรเจคนี้ใช้ line 3, 4, 5, 10
 *
 *  NVIC = Nested Vectored Interrupt Controller = "ผู้จัดคิว" interrupt ใน CPU
 *  ตัดสินว่าถ้า interrupt หลายตัวมาพร้อมกันจะให้ใครทำก่อน (ตาม priority:
 *  เลขน้อย = สำคัญกว่า)
 *
 *  📘 Callback คืออะไร?
 *  driver นี้ "ไม่รู้" ว่าปุ่มเอาไปใช้ทำอะไร มันแค่รับ "ฟังก์ชันปลายทาง"
 *  (callback) จาก main.c ไว้ แล้วพอปุ่มถูกกด/ปล่อยก็เรียกฟังก์ชันนั้นให้
 *  เหมือนฝากเบอร์โทรไว้ "มีอะไรโทรหาเบอร์นี้นะ"
 *
 *          DESIGN NOTE: Driver นี้ไม่รู้เรื่อง business logic ใดๆ ของ Digital
 *          Lock เลย หน้าที่เดียวคือแจ้ง rising/falling event ผ่าน callback
 *          -> นี่คือการแยก Driver/Application ตามเกณฑ์อาจารย์
 ******************************************************************************/
#ifndef EXTI_DRIVER_H
#define EXTI_DRIVER_H

#include <stdint.h>

/* ⚠ อ่านตรงนี้ให้ดี — ชื่ออาจทำให้งง:
 *   ปุ่มบน shield ต่อแบบ active-low (กด = ขาถูกดึงลง 0V)
 *   ดังนั้นตอน "กด" สัญญาณไฟฟ้าจริงคือ falling edge (1 -> 0) และตอน "ปล่อย"
 *   คือ rising edge (0 -> 1)
 *   แต่ในโปรเจคนี้ตั้งชื่อ enum ตาม "ความหมายของการกระทำ" ไม่ใช่ตามไฟฟ้า:
 *     EXTI_EDGE_RISING  = "ปุ่มเพิ่งถูกกดลง"   (นึกถึง "เริ่ม" การกด)
 *     EXTI_EDGE_FALLING = "ปุ่มเพิ่งถูกปล่อย"  (นึกถึง "จบ" การกด)
 *   เวลาอ่านโค้ดใน main.c ให้แปลในใจว่า RISING = กด, FALLING = ปล่อย */
typedef enum
{
    EXTI_EDGE_RISING  = 0U,   /* ปุ่มถูกกดลง (วงจร pull-up: กด = 0V) */
    EXTI_EDGE_FALLING = 1U    /* ปุ่มถูกปล่อย */
} EXTI_Edge_t;

/* 📘 Function pointer type: EXTI_Callback_t คือ "ชนิดของตัวแปรที่เก็บที่อยู่
 *    ของฟังก์ชัน" ซึ่งฟังก์ชันนั้นต้องรับ EXTI_Edge_t 1 ตัว และไม่คืนค่า
 *    เช่น main.c มีฟังก์ชัน void Main_ExtiEventHandler(EXTI_Edge_t edge)
 *    ก็ส่งชื่อฟังก์ชันนี้เข้ามาเป็น callback ได้ */
typedef void (*EXTI_Callback_t)(EXTI_Edge_t edge);

/**
 * @brief  ปุ่มกรอกรหัสหลัก (PB4 / EXTI Line 4) — เหมือนกับเวอร์ชันที่ทดสอบ
 *         ผ่านแล้วทุกประการ ไม่มีการแก้ไข
 * @param  callback : ฟังก์ชันที่จะถูกเรียกเมื่อเกิด interrupt (ห้าม NULL)
 */
void EXTI_Driver_Init(EXTI_Callback_t callback);

/**
 * @brief  ปุ่ม Setup Mode (PB5 / EXTI Line 5) — กดค้างเพื่อเข้า/ออก Setup Mode
 * @param  callback : ฟังก์ชันที่จะถูกเรียกเมื่อเกิด interrupt (ห้าม NULL)
 */
void EXTI_Driver_InitSetupButton(EXTI_Callback_t callback);

/**
 * @brief  ปุ่มเพิ่มจำนวนหลักรหัส ตอน Setup Mode (PA10 / EXTI Line 10)
 * @param  callback : ฟังก์ชันที่จะถูกเรียกเมื่อเกิด interrupt (ห้าม NULL)
 */
void EXTI_Driver_InitDigitUpButton(EXTI_Callback_t callback);

/**
 * @brief  ปุ่มลดจำนวนหลักรหัส ตอน Setup Mode (PB3 / EXTI Line 3)
 * @param  callback : ฟังก์ชันที่จะถูกเรียกเมื่อเกิด interrupt (ห้าม NULL)
 */
void EXTI_Driver_InitDigitDownButton(EXTI_Callback_t callback);

#endif /* EXTI_DRIVER_H */
